import { M as MemoryService } from "./assets/memoryService-4aM8quJj.js";
import { setupMessageListeners, translateSelectionForTab } from "./assets/messageHandler-kXoTEvuu.js";
import { l as logWithTimestamp, s as setupTabListeners, c as cleanupOnUnload, C as ConfigManager } from "./assets/_commonjsHelpers-DP-qmQZY.js";
import "./assets/WorkflowCompiler-BnHA3pBD.js";
import "./assets/notionClient-B6Inoxhc.js";
function initializeExtension() {
  logWithTimestamp("BrowserOnly 🤖️ extension initialized");
  setupMessageListeners();
  setupTabListeners();
  setupEventListeners();
  setupCommandListeners();
}
function setupEventListeners() {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "sync") {
      const providerConfigChanged = Object.keys(changes).some(
        (key) => key === "provider" || key === "anthropicApiKey" || key === "openaiApiKey" || key === "geminiApiKey" || key === "ollamaApiKey" || key === "anthropicBaseUrl" || key === "openaiBaseUrl" || key === "geminiBaseUrl" || key === "ollamaBaseUrl" || key === "translationProvider"
      );
      if (providerConfigChanged) {
        chrome.runtime.sendMessage({
          action: "providerConfigChanged"
        });
        logWithTimestamp("Provider configuration changed, notified clients");
      }
    }
  });
  chrome.runtime.onInstalled.addListener((details) => {
    logWithTimestamp("BrowserOnly 🤖️ extension installed");
    if (details.reason === "install") {
      chrome.runtime.openOptionsPage();
    }
    if (details.reason === "install" || details.reason === "update") {
      logWithTimestamp("Initializing memory database");
      const memoryService = MemoryService.getInstance();
      memoryService.init().then(async () => {
        logWithTimestamp("Memory database initialized successfully");
        if (details.reason === "install") {
          try {
            logWithTimestamp("Importing default memories for new installation");
            const importedCount = await memoryService.importDefaultMemories();
            if (importedCount > 0) {
              logWithTimestamp(`Successfully imported ${importedCount} default memories`);
            } else {
              logWithTimestamp("No default memories were imported");
            }
          } catch (error) {
            logWithTimestamp(`Error importing default memories: ${error}`, "error");
          }
        }
      }).catch((error) => {
        logWithTimestamp(`Error initializing memory database: ${error}`, "error");
      });
    }
  });
  chrome.action.onClicked.addListener(async (tab) => {
    if (tab.id) {
      logWithTimestamp(`Opening side panel for tab ${tab.id}`);
      try {
        await chrome.sidePanel.open({ tabId: tab.id });
        logWithTimestamp(`Side panel opened for tab ${tab.id}`);
      } catch (error) {
        logWithTimestamp(`Error opening side panel: ${String(error)}`, "error");
      }
    } else {
      logWithTimestamp("No tab ID available for action click", "error");
    }
  });
  chrome.runtime.onSuspend.addListener(async () => {
    logWithTimestamp("Extension is being suspended, cleaning up resources");
    try {
      await cleanupOnUnload();
      logWithTimestamp("Cleanup completed successfully");
      try {
        logWithTimestamp("Deleting memory database");
        const request = indexedDB.deleteDatabase("BrowserOnly-memories");
        request.onsuccess = () => {
          logWithTimestamp("Memory database deleted successfully");
        };
        request.onerror = (event) => {
          logWithTimestamp(`Error deleting memory database: ${event.target.error}`, "error");
        };
      } catch (error) {
        logWithTimestamp(`Exception deleting memory database: ${error}`, "error");
      }
    } catch (error) {
      logWithTimestamp(`Error during cleanup: ${String(error)}`, "error");
    }
  });
  chrome.runtime.onUpdateAvailable.addListener(async (details) => {
    logWithTimestamp(`Extension update available: ${details.version}, cleaning up resources`);
    try {
      await cleanupOnUnload();
      logWithTimestamp("Cleanup before update completed successfully");
      try {
        logWithTimestamp("Deleting memory database before update");
        const request = indexedDB.deleteDatabase("BrowserOnly-memories");
        request.onsuccess = () => {
          logWithTimestamp("Memory database deleted successfully before update");
        };
        request.onerror = (event) => {
          logWithTimestamp(`Error deleting memory database before update: ${event.target.error}`, "error");
        };
      } catch (error) {
        logWithTimestamp(`Exception deleting memory database before update: ${error}`, "error");
      }
    } catch (error) {
      logWithTimestamp(`Error during pre-update cleanup: ${String(error)}`, "error");
    }
  });
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "copyToPrompt",
      title: "Send selection to BrowserOnly",
      contexts: ["selection"]
    });
    chrome.contextMenus.create({ id: "translateSelection", title: "翻译选中文本", contexts: ["selection"] });
  });
  chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    console.log("copyToPrompt", info);
    if (info.menuItemId === "copyToPrompt") {
      chrome.runtime.sendMessage({
        type: "copyToPrompt",
        text: info.selectionText
      });
      if (tab == null ? void 0 : tab.id) {
        chrome.sidePanel.open({ tabId: tab.id });
      }
    }
    if (info.menuItemId === "translateSelection" && (tab == null ? void 0 : tab.id) && info.selectionText) {
      const settings = await ConfigManager.getInstance().getTranslationSettings();
      await translateSelectionForTab(tab.id, {
        action: "translateSelection",
        text: info.selectionText,
        requestId: `${Date.now()}`,
        targetLanguage: settings.targetLanguage,
        engine: "auto",
        style: "natural"
      });
    }
  });
  try {
    if (chrome.sidePanel.onShown) {
      chrome.sidePanel.onShown.addListener(async (info) => {
        logWithTimestamp(`Side panel shown for tab ${info.tabId}`);
        if (info.tabId) {
          try {
            const tab = await chrome.tabs.get(info.tabId);
            const windowId = tab.windowId;
            logWithTimestamp(`Side panel shown for tab ${info.tabId} in window ${windowId}`);
            chrome.runtime.sendMessage({
              action: "initializeTab",
              tabId: info.tabId,
              windowId
            });
          } catch (error) {
            logWithTimestamp(`Error getting window ID for tab ${info.tabId}: ${String(error)}`, "error");
            chrome.runtime.sendMessage({
              action: "initializeTab",
              tabId: info.tabId
            });
          }
        }
      });
    }
    if (chrome.sidePanel.onHidden) {
      chrome.sidePanel.onHidden.addListener((info) => {
        logWithTimestamp(`Side panel hidden for tab ${info.tabId}`);
      });
    }
  } catch (error) {
    logWithTimestamp("Side panel events not available: " + String(error), "warn");
    logWithTimestamp("Using fallback approach for initialization");
  }
}
function setupCommandListeners() {
  logWithTimestamp("Setting up command listeners for keyboard shortcuts");
  chrome.commands.getAll().then((commands) => {
    logWithTimestamp(`Registered commands: ${JSON.stringify(commands)}`);
  }).catch((error) => {
    logWithTimestamp(`Error getting registered commands: ${String(error)}`, "error");
  });
  chrome.commands.onCommand.addListener(async (command) => {
    logWithTimestamp(`Command received: ${command}`);
  });
  logWithTimestamp("Command listeners set up");
}
initializeExtension();
//# sourceMappingURL=background.js.map
