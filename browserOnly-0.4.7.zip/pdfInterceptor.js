function isPdfUrl(url) {
  if (!url) return false;
  const urlLower = url.toLowerCase();
  if (urlLower.endsWith(".pdf")) {
    return true;
  }
  if (urlLower.includes("/pdf/") || urlLower.includes(".pdf?") || urlLower.includes(".pdf#")) {
    return true;
  }
  const pdfViewerPatterns = [
    "chrome://pdf-viewer/",
    "chrome-extension://mhjfbmdgcfjbbpaeojofohoefgiehjai/",
    // Chrome PDF Viewer extension
    "/viewer.html",
    // Common PDF.js pattern
    "pdfjs-"
    // PDF.js patterns
  ];
  return pdfViewerPatterns.some((pattern) => urlLower.includes(pattern));
}
function extractPdfUrl(viewerUrl) {
  if (!viewerUrl) return "";
  try {
    if (viewerUrl.includes("chrome://pdf-viewer/")) {
      const urlParams = new URLSearchParams(viewerUrl.split("?")[1] || "");
      return urlParams.get("src") || viewerUrl;
    }
    if (viewerUrl.includes("chrome-extension://") && viewerUrl.includes("/content/web/viewer.html")) {
      const urlParams = new URLSearchParams(viewerUrl.split("?")[1] || "");
      const file = urlParams.get("file");
      if (file) {
        return decodeURIComponent(file);
      }
    }
    if (isPdfUrl(viewerUrl)) {
      return viewerUrl;
    }
    return viewerUrl;
  } catch (error) {
    console.error("Error extracting PDF URL:", error);
    return viewerUrl;
  }
}
const PDF_VIEWER_PATH = "pdf-viewer.html";
const INTERCEPTOR_ENABLED_KEY = "pdf-interceptor-enabled";
let isInterceptorEnabled = true;
let originalUrl = "";
async function checkInterceptionEnabled() {
  return new Promise((resolve) => {
    chrome.storage.sync.get([INTERCEPTOR_ENABLED_KEY], (result) => {
      const enabled = result[INTERCEPTOR_ENABLED_KEY] !== false;
      console.log("[PDF Interceptor] Checking storage:", INTERCEPTOR_ENABLED_KEY, "=", result[INTERCEPTOR_ENABLED_KEY], "enabled:", enabled);
      resolve(enabled);
    });
  });
}
async function initializePdfInterceptor() {
  isInterceptorEnabled = await checkInterceptionEnabled();
  if (!isInterceptorEnabled) {
    console.log("[PDF Interceptor] PDF interception is disabled");
    return;
  }
  const currentUrl = window.location.href;
  if (currentUrl.includes(PDF_VIEWER_PATH)) {
    console.log("[PDF Interceptor] Already in PDF viewer, skipping interception");
    return;
  }
  if (isPdfUrl(currentUrl)) {
    console.log("[PDF Interceptor] PDF URL detected:", currentUrl);
    interceptPdfUrl(currentUrl);
  } else {
    monitorPdfLinks();
    monitorNavigation();
  }
}
function interceptPdfUrl(pdfUrl) {
  originalUrl = extractPdfUrl(pdfUrl);
  const viewerUrl = createPdfViewerUrl(originalUrl);
  console.log("[PDF Interceptor] Redirecting to custom PDF viewer:", viewerUrl);
  window.location.replace(viewerUrl);
}
function createPdfViewerUrl(pdfUrl) {
  const extensionId = chrome.runtime.id;
  const viewerUrl = `chrome-extension://${extensionId}/${PDF_VIEWER_PATH}`;
  const encodedPdfUrl = encodeURIComponent(pdfUrl);
  return `${viewerUrl}?file=${encodedPdfUrl}`;
}
function monitorPdfLinks() {
  const pdfLinks = document.querySelectorAll('a[href$=".pdf"], a[href*=".pdf?"], a[href*=".pdf#"]');
  pdfLinks.forEach((link) => {
    if (link instanceof HTMLAnchorElement) {
      link.addEventListener("click", (event) => {
        if (isInterceptorEnabled && isPdfUrl(link.href)) {
          event.preventDefault();
          console.log("[PDF Interceptor] PDF link clicked:", link.href);
          interceptPdfUrl(link.href);
        }
      });
    }
  });
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
        if (node instanceof HTMLElement) {
          const newPdfLinks = node.querySelectorAll('a[href$=".pdf"], a[href*=".pdf?"], a[href*=".pdf#"]');
          newPdfLinks.forEach((link) => {
            if (link instanceof HTMLAnchorElement) {
              link.addEventListener("click", (event) => {
                if (isInterceptorEnabled && isPdfUrl(link.href)) {
                  event.preventDefault();
                  console.log("[PDF Interceptor] Dynamic PDF link clicked:", link.href);
                  interceptPdfUrl(link.href);
                }
              });
            }
          });
        }
      });
    });
  });
  const observationTarget = document.body ?? document.documentElement;
  if (observationTarget) {
    observer.observe(observationTarget, { childList: true, subtree: true });
  }
}
function monitorNavigation() {
  window.addEventListener("popstate", async () => {
    const currentUrl = window.location.href;
    if (isInterceptorEnabled && isPdfUrl(currentUrl)) {
      console.log("[PDF Interceptor] Navigation to PDF URL detected:", currentUrl);
      interceptPdfUrl(currentUrl);
    }
  });
  const originalPushState = history.pushState;
  const originalReplaceState = history.replaceState;
  history.pushState = function(state, title, url) {
    const result = originalPushState.apply(history, [state, title, url]);
    if (url && isInterceptorEnabled && isPdfUrl(url.toString())) {
      console.log("[PDF Interceptor] pushState to PDF URL detected:", url);
      setTimeout(() => interceptPdfUrl(url.toString()), 0);
    }
    return result;
  };
  history.replaceState = function(state, title, url) {
    const result = originalReplaceState.apply(history, [state, title, url]);
    if (url && isInterceptorEnabled && isPdfUrl(url.toString())) {
      console.log("[PDF Interceptor] replaceState to PDF URL detected:", url);
      setTimeout(() => interceptPdfUrl(url.toString()), 0);
    }
    return result;
  };
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "togglePdfInterception") {
    isInterceptorEnabled = message.enabled;
    console.log("[PDF Interceptor] Interception", isInterceptorEnabled ? "enabled" : "disabled");
    sendResponse({ success: true });
  }
  if (message.action === "checkPdfUrl") {
    const currentUrl = window.location.href;
    const isPdf = isPdfUrl(currentUrl);
    sendResponse({
      isPdf,
      url: currentUrl,
      originalUrl: isPdf ? extractPdfUrl(currentUrl) : null
    });
  }
});
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "sync" && changes[INTERCEPTOR_ENABLED_KEY]) {
    const newValue = changes[INTERCEPTOR_ENABLED_KEY].newValue;
    isInterceptorEnabled = newValue !== false;
    console.log("[PDF Interceptor] Setting changed, interception is now", isInterceptorEnabled ? "enabled" : "disabled");
  }
});
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializePdfInterceptor);
} else {
  initializePdfInterceptor();
}
//# sourceMappingURL=pdfInterceptor.js.map
