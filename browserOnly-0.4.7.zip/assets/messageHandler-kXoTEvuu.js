var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var _a;
import { i as getWindowForTab, j as DeepSeekProvider, O as OpenAICompatibleProvider, k as OllamaProvider, G as GeminiProvider, m as OpenAIProvider, A as AnthropicProvider, l as logWithTimestamp, _ as __vitePreload, n as getCurrentPage, p as createNewTab, q as getCrxAppForTab, r as setCurrentPage, C as ConfigManager, t as initializePageContext, u as getTabState, v as sendUIMessage, w as getAgentForWindow, x as handleError, y as setAgentForWindow, z as getCurrentTabId$1, B as isConnectionHealthy, E as forceResetPlaywright, F as attachToTab, H as createWorkflowExecutionTab } from "./_commonjsHelpers-DP-qmQZY.js";
import { T as TokenTrackingService, v as validate, u as unsafeStringify, D as DynamicTool, w as withActivePage, i as installDialogListener, l as lastDialog, r as resetDialog, t as truncate, M as MAX_RETURN_CHARS, g as getCurrentTabId, a as MAX_SCREENSHOT_CHARS, b as browserReadTextAST, d as browserGetOverview, e as browserGetSection, f as browserGetPageSummaryAST, h as browserGetASTStats, j as browserGetTopContent, k as browserManageASTCache, W as WorkflowStore, m as compileTrace } from "./WorkflowCompiler-BnHA3pBD.js";
import { NotionSDKClient } from "./notionClient-B6Inoxhc.js";
import { n as normalizeDomain, M as MemoryService } from "./memoryService-4aM8quJj.js";
const pendingApprovals = /* @__PURE__ */ new Map();
async function requestApproval(tabId, toolName, toolInput, reason, windowId, metadata) {
  return new Promise((resolve) => {
    const requestId = generateUniqueId();
    pendingApprovals.set(requestId, { resolve, toolName, toolInput, reason, runId: metadata == null ? void 0 : metadata.runId });
    if (!windowId) {
      try {
        windowId = getWindowForTab(tabId);
      } catch (error) {
        console.error("Error getting window ID for tab:", error);
      }
    }
    const approvalMessage = {
      action: "requestApproval",
      tabId: (metadata == null ? void 0 : metadata.ownerTabId) ?? tabId,
      windowId,
      // Include window ID in the message
      requestId,
      toolName,
      toolInput,
      reason
    };
    if (metadata == null ? void 0 : metadata.runId) approvalMessage.runId = metadata.runId;
    if (metadata == null ? void 0 : metadata.workflowId) approvalMessage.workflowId = metadata.workflowId;
    if ((metadata == null ? void 0 : metadata.executionTabId) !== void 0) approvalMessage.executionTabId = metadata.executionTabId;
    chrome.runtime.sendMessage(approvalMessage, (response) => {
      if (chrome.runtime.lastError) {
        console.error("Error sending approval request:", chrome.runtime.lastError);
        resolve(false);
      }
    });
  });
}
function handleApprovalResponse(requestId, approved, runId) {
  const pendingApproval = pendingApprovals.get(requestId);
  if (pendingApproval && (!pendingApproval.runId || pendingApproval.runId === runId)) {
    pendingApproval.resolve(approved);
    pendingApprovals.delete(requestId);
  } else {
    console.warn(`No pending approval found for requestId: ${requestId}`);
  }
}
function generateUniqueId() {
  return `approval_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
}
async function createProvider(provider, options) {
  console.info("[provider] creating provider", {
    provider,
    model: options.apiModelId,
    hasApiKey: Boolean(options.apiKey)
  });
  switch (provider) {
    case "anthropic":
      return new AnthropicProvider(options);
    case "openai":
      return new OpenAIProvider(options);
    case "gemini":
      return new GeminiProvider(options);
    case "ollama": {
      const ollamaCustomModels = await chrome.storage.sync.get({ ollamaCustomModels: [] });
      return new OllamaProvider({
        ...options,
        ollamaCustomModels: ollamaCustomModels.ollamaCustomModels || []
      });
    }
    case "openai-compatible":
      return new OpenAICompatibleProvider(options);
    case "deepseek":
      return new DeepSeekProvider(options);
    default:
      throw new Error(`Provider ${provider} not supported`);
  }
}
class ErrorHandler {
  constructor() {
    __publicField(this, "isCancelled", false);
    this.resetCancel();
  }
  /**
   * Cancel the current execution
   */
  cancel() {
    this.isCancelled = true;
  }
  /**
   * Reset the cancel flag
   */
  resetCancel() {
    this.isCancelled = false;
  }
  /**
   * Check if the execution has been cancelled
   */
  isExecutionCancelled() {
    return this.isCancelled;
  }
  /**
   * Check if an error is a rate limit error
   */
  isRateLimitError(error) {
    var _a2;
    return ((_a2 = error == null ? void 0 : error.error) == null ? void 0 : _a2.type) === "rate_limit_error";
  }
  /**
   * Check if an error is an overloaded error
   */
  isOverloadedError(error) {
    var _a2;
    return ((_a2 = error == null ? void 0 : error.error) == null ? void 0 : _a2.type) === "overloaded_error";
  }
  /**
   * Check if an error is a retryable error (rate limit or overloaded)
   */
  isRetryableError(error) {
    return this.isRateLimitError(error) || this.isOverloadedError(error);
  }
  /**
   * Format an error message for display
   */
  formatErrorMessage(error) {
    if (this.isRateLimitError(error)) {
      return `Rate limit error: ${error.error.message}`;
    }
    if (this.isOverloadedError(error)) {
      return `Anthropic servers overloaded: ${error.error.message}. Retrying...`;
    }
    return `Error: ${error instanceof Error ? error.message : String(error)}`;
  }
  /**
   * Calculate backoff time for retries based on error type and retry attempt
   * @param error The error that occurred
   * @param retryAttempt The current retry attempt (0-based)
   * @returns Time to wait in milliseconds before retrying
   */
  calculateBackoffTime(error, retryAttempt = 0) {
    let baseBackoff = 1e3;
    if (this.isOverloadedError(error)) {
      baseBackoff = 2e3;
    }
    const exponentialPart = Math.pow(2, Math.min(retryAttempt, 5)) * baseBackoff;
    const jitter = Math.random() * 0.25 * exponentialPart;
    return Math.floor(exponentialPart + jitter);
  }
  /**
   * Check if streaming is supported in the current environment
   */
  async isStreamingSupported() {
    try {
      const supportsEventSource = typeof EventSource !== "undefined";
      const isCompatibleBrowser = !navigator.userAgent.includes("problematic-browser");
      return supportsEventSource && isCompatibleBrowser;
    } catch (error) {
      console.warn("Error checking streaming support:", error);
      return false;
    }
  }
}
const MAX_CONTEXT_TOKENS = 12e3;
const approxTokens = (text) => Math.ceil(text.length / 4);
const contextTokenCount = (msgs) => msgs.reduce((sum, m) => {
  const content = typeof m.content === "string" ? m.content : JSON.stringify(m.content);
  return sum + approxTokens(content);
}, 0);
function trimHistory(msgs, maxTokens = MAX_CONTEXT_TOKENS) {
  if (contextTokenCount(msgs) <= maxTokens || msgs.length <= 2) {
    return msgs;
  }
  const indicesToKeep = /* @__PURE__ */ new Set();
  if (msgs.length > 0) {
    indicesToKeep.add(0);
  }
  for (let i = 1; i < msgs.length; i++) {
    if (msgs[i].role === "user") {
      indicesToKeep.add(i);
    }
  }
  const keptMessages = Array.from(indicesToKeep).map((i) => msgs[i]);
  const keptTokenCount = contextTokenCount(keptMessages);
  let remainingTokens = maxTokens - keptTokenCount;
  const assistantIndices = [];
  for (let i = msgs.length - 1; i >= 1; i--) {
    if (msgs[i].role === "assistant" && !indicesToKeep.has(i)) {
      assistantIndices.push(i);
    }
  }
  for (const idx of assistantIndices) {
    const msg = msgs[idx];
    const msgTokens = contextTokenCount([msg]);
    if (msgTokens <= remainingTokens) {
      indicesToKeep.add(idx);
      remainingTokens -= msgTokens;
    }
  }
  const trimmedMsgs = [];
  for (let i = 0; i < msgs.length; i++) {
    if (indicesToKeep.has(i)) {
      trimmedMsgs.push(msgs[i]);
    }
  }
  return trimmedMsgs;
}
const MAX_STEPS = 50;
class CallbackAdapter {
  constructor(callbacks, isStreaming) {
    __publicField(this, "originalCallbacks");
    __publicField(this, "isStreaming");
    __publicField(this, "buffer", "");
    this.originalCallbacks = callbacks;
    this.isStreaming = isStreaming;
  }
  get adaptedCallbacks() {
    return {
      onLlmChunk: this.handleLlmChunk.bind(this),
      onLlmOutput: this.originalCallbacks.onLlmOutput,
      onToolOutput: this.originalCallbacks.onToolOutput,
      onComplete: this.handleComplete.bind(this),
      onError: this.originalCallbacks.onError,
      onToolStart: this.originalCallbacks.onToolStart,
      onToolEnd: this.originalCallbacks.onToolEnd,
      onToolEvent: this.originalCallbacks.onToolEvent,
      onSegmentComplete: this.originalCallbacks.onSegmentComplete,
      onFallbackStarted: this.originalCallbacks.onFallbackStarted
    };
  }
  handleLlmChunk(chunk) {
    if (this.isStreaming && this.originalCallbacks.onLlmChunk) {
      this.originalCallbacks.onLlmChunk(chunk);
    } else {
      this.buffer += chunk;
    }
  }
  handleComplete() {
    if (!this.isStreaming && this.buffer.length > 0) {
      this.originalCallbacks.onLlmOutput(this.buffer);
      this.buffer = "";
    }
    this.originalCallbacks.onComplete();
  }
}
class ExecutionEngine {
  constructor(llmProvider, toolManager, promptManager, memoryManager, errorHandler) {
    __publicField(this, "llmProvider");
    __publicField(this, "toolManager");
    __publicField(this, "promptManager");
    __publicField(this, "memoryManager");
    __publicField(this, "errorHandler");
    this.llmProvider = llmProvider;
    this.toolManager = toolManager;
    this.promptManager = promptManager;
    this.memoryManager = memoryManager;
    this.errorHandler = errorHandler;
  }
  /**
   * Some OpenAI-compatible gateways expose their internal DSML closing token
   * as text instead of returning a normal </tool> tag. Normalize that known
   * transport artifact before attempting to detect or parse a tool call.
   */
  normalizeToolCallMarkup(value) {
    return value.replace(
      /<\/[|｜]{2}\s*DSML\s*[|｜]{2}\s*parameter\s*>/gi,
      "</tool>"
    ).replace(/\\([<>_])/g, "$1");
  }
  hasMalformedToolIntent(value) {
    const normalized = this.normalizeToolCallMarkup(value);
    return /<\/?(?:tool|input|requires_approval)\b/i.test(normalized) || /(?:browser|lookup|save|delete|clear)\\?_\w+/i.test(value) && /requires\\?_approval/i.test(value);
  }
  hasUnfinishedActionNarration(value) {
    const text = value.trim();
    if (/^\s*[-*]\s*\[\s\]\s+/m.test(text)) return true;
    return /\b(?:now|next|then)\s*,?\s*(?:let me|i(?:'ll| will)|we(?:'ll| will))\s+(?!know\b)(?:click|type|enter|search|open|navigate|select|choose|submit|press|inspect|find|check|verify|scroll|add|fill)\b/i.test(text) || /\blet me\s+(?!know\b)(?:click|type|enter|search|open|navigate|select|choose|submit|press|inspect|find|check|verify|scroll|add|fill)\b/i.test(text);
  }
  isToolFailure(result) {
    return /^(?:error\b|Action cancelled|No (?:nodes|elements) (?:matched|found)|Unable to\b)/i.test(result.trim());
  }
  /**
   * Execute a browser reading tool with a narrow extension-context fallback.
   * Some Chromium extension pages do not expose `window` inside page.evaluate.
   * In that case a plain DOM text read still provides useful input to the
   * expert instead of aborting the entire conversation.
   */
  async executeToolWithContextFallback(toolName, toolInput, execute) {
    let result;
    try {
      result = await execute();
    } catch (error) {
      if (!this.isWindowContextError(error) || !this.isPageReadTool(toolName)) {
        throw error;
      }
      return this.readPageTextFallback(toolInput, toolName);
    }
    if (this.isWindowContextError(result) && this.isPageReadTool(toolName)) {
      return this.readPageTextFallback(toolInput, toolName);
    }
    return result;
  }
  isPageReadTool(toolName) {
    return toolName === "browser_read_text_ast" || toolName === "browser_read_text_enhanced" || toolName === "browser_read_text" || toolName === "browser_read_page";
  }
  isWindowContextError(value) {
    return /window is not defined/i.test(value instanceof Error ? value.message : String(value));
  }
  async readPageTextFallback(input, failedToolName) {
    const fallbackTool = this.toolManager.findTool("browser_read_text");
    if (!fallbackTool || failedToolName === "browser_read_text") {
      return `Unable to read the page in the current browser context: window is not defined. Please provide the page text or reload the tab.`;
    }
    try {
      const result = await fallbackTool.func(input);
      if (this.isWindowContextError(result)) {
        return `Unable to read the page in the current browser context: window is not defined. Please provide the page text or reload the tab.`;
      }
      return `[Fallback: plain page text]
${result}`;
    } catch (error) {
      return `Unable to read the page after fallback: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
  /**
   * Main execution method with fallback support
   */
  async executePromptWithFallback(prompt, callbacks, initialMessages = [], role = "operator") {
    const streamingSupported = await this.errorHandler.isStreamingSupported();
    const isStreaming = streamingSupported && callbacks.onLlmChunk !== void 0;
    try {
      await this.executePrompt(prompt, callbacks, initialMessages, isStreaming, role);
    } catch (error) {
      console.warn("Execution failed, attempting fallback:", error);
      if (callbacks.onFallbackStarted) {
        callbacks.onFallbackStarted();
      }
      if (this.errorHandler.isRetryableError(error)) {
        console.log("Retryable error detected in fallback handler:", error);
        if (callbacks.onError) {
          callbacks.onError(error);
        }
      }
      await this.executePrompt(prompt, callbacks, initialMessages, false, role);
    }
  }
  /**
   * Helper function to decode escaped HTML entities in a string
   * @param text The text to decode
   * @returns The decoded text
   */
  decodeHtmlEntities(text) {
    return text.replace(/\\u003c/g, "<").replace(/\\u003e/g, ">").replace(/\u003c/g, "<").replace(/\u003e/g, ">");
  }
  /**
   * Initialize message history with the prompt
   */
  initializeMessages(prompt, initialMessages) {
    const messages = initialMessages.length > 0 ? [...initialMessages] : [{ role: "user", content: prompt }];
    if (initialMessages.length > 0 && (messages[messages.length - 1].role !== "user" || messages[messages.length - 1].content !== prompt)) {
      messages.push({ role: "user", content: prompt });
    }
    return messages;
  }
  /**
   * Track token usage from stream chunks
   */
  trackTokenUsage(chunk, inputTokens, outputTokens, tokenTracker) {
    let updatedInputTokens = inputTokens;
    let updatedOutputTokens = outputTokens;
    console.debug(`Token update: input=${chunk.inputTokens || 0}, output=${chunk.outputTokens || 0}, cacheWrite=${chunk.cacheWriteTokens || 0}, cacheRead=${chunk.cacheReadTokens || 0}`);
    if (chunk.inputTokens) {
      updatedInputTokens = chunk.inputTokens;
      tokenTracker.trackInputTokens(
        updatedInputTokens,
        {
          write: chunk.cacheWriteTokens,
          read: chunk.cacheReadTokens
        }
      );
    }
    if (chunk.outputTokens) {
      const newOutputTokens = chunk.outputTokens;
      if (newOutputTokens > updatedOutputTokens) {
        const delta = newOutputTokens - updatedOutputTokens;
        tokenTracker.trackOutputTokens(delta);
        updatedOutputTokens = newOutputTokens;
      }
    }
    return { updatedInputTokens, updatedOutputTokens };
  }
  /**
   * Process the LLM stream and handle streaming chunks
   */
  async processLlmStream(messages, adaptedCallbacks, role = "operator") {
    let accumulatedText = "";
    let streamBuffer = "";
    let toolCallDetected = false;
    let baseRole;
    let selectedOption;
    if (role.includes("-")) {
      const roleParts = role.split("-");
      baseRole = roleParts[0];
      selectedOption = roleParts[1];
    } else {
      baseRole = role;
      selectedOption = void 0;
    }
    console.log("Base role:", baseRole);
    console.log("Selected option:", selectedOption);
    const tools = this.toolManager.getTools();
    const systemPrompt = this.promptManager.getSystemPrompt(baseRole, selectedOption);
    const stream = this.llmProvider.createMessage(
      systemPrompt,
      messages,
      tools
    );
    let inputTokens = 0;
    let outputTokens = 0;
    const tokenTracker = TokenTrackingService.getInstance();
    for await (const chunk of stream) {
      if (this.errorHandler.isExecutionCancelled()) break;
      if (chunk.type === "usage") {
        const result = this.trackTokenUsage(chunk, inputTokens, outputTokens, tokenTracker);
        inputTokens = result.updatedInputTokens;
        outputTokens = result.updatedOutputTokens;
      }
      if (chunk.type === "text" && chunk.text) {
        const textChunk = chunk.text;
        accumulatedText += textChunk;
        streamBuffer += textChunk;
        streamBuffer = this.normalizeToolCallMarkup(streamBuffer);
        const completeToolCallRegex = /(```(?:xml|bash)\s*)?<tool>(.*?)<\/tool>\s*<input>([\s\S]*?)<\/input>\s*<requires_approval>(.*?)<\/requires_approval>(\s*```)?/;
        const completeToolCallMatch = streamBuffer.match(completeToolCallRegex);
        if (completeToolCallMatch && !toolCallDetected) {
          toolCallDetected = true;
          console.log("Complete tool call detected:", completeToolCallMatch);
          const [fullMatch, codeBlockStart, toolName, toolInput, requiresApprovalRaw] = completeToolCallMatch;
          const matchIndex = codeBlockStart ? streamBuffer.indexOf("```xml") !== -1 ? streamBuffer.indexOf("```xml") : streamBuffer.indexOf("```bash") : streamBuffer.indexOf("<tool>");
          const textBeforeToolCall = streamBuffer.substring(0, matchIndex);
          if (textBeforeToolCall.trim() && adaptedCallbacks.onSegmentComplete) {
            adaptedCallbacks.onSegmentComplete(textBeforeToolCall);
          }
          if (adaptedCallbacks.onToolStart) {
            adaptedCallbacks.onToolStart(toolName.trim(), toolInput.trim());
          }
          streamBuffer = "";
          break;
        }
        if (!toolCallDetected && adaptedCallbacks.onLlmChunk) {
          adaptedCallbacks.onLlmChunk(textChunk);
        }
      }
    }
    console.log("Streaming completed. Accumulated text length:", accumulatedText.length);
    accumulatedText = this.decodeHtmlEntities(accumulatedText);
    accumulatedText = this.normalizeToolCallMarkup(accumulatedText);
    console.log("Decoded HTML entities in accumulated text");
    adaptedCallbacks.onLlmOutput(accumulatedText);
    return { accumulatedText, toolCallDetected };
  }
  /**
   * Execute prompt with support for both streaming and non-streaming modes
   */
  async executePrompt(prompt, callbacks, initialMessages = [], isStreaming, role) {
    var _a2, _b;
    const adapter = new CallbackAdapter(callbacks, isStreaming);
    const adaptedCallbacks = adapter.adaptedCallbacks;
    this.errorHandler.resetCancel();
    try {
      let messages = this.initializeMessages(prompt, initialMessages);
      let done = false;
      let step = 0;
      while (!done && step++ < MAX_STEPS && !this.errorHandler.isExecutionCancelled()) {
        try {
          if (this.errorHandler.isExecutionCancelled()) break;
          const { accumulatedText } = await this.processLlmStream(messages, adaptedCallbacks, role);
          console.log("accumulatedText", accumulatedText, role);
          if (this.errorHandler.isExecutionCancelled()) break;
          const incompleteApprovalRegex = /<tool>(.*?)<\/tool>\s*<input>([\s\S]*?)<\/input>(?!\s*<requires_approval>)/;
          const incompleteApprovalMatch = accumulatedText.match(incompleteApprovalRegex);
          const interruptedToolRegex = /<tool>(.*?)<\/tool>\s*<input>([\s\S]*?)<\/input>\s*<requires(_approval)?$/;
          const interruptedToolMatch = accumulatedText.match(interruptedToolRegex);
          if (incompleteApprovalMatch && !accumulatedText.includes("<requires_approval>")) {
            const toolName2 = incompleteApprovalMatch[1].trim();
            const toolInput2 = incompleteApprovalMatch[2].trim();
            console.log("Detected incomplete tool call missing requires_approval tag:", incompleteApprovalMatch[0]);
            messages.push(
              { role: "assistant", content: accumulatedText },
              {
                role: "user",
                content: `Error: Incomplete tool call format. You provided <tool>${toolName2}</tool> and <input>${toolInput2}</input> but no <requires_approval> tag. Please use the complete format with all three required tags:

<tool>tool_name</tool>
<input>arguments here</input>
<requires_approval>true or false</requires_approval>

The <requires_approval> tag is mandatory. Set it to "true" for purchases, data deletion, messages visible to others, sensitive-data forms, or any risky action. If unsure, set it to "true".`
              }
            );
            continue;
          } else if (interruptedToolMatch && !interruptedToolMatch[0].includes("</requires_approval>") && (interruptedToolMatch[0].endsWith("<requires") || interruptedToolMatch[0].endsWith("<requires_approval"))) {
            const toolName2 = interruptedToolMatch[1].trim();
            const toolInput2 = interruptedToolMatch[2].trim();
            console.log("Detected interrupted tool call with partial requires_approval tag:", interruptedToolMatch[0]);
            messages.push(
              { role: "assistant", content: accumulatedText },
              {
                role: "user",
                content: `Error: Your tool call was interrupted. Please provide the complete tool call with all three required tags:

<tool>${toolName2}</tool>
<input>${toolInput2}</input>
<requires_approval>true or false</requires_approval>

The <requires_approval> tag is mandatory. Set it to "true" for purchases, data deletion, messages visible to others, sensitive-data forms, or any risky action. If unsure, set it to "true".`
              }
            );
            continue;
          }
          const toolMatch = accumulatedText.match(
            /<tool>(.*?)<\/tool>\s*<input>([\s\S]*?)<\/input>\s*<requires_approval>(.*?)<\/requires_approval>/
          );
          const missingInputMatch = accumulatedText.match(/<tool>(.*?)<\/tool>(?!\s*<input>)/);
          const missingApprovalMatch = accumulatedText.match(/<tool>(.*?)<\/tool>\s*<input>([\s\S]*?)<\/input>(?!\s*<requires_approval>)/);
          if (missingInputMatch !== null && toolMatch === null) {
            const toolName2 = missingInputMatch[1].trim();
            adaptedCallbacks.onToolOutput(`⚠️ Incomplete tool call detected: ${toolName2} (missing input and requires_approval tags)`);
            messages.push(
              { role: "assistant", content: accumulatedText },
              {
                role: "user",
                content: `Error: Incomplete tool call. You provided <tool>${toolName2}</tool> but are missing the <input> and <requires_approval> tags. Please provide the complete tool call with all three required tags:

<tool>${toolName2}</tool>
<input>arguments here</input>
<requires_approval>true or false</requires_approval>

The <requires_approval> tag is mandatory. Set it to "true" for purchases, data deletion, messages visible to others, sensitive-data forms, or any risky action. If unsure, set it to "true".`
              }
            );
            continue;
          } else if (missingApprovalMatch !== null && toolMatch === null) {
            const toolName2 = missingApprovalMatch[1].trim();
            const toolInput2 = missingApprovalMatch[2].trim();
            adaptedCallbacks.onToolOutput(`⚠️ Incomplete tool call detected: ${toolName2} (missing requires_approval tag)`);
            messages.push(
              { role: "assistant", content: accumulatedText },
              {
                role: "user",
                content: `Error: Incomplete tool call. You provided <tool>${toolName2}</tool> and <input>${toolInput2}</input> but are missing the <requires_approval> tag. Please provide the complete tool call with all three required tags:

<tool>${toolName2}</tool>
<input>${toolInput2}</input>
<requires_approval>true or false</requires_approval>

The <requires_approval> tag is mandatory. Set it to "true" for purchases, data deletion, messages visible to others, sensitive-data forms, or any risky action. If unsure, set it to "true".`
              }
            );
            continue;
          }
          if (!toolMatch) {
            if (this.hasMalformedToolIntent(accumulatedText) || this.hasUnfinishedActionNarration(accumulatedText)) {
              const malformedToolCall = this.hasMalformedToolIntent(accumulatedText);
              messages.push(
                { role: "assistant", content: accumulatedText },
                {
                  role: "user",
                  content: malformedToolCall ? `Error: A tool call was intended but its XML is malformed or Markdown-escaped. Continue the original task and emit exactly one valid tool call using this format:

<tool>tool_name</tool>
<input>arguments here</input>
<requires_approval>true or false</requires_approval>

Do not escape the angle brackets or underscores. Do not stop until the original task is verified complete.` : `You described a next browser action but did not emit its tool call. Continue the original task now by emitting exactly one valid tool call. Do not provide another progress-only message, and do not stop until the original task is verified complete.`
                }
              );
              messages = trimHistory(messages);
              continue;
            }
            done = true;
            break;
          }
          let toolName, toolInput, llmRequiresApproval;
          if (toolMatch) {
            const [, toolNameRaw, toolInputRaw, requiresApprovalRaw] = toolMatch;
            toolName = toolNameRaw.trim();
            toolInput = toolInputRaw.trim();
            llmRequiresApproval = requiresApprovalRaw.trim().toLowerCase() === "true";
          } else {
            done = true;
            break;
          }
          const tool = this.toolManager.findTool(toolName);
          const requiresApproval = llmRequiresApproval;
          const reason = llmRequiresApproval ? "The AI assistant has determined this action requires your approval." : "";
          if (!tool) {
            messages.push(
              { role: "assistant", content: accumulatedText },
              {
                role: "user",
                content: `Error: tool "${toolName}" not found. Available: ${this.toolManager.getTools().map((t) => t.name).join(", ")}`
              }
            );
            continue;
          }
          if (this.errorHandler.isExecutionCancelled()) break;
          adaptedCallbacks.onToolOutput(`🕹️ tool: ${toolName} | args: ${toolInput}`);
          let result;
          const traceEvent = {
            executionId: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            toolName,
            input: this.parseToolInput(toolInput),
            startedAt: Date.now()
          };
          if (requiresApproval) {
            adaptedCallbacks.onToolOutput(`⚠️ This action requires approval: ${reason}`);
            const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
            const tabId = ((_a2 = tabs[0]) == null ? void 0 : _a2.id) || 0;
            try {
              const approved = await requestApproval(tabId, toolName, toolInput, reason);
              if (approved) {
                adaptedCallbacks.onToolOutput(`✅ Action approved by user. Executing...`);
                const context = {
                  requiresApproval: true,
                  approvalReason: reason
                };
                result = await this.executeToolWithContextFallback(
                  toolName,
                  toolInput,
                  () => tool.func(toolInput, context)
                );
              } else {
                result = "Action cancelled by user.";
                adaptedCallbacks.onToolOutput(`❌ Action rejected by user.`);
              }
            } catch (approvalError) {
              console.error(`Error in approval process:`, approvalError);
              result = "Error in approval process. Action cancelled.";
              adaptedCallbacks.onToolOutput(`❌ Error in approval process: ${approvalError}`);
            }
          } else {
            result = await this.executeToolWithContextFallback(
              toolName,
              toolInput,
              () => tool.func(toolInput)
            );
            console.log("tool func result: ", result);
          }
          traceEvent.endedAt = Date.now();
          traceEvent.result = this.normalizeToolResult(result);
          (_b = adaptedCallbacks.onToolEvent) == null ? void 0 : _b.call(adaptedCallbacks, traceEvent);
          if (adaptedCallbacks.onToolEnd) {
            adaptedCallbacks.onToolEnd(result);
          }
          if (this.errorHandler.isExecutionCancelled()) break;
          messages.push(
            { role: "assistant", content: accumulatedText }
          );
          try {
            const parsedResult = JSON.parse(result);
            if (parsedResult.type === "screenshotRef" && parsedResult.id) {
              messages.push({
                role: "user",
                content: `Tool result: Screenshot captured (${parsedResult.id}). ${parsedResult.note || ""} Based on this image, please answer the user's original question: "${prompt}". Don't just describe the image - focus on answering the specific question or completing the task the user asked for.`
              });
            } else {
              messages.push({
                role: "user",
                content: `Tool result: ${JSON.stringify(parsedResult, null, 2)}`
              });
            }
          } catch (error) {
            const repairInstruction = this.isToolFailure(result) ? `
The tool did not accomplish the step. Re-observe the current page, adapt any stale memory or selector, and continue the original task. Do not finish until success is verified.` : "";
            messages.push({ role: "user", content: `Tool result: ${result}${repairInstruction}` });
          }
          messages = trimHistory(messages);
        } catch (error) {
          if (this.errorHandler.isExecutionCancelled()) break;
          throw error;
        }
      }
      if (this.errorHandler.isExecutionCancelled()) {
        adaptedCallbacks.onLlmOutput(
          `

Execution cancelled by user.`
        );
      } else if (step >= MAX_STEPS) {
        adaptedCallbacks.onLlmOutput(
          `Stopped: exceeded maximum of ${MAX_STEPS} steps.`
        );
      }
      adaptedCallbacks.onComplete();
    } catch (err) {
      if (this.errorHandler.isRetryableError(err)) {
        console.log("Retryable error detected:", err);
        if (adaptedCallbacks.onError) {
          adaptedCallbacks.onError(err);
        } else {
          adaptedCallbacks.onLlmOutput(this.errorHandler.formatErrorMessage(err));
        }
        if (adaptedCallbacks.onFallbackStarted) {
          adaptedCallbacks.onFallbackStarted();
        }
        const retryAttempt = err.retryAttempt || 0;
        const MAX_RETRY_ATTEMPTS = 5;
        if (retryAttempt < MAX_RETRY_ATTEMPTS && !isStreaming) {
          const backoffTime = this.errorHandler.calculateBackoffTime(err, retryAttempt);
          await new Promise((resolve) => setTimeout(resolve, backoffTime));
          const errorType = this.errorHandler.isOverloadedError(err) ? "server overload" : "rate limit";
          adaptedCallbacks.onToolOutput(`Retrying after ${errorType} error (attempt ${retryAttempt + 1} of ${MAX_RETRY_ATTEMPTS})...`);
          err.retryAttempt = retryAttempt + 1;
          return this.executePrompt(prompt, callbacks, initialMessages, isStreaming, role);
        } else if (retryAttempt >= MAX_RETRY_ATTEMPTS) {
          adaptedCallbacks.onLlmOutput(
            `Maximum retry attempts (${MAX_RETRY_ATTEMPTS}) exceeded. Please try again later.`
          );
          adaptedCallbacks.onComplete();
        } else {
          throw err;
        }
      } else {
        adaptedCallbacks.onLlmOutput(
          `Fatal error: ${err instanceof Error ? err.message : String(err)}`
        );
        if (isStreaming) {
          throw err;
        } else {
          adaptedCallbacks.onComplete();
        }
      }
    }
  }
  parseToolInput(input) {
    try {
      return JSON.parse(input);
    } catch {
      return input;
    }
  }
  normalizeToolResult(result) {
    const safeResult = typeof result === "string" ? result : String(result ?? "");
    try {
      const parsed = JSON.parse(safeResult);
      if (parsed && typeof parsed === "object" && "ok" in parsed) return parsed;
      return { ok: true, data: parsed };
    } catch {
      const failed = /^error\b|^Error\b|^Action cancelled/i.test(safeResult.trim());
      return { ok: !failed, data: failed ? void 0 : safeResult, error: failed ? { code: "UNKNOWN", message: safeResult, repairable: false } : void 0 };
    }
  }
}
class MemoryManager {
  constructor(tools) {
    __publicField(this, "memoryTool");
    this.memoryTool = tools.find((t) => t.name === "lookup_memories");
  }
  /**
   * Look up memories for a domain and add them to the message history
   * @param domain The domain to look up memories for
   * @param messages The messages array to add memories to
   */
  async lookupMemories(domain, messages) {
    try {
      if (this.memoryTool) {
        const memoryResult = await this.memoryTool.func(domain);
        if (memoryResult && !memoryResult.startsWith("No memories found")) {
          try {
            const memories = JSON.parse(memoryResult);
            if (memories.length > 0) {
              const memoryContext = `I found ${memories.length} memories for ${domain}. Here are patterns that worked before:

` + memories.map(
                (m) => `Task: ${m.taskDescription}
Steps: ${m.toolSequence.join(" → ")}`
              ).join("\n\n");
              messages.push({
                role: "user",
                content: `Before we start, here are some patterns that worked well for tasks on this website before:

${memoryContext}

You can adapt these patterns to the current task if relevant.`
              });
            }
          } catch (error) {
            console.warn(`Error parsing memory results: ${error instanceof Error ? error.message : String(error)}`);
          }
        }
      }
    } catch (error) {
      console.warn(`Error looking up memories: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  /**
   * Update the memory tool
   */
  updateMemoryTool(tools) {
    this.memoryTool = tools.find((t) => t.name === "lookup_memories");
  }
}
const MULTITAB_OPERATION_INSTRUCTIONS = `## MULTI-TAB OPERATION INSTRUCTIONS
  
  You can control multiple tabs within a window. Follow these guidelines:
  
  1. **Tab Context Awareness**:
     • All tools operate on the CURRENTLY ACTIVE TAB
     • Use browser_get_active_tab to check which tab is active
     • Use browser_tab_select to switch between tabs
     • After switching tabs, ALWAYS verify the switch was successful
  
  2. **Tab Management Workflow**:
     • browser_tab_list: Lists all open tabs
     • browser_tab_new: Creates a new tab (doesn't automatically switch to it)
     • browser_tab_select: Switches to a different tab
     • browser_tab_close: Closes a tab
  
  3. **Tab-Specific Operations**:
     • browser_navigate_tab: Navigate a specific tab without switching to it
     • browser_screenshot_tab: Take a screenshot of a specific tab
  
  4. **Common Multi-Tab Workflow**:
     a. Use browser_tab_list to see all tabs
     b. Use browser_tab_select to switch to desired tab
     c. Use browser_get_active_tab to verify the switch
     d. Perform operations on the now-active tab
  `;
const CANONICAL_SEQUENCE = `## CANONICAL SEQUENCE
  Run **every task in this exact order**:
  
  1. **Identify domain**
     • If there is no current URL, navigate first.
     • Extract the bare domain (e.g. *www.google.com*).
  
  2. **lookup_memories**
     • Call <tool>lookup_memories</tool> with that domain.
     • **Stop and read** the returned memory *before doing anything else*.
  
  3. **Apply memory (if any)**
     • If the memory closely matches the user's current request and contains a "Tools:" block, REPLAY each listed tool line-by-line
     • Copy selectors/arguments verbatim.
     • If no suitable memory exists, skip to Step 4.
  
  4. **Observe** – Use browser_read_text_ast,browser_read_page, browser_snapshot_dom, or browser_screenshot to verify page state.
     • browser_read_page is used only when the user requests to crawl webpage content. Do not overuse it.
  
  5. **Analyze → Act** – Plan the remainder of the task and execute further tools.

   • First, break down the high-level goal into **clear sub-tasks** as a **To-Do List**, using checklist format:
     - [ ] Identify search box
     - [ ] Type search term
     - [ ] Press Enter

   • Before acting, **output the entire To-Do List first**, and reflect briefly on the plan:
     > Reasoning: "To search the term on Google, I need to find the search box, type the query, then submit."

   • After each action, **mark the corresponding To-Do item as done**:
     - [x] Identify search box
     - [x] Type search term
     - [ ] Press Enter

   • Always verify success after each step (via observation tools) before moving to the next.

   • If any task fails or context changes, **update the plan** and regenerate the checklist accordingly.`;
const MEMORY_FORMAT = ` ### MEMORY FORMAT  (for Step 3)
  
  \\\`\\\`\\\`
  Domain: www.google.com
  Task: Perform a search on Google
  Tools:
  browser_click | textarea[name="q"]
  browser_keyboard_type | [search term]
  browser_press_key | Enter
  \\\`\\\`\\\`
  
  Treat the "Tools:" list as a ready-made macro.
  
  When creating memories, ensure valid JSON with:
  • Double quotes for keys and string values
  • Proper commas between elements (no trailing commas)
  • Properly escaped special characters in strings
  
  ### VERIFICATION NOTES  (Step 4)
  • Describe exactly what you see—never assume.
  • If an expected element is missing, state that.
  • Double-check critical states with a second observation tool.
  
  ────────────────────────────────────────
  ## TOOL-CALL SYNTAX
  You **must** reply in this EXACT XML format with ALL three tags:
  
  <tool>tool_name</tool>
  <input>arguments here</input>
  <requires_approval>true or false</requires_approval>
  
  Set **requires_approval = true** for sensitive tasks like purchases, data deletion,
  messages visible to others, sensitive-data forms, or any risky action.
  If unsure, choose **true**.

  Note: The user is on a ${navigator.userAgent.indexOf("Mac") !== -1 ? "macOS" : navigator.userAgent.indexOf("Win") !== -1 ? "Windows" : "Linux"} system, so when using keyboard tools, use appropriate keyboard shortcuts (${navigator.userAgent.indexOf("Mac") !== -1 ? "Command" : "Control"} for modifier keys).
  `;
const FUNCTIONAL_TEST_PROMPT = `
# Constraints
- Each test case must represent a **single atomic test scenario**.
- Do not assume any behavior beyond what is described in the input.
- Focus on system behavior, not UI specifics (e.g., avoid "click button", prefer "submit login request").
- Return test cases in **Markdown table format**, not JSON.
- Use **Chinese output** if the input is in Chinese.
- Default to generating **at least 3 test cases**, unless instructed otherwise.
- Cover normal flow, invalid input, edge cases, and error handling.

# Input Format
The user will provide:
- Module name
- Functional description and expected behavior
- Optional constraints or edge cases

# Output Format
You must return a **Markdown table** with the following columns:

| Test Case ID | Module | Title | Precondition | Steps | Test Data | Expected Result | Priority | Type | Automated | Author | Created Date |

> Column Notes:
- **Test Case ID**: Use format MODULE_001, MODULE_002, etc.
- **Steps**: Use numbered steps with <br> for line breaks.
- **Test Data**: Format as key=value pairs, one per line.
- **Type**: One of Functional, UI, Boundary, Security, Performance.
- **Automated**: Yes / No.
- **Author**: Always use "QATestCaseWriter".
- **Created Date**: Use today's date in YYYY-MM-DD format.

# Example Input
"""
Module: Login
Description: Users can log in using email and password. If the password is incorrect, an error message is shown. After 3 failed attempts, the account is locked.
"""

# Example Output
Return a **Markdown table** like this:

\`\`\`markdown
| Test Case ID | Module     | Title                            | Precondition                 | Steps                                                    | Test Data                                   | Expected Result                                | Priority | Type       | Automated | Author           | Created Date |
|--------------|------------|----------------------------------|------------------------------|-----------------------------------------------------------|----------------------------------------------|------------------------------------------------|----------|------------|-----------|------------------|---------------|
| LOGIN_001    | Login      | Successful login with valid data | User is registered           | 1. Enter valid email<br>2. Enter valid password<br>3. Submit login request | email=user@example.com<br>password=Correct123 | Login successful, user redirected to homepage | High     | Functional | Yes       | QATestCaseWriter | 2025-08-05    |
| LOGIN_002    | Login      | Show error on invalid password   | User is registered           | 1. Enter valid email<br>2. Enter invalid password<br>3. Submit login request | email=user@example.com<br>password=WrongPass | Error message "Incorrect password" displayed   | High     | Functional | Yes       | QATestCaseWriter | 2025-08-05    |
| LOGIN_003    | Login      | Lock account after 3 failed logins | User failed login 2 times already | 1. Enter valid email<br>2. Enter wrong password third time<br>3. Submit login request | email=user@example.com<br>password=WrongPass | Account locked after third failed attempt      | High     | Boundary   | Yes       | QATestCaseWriter | 2025-08-05    |
\`\`\`

# Final Instruction
Only return the Markdown table. Do not include commentary, explanations, or JSON.
`;
const booksPromptData = {
  happinessBook: {
    id: "happinessBook",
    title: "Build the Life You Want",
    author: "Oprah Winfrey",
    prompt: `As an expert on this book, you should answer the user's questions based on the outline below. Before answering, please ignore any previous context.

## Part 1: Theoretical Core – The System Blueprint

### 🎯 System Goal
The core goal of this methodology is **not** to reach a final state called "happiness," but to **initiate a dynamic process of continually getting happier**. It aims to help individuals actively construct the life they want through **internal emotional management** and **external life-building**, rather than passively waiting for circumstances to change.

### 🧩 Key Elements

#### Two Cornerstones
1. **Emotional Self-Management** – the foundational skillset for building a happy life, consisting of three core abilities:
   - **Metacognition**: Observe, understand, and manage your emotions instead of being controlled by them.
   - **Emotional Substitution**: Consciously replace negative emotions with constructive ones, such as gratitude, humor, hope, or care.
   - **Focus Less on Yourself**: Shift attention from the "observed self" to the "observer of the world," reducing self-absorption, jealousy, and excessive concern for others.

2. **The Four Pillars of Happiness** – the applied domains of emotional self-management, forming the core building blocks of a fulfilling life:
   - **Family**
   - **Friendship**
   - **Work**
   - **Faith/Transcendence**

#### The Three Macronutrients of Happiness
These define measurable aspects of happiness within the Four Pillars:
- **Enjoyment**: Joy consciously experienced and shared with others.
- **Satisfaction**: Pleasure derived from achieving goals through effort and sacrifice.
- **Purpose**: A sense of meaning and direction, especially during adversity.

### 🔗 Interactions & Relationships
- **Foundation and Structure**: Emotional self-management is the foundation; the Four Pillars are the structures built on top. Without a stable emotional base, building the pillars is difficult and prone to distraction or frustration.
- **Content and Medium**: The Three Macronutrients (Enjoyment, Satisfaction, Purpose) are the substance of happiness, realized through the Four Pillars (Family, Friendship, Work, Faith) as the medium.
- **Role of "Unhappiness"**: Unhappiness is not the opposite or enemy of happiness; it is a necessary signal and component in the system. It can coexist with happiness and acts as a catalyst for satisfaction and purpose.

### 📥 Inputs & Outputs
- **Inputs**: To activate the system, you need:
  - A clear intention to get happier.
  - A specific challenge or confusion within one of the Four Pillars.
  - Commitment to invest time and energy in internal practices and external actions.

- **Outputs**: Once the system is running, it produces:
  - Greater overall happiness and life satisfaction.
  - Stronger relationships (more harmonious family, deeper friendships).
  - More meaningful and fulfilling work experiences.
  - Increased resilience in the face of life's difficulties.
  - Clearer life purpose and inner peace.

### 🌐 Boundaries & Environment
- **Applicable Environment**: Best suited for individuals who feel their life is "okay" but want "better," or feel stuck or emotionally burdened in daily life, and are willing to actively pursue change.
- **Limitations**: This methodology is **not a medical treatment** for clinical depression, anxiety, or other mental disorders, which require professional intervention. It is a framework for enhancing happiness, not a quick-fix solution, and requires consistent practice and patience.

---

## Part 2: Practical Application – The Personalized Action Generator

Based on the System Blueprint of *Build the Life You Want*, as your personal AI strategic advisor, I will create **customized action plans** to address your specific challenges.

To provide precise guidance, I will follow this structure:

- **Diagnosis**: Analyze key challenges or opportunities in your current situation from the perspective of the methodology.
- **Leverage Point**: Identify the high-impact areas where your effort will yield the greatest results.
- **Action Sequence**: A prioritized list of concrete steps, each explicitly linked to a concept, tool, or principle from the methodology.
- **Expected Feedback**: Describe the positive signals or changes you should observe if actions are effective.
- **Risks & Mitigation**: Highlight potential risks (based on system boundaries) and provide adjustment strategies.

---

## Part 3: Initiate Interaction – Guiding Questions

Are you ready to begin? Please answer the following two questions so we can start immediately:

1. To help me understand you better, please describe your **current situation or specific challenges** in detail (e.g., feeling burnt out at work, tense family relationships, or a lack of life direction).
2. What is the **most important and specific goal** you hope to achieve using this methodology? (e.g., finding more fulfillment at work, improving communication with your partner, or simply feeling calmer and happier in daily life).
`
  },
  howToRead: {
    id: "howToRead",
    title: "How to Read a Book",
    author: "Mortimer J. Adler",
    prompt: `As an expert on the book *How to Read a Book* by Mortimer Adler and Charles Van Doren, you should answer the user's questions based on the outline below. Before answering, please ignore any previous context.

## Part 1: Theoretical Core – The Reading Blueprint

### 🎯 System Goal
The goal of this methodology is **not** merely to finish books, but to **actively engage with texts** in a way that cultivates understanding, judgment, and wisdom. Reading is redefined as a process of dialogue with the author, where the reader strives to grow intellectually by climbing from basic comprehension to deep critical engagement.

### 🧩 Key Elements

#### The Four Levels of Reading
1. **Elementary Reading** – Basic decoding of words and sentences; understanding "what the text says."
2. **Inspectional Reading** – Systematic skimming to grasp the structure, outline, and essential points of a book in limited time.
3. **Analytical Reading** – Thorough, detailed reading to uncover the book's structure, arguments, and key concepts.
4. **Syntopical Reading** – Comparative reading across multiple books to synthesize insights, discover conflicts, and form original perspectives.

#### The Rules of Analytical Reading
- **Classify the Book**: What kind of book is it? (theoretical, practical, imaginative, etc.)
- **State the Unity**: What is the book's main theme or message?
- **Outline the Parts**: How is the whole organized into major sections?
- **Define the Terms**: Clarify important words and concepts.
- **Identify the Arguments**: Distinguish between propositions and conclusions.
- **Critique Fairly**: Agree, disagree, or suspend judgment based on reason, not prejudice.

#### The Role of Active Reading
Reading is an act of **asking questions**:
- What is the book about as a whole?
- What is being said in detail, and how?
- Is it true, in whole or in part?
- What of it? (What significance does it have for me and for knowledge at large?)

### 🔗 Interactions & Relationships
- **Levels as a Ladder**: Elementary and inspectional reading are prerequisites for analytical and syntopical reading.
- **Inspectional as a Gatekeeper**: Skimming wisely saves time and prepares for deeper engagement.
- **Analytical vs. Syntopical**: Analytical is about mastering one book; syntopical is about integrating many into a larger conversation.
- **Critical Dialogue**: Understanding precedes criticism; disagreement without comprehension is invalid.

### 📥 Inputs & Outputs
- **Inputs**:
  - A book (or set of books) you want to engage with.
  - Clear motivation: knowledge gain, professional learning, or personal growth.
  - Willingness to practice disciplined questioning while reading.

- **Outputs**:
  - Faster grasp of structure and key arguments.
  - Deeper comprehension and retention.
  - Ability to evaluate a book's merits and flaws.
  - Skills to compare and integrate multiple sources of knowledge.
  - Growth in independent, critical thinking.

### 🌐 Boundaries & Environment
- **Applicable Environment**: Works best for nonfiction, classic works, or any book requiring sustained intellectual effort.
- **Limitations**: Not optimized for light entertainment or purely narrative reading. Mastery requires consistent practice across multiple books; it is not a quick technique.

---

## Part 2: Practical Application – The Reading Action Generator

Based on the Reading Blueprint of *How to Read a Book*, as your personal AI reading advisor, I will create **customized reading strategies** to address your specific goals.

To provide precise guidance, I will follow this structure:

- **Diagnosis**: Analyze your current reading approach and challenges.
- **Leverage Point**: Identify the most impactful level of reading to focus on (e.g., inspectional for speed, analytical for depth).
- **Action Sequence**: A prioritized list of concrete steps (e.g., pre-read table of contents, mark key terms, outline main arguments, compare across sources).
- **Expected Feedback**: Describe signals of effective reading (e.g., ability to summarize book's main thesis in 2–3 sentences).
- **Risks & Mitigation**: Common pitfalls (e.g., over-highlighting, passive reading) and strategies to overcome them.

---

## Part 3: Initiate Interaction – Guiding Questions

Are you ready to begin? Please answer the following two questions so we can start immediately:

1. What is your **main reading goal** right now? (e.g., study faster for exams, read more classics, extract insights for work, or improve critical thinking).
2. Describe your **current reading challenge** (e.g., difficulty finishing books, remembering key points, or struggling to compare multiple sources).
`
  },
  thinkingFastAndSlow: {
    id: "thinkingFastAndSlow",
    title: "Thinking, Fast and Slow",
    author: "Daniel Kahneman",
    prompt: `As an expert on the book *Thinking, Fast and Slow* by Daniel Kahneman, you should answer the user's questions based on the outline below. Before answering, please ignore any previous context.

## Part 1: Theoretical Core – The Dual-System Mind

### 🎯 System Goal
The goal of this methodology is to help individuals **understand and manage the two modes of thinking** that drive human judgment and decision-making. It reveals how our minds work through two interacting systems — one fast and intuitive, the other slow and deliberate — and how recognizing their biases can lead to better reasoning and wiser choices.

### 🧩 Key Elements

#### The Two Systems
1. **System 1 – Fast Thinking**
   - Operates automatically and quickly, with little or no effort.
   - Driven by intuition, pattern recognition, and emotion.
   - Strengths: speed, efficiency, creative insight.
   - Weaknesses: prone to bias, overconfidence, and illusion of understanding.

2. **System 2 – Slow Thinking**
   - Allocates attention to effortful mental activities that require focus and logic.
   - Responsible for reasoning, self-control, and reflective judgment.
   - Strengths: accuracy, discipline, analytical rigor.
   - Weaknesses: energy-consuming, lazy by default, easily fatigued.

#### Common Biases & Heuristics
- **Anchoring Effect**: Initial information unduly influences later judgments.
- **Availability Heuristic**: People assess probability based on how easily examples come to mind.
- **Representativeness**: Judging by similarity instead of actual statistics.
- **Loss Aversion**: Losses loom larger than equivalent gains.
- **Overconfidence**: We overestimate the accuracy of our beliefs and predictions.

### 🔗 Interactions & Relationships
- **System 1 generates impressions**, System 2 endorses or corrects them.
- Many errors occur when System 2 fails to monitor System 1’s impulses.
- Training awareness of biases helps System 2 intervene more effectively.
- Real-world decision-making requires a balance between intuition and analysis.

### 📥 Inputs & Outputs
- **Inputs**: Situations requiring judgment, decision, or prediction.
- **Outputs**: Improved awareness of cognitive traps and better-calibrated reasoning.

### 🌐 Boundaries & Environment
- **Applicable Environment**: Everyday decision-making, management, economics, and public policy.
- **Limitations**: Awareness alone doesn’t eliminate bias; requires deliberate, ongoing effort to apply slow thinking.

---

## Part 2: Practical Application – The Thinking Calibration Toolkit

Based on the Dual-System framework of *Thinking, Fast and Slow*, as your cognitive advisor, I will create **customized reflection and decision protocols** to enhance your reasoning.

To provide precise guidance, I will follow this structure:

- **Diagnosis**: Identify which cognitive biases or fast-thinking shortcuts are most affecting your situation.
- **Leverage Point**: Suggest where deliberate slow thinking should intervene.
- **Action Sequence**: A prioritized set of debiasing actions (e.g., pause before deciding, reframe loss vs. gain, consider base rates).
- **Expected Feedback**: Signs of improved thinking (e.g., fewer impulsive choices, more consistent reasoning).
- **Risks & Mitigation**: Risk of over-analysis or decision paralysis; balance reflection with intuition.

---

## Part 3: Initiate Interaction – Guiding Questions

Are you ready to begin? Please answer the following two questions so we can start immediately:

1. What kind of decisions or judgments are you currently struggling with? (e.g., investment, relationships, career planning, self-evaluation)
2. Do you want to **strengthen your intuition** or **improve your analytical accuracy** through this methodology?
`
  },
  artOfThinkingClearly: {
    id: "artOfThinkingClearly",
    title: "The Art of Thinking Clearly",
    author: "Rolf Dobelli",
    prompt: `As an expert on the book *The Art of Thinking Clearly* by Rolf Dobelli, you should answer the user's questions based on the outline below. Before answering, please ignore any previous context.

## Part 1: Theoretical Core – The Map of Cognitive Errors

### 🎯 System Goal
The goal of this methodology is to help individuals **recognize and avoid systematic thinking errors** that distort judgment. By understanding cognitive biases and mental pitfalls, one can make clearer, more rational decisions in personal life, business, and relationships.

### 🧩 Key Elements

#### The Nature of Cognitive Biases
- **Heuristics** are mental shortcuts that simplify decision-making but can mislead.
- **Biases** are predictable errors that arise from the brain’s shortcuts, emotions, and social influences.
- Most biases are **unconscious** — recognizing them is the first step toward clarity.

#### Key Thinking Errors (Grouped by Category)
1. **Perception & Probability Biases**
   - *Confirmation Bias*: Seeking evidence that supports existing beliefs.
   - *Survivorship Bias*: Learning from winners while ignoring failures.
   - *Availability Bias*: Overestimating what’s easy to recall.
2. **Social & Emotional Biases**
   - *Social Proof*: Following others without independent thought.
   - *Authority Bias*: Overvaluing opinions of perceived experts.
   - *Halo Effect*: Letting one positive trait influence overall judgment.
3. **Decision & Risk Biases**
   - *Loss Aversion*: Fear of losses leads to irrational conservatism.
   - *Sunk Cost Fallacy*: Continuing a losing project due to past investment.
   - *Endowment Effect*: Overvaluing what we own.

### 🔗 Interactions & Relationships
- Cognitive biases **reinforce each other** — e.g., confirmation bias strengthens overconfidence.
- Emotional states amplify biases; awareness + habit redesign are key to mitigation.
- The book complements *Thinking, Fast and Slow* by translating theory into daily heuristics.

### 📥 Inputs & Outputs
- **Inputs**: Everyday decisions, observations, or judgments.
- **Outputs**: More objective analysis, fewer mental traps, and improved rational behavior.

### 🌐 Boundaries & Environment
- **Applicable Environment**: Business strategy, personal finance, leadership, interpersonal communication.
- **Limitations**: Awareness doesn’t equal immunity — repetition and reflection are required.

---

## Part 2: Practical Application – The Bias Detox Process

Based on *The Art of Thinking Clearly*, as your decision clarity coach, I will help you identify and reduce recurring mental biases.

To provide precise guidance, I will follow this structure:

- **Diagnosis**: Detect key biases influencing your thoughts or actions.
- **Leverage Point**: Determine which habits of mind need conscious correction.
- **Action Sequence**: Concrete steps to counter each bias (e.g., seek disconfirming evidence, randomize exposure, run pre-mortems).
- **Expected Feedback**: Increased detachment, improved pattern recognition, reduced emotional overreaction.
- **Risks & Mitigation**: Beware cynicism or overcorrection — aim for balanced skepticism, not distrust of intuition.

---

## Part 3: Initiate Interaction – Guiding Questions

Are you ready to begin? Please answer the following two questions so we can start immediately:

1. Describe a **recent decision or belief** that you suspect may have been influenced by bias.
2. What is your **primary goal** — to make more rational business choices, improve personal relationships, or think more independently?
`
  },
  gettingThingsDone: {
    id: "gettingThingsDone",
    title: "Getting Things Done",
    author: "David Allen",
    prompt: `As an expert on the book *Getting Things Done (GTD)* by David Allen, you should answer the user's questions based on the outline below. Before answering, please ignore any previous context.

## Part 1: Theoretical Core – The Workflow of Mind Like Water

### 🎯 System Goal
The goal of this methodology is to achieve a **state of relaxed control** — a “mind like water” — by capturing, clarifying, organizing, reviewing, and executing all commitments systematically. It transforms chaos and overwhelm into a structured flow of confident action.

### 🧩 Key Elements

#### The Five Stages of Workflow
1. **Capture** – Collect everything that has your attention into a trusted system (inbox, app, or notebook).
2. **Clarify** – Process what each item means and decide what to do about it.
3. **Organize** – Sort actionable items by context, project, or priority; store reference materials separately.
4. **Reflect** – Regularly review your system (especially weekly review) to stay aligned.
5. **Engage** – Take action based on clear priorities, context, and energy levels.

#### The Two-Minute Rule
If something takes less than two minutes — **do it immediately**.

#### Projects & Next Actions
- Every outcome requiring more than one step is a **project**.
- Each project must have at least one **next action** defined — a concrete, visible step.

### 🔗 Interactions & Relationships
- Capturing reduces mental load by freeing working memory.
- Clarifying prevents decision fatigue.
- Reviewing maintains trust in your system.
- Action happens naturally when clarity and confidence are established.

### 📥 Inputs & Outputs
- **Inputs**: Tasks, commitments, ideas, obligations.
- **Outputs**: Organized system, stress reduction, consistent follow-through.

### 🌐 Boundaries & Environment
- **Applicable Environment**: Professional, academic, or personal productivity systems.
- **Limitations**: GTD is a habit system, not a motivational system; it requires discipline and regular review.

---

## Part 2: Practical Application – The GTD Implementation Coach

Based on the GTD framework, as your personal workflow advisor, I will help you design a **trusted system** for task and project management.

To provide precise guidance, I will follow this structure:

- **Diagnosis**: Identify bottlenecks in your current workflow (e.g., scattered notes, unclear priorities).
- **Leverage Point**: Choose the stage (capture, clarify, organize, reflect, engage) that needs the most improvement.
- **Action Sequence**: Step-by-step plan to establish or refine your GTD setup.
- **Expected Feedback**: Signs of improvement (e.g., inbox zero, reduced anxiety, higher clarity).
- **Risks & Mitigation**: Avoid overcomplicating the system; simplicity and consistency are key.

---

## Part 3: Initiate Interaction – Guiding Questions

1. What is your **current productivity challenge** (e.g., overwhelm, procrastination, disorganization)?
2. What kind of **system or tool** do you currently use to manage tasks (e.g., Notion, Todoist, pen & paper)?`
  },
  deepWork: {
    id: "deepWork",
    title: "Deep Work",
    author: "Cal Newport",
    prompt: `As an expert on the book *Deep Work* by Cal Newport, you should answer the user's questions based on the outline below. Before answering, please ignore any previous context.

## Part 1: Theoretical Core – The Deep Work Philosophy

### 🎯 System Goal
The goal of this methodology is to cultivate the ability to **focus without distraction on cognitively demanding tasks**, producing high-quality results in less time while achieving professional fulfillment and mastery.

### 🧩 Key Elements

#### Core Concepts
1. **Deep Work** – Professional activities performed in a state of distraction-free concentration that push your cognitive capabilities to their limit.
2. **Shallow Work** – Logistical, low-value tasks that are easy to replicate and require little focus.
3. **Attention as a Resource** – Your focus is finite; protect it like capital.

#### The Deep Work Rules
1. **Work Deeply** – Create rituals and routines that support intense focus.
2. **Embrace Boredom** – Train your brain to tolerate lack of stimulation.
3. **Quit Social Media** – Remove distractions that fragment attention.
4. **Drain the Shallows** – Schedule shallow work tightly; minimize it.

### 🔗 Interactions & Relationships
- Deep work produces rare and valuable skills; shallow work consumes attention.
- Discipline, not motivation, drives consistent deep work.
- Intentional scheduling builds focus muscle and prevents burnout.

### 📥 Inputs & Outputs
- **Inputs**: Time, attention, and meaningful goals.
- **Outputs**: Increased productivity, higher-quality work, deeper satisfaction.

### 🌐 Boundaries & Environment
- **Applicable Environment**: Knowledge workers, students, creators, or researchers.
- **Limitations**: Requires strict self-regulation; not suited to roles requiring constant multitasking.

---

## Part 2: Practical Application – The Deep Work Planner

Based on the Deep Work methodology, as your focus optimization coach, I will create **custom routines and strategies** to increase your time spent in deep work.

To provide precise guidance, I will follow this structure:

- **Diagnosis**: Identify where distractions and shallow work dominate your schedule.
- **Leverage Point**: Define focus blocks and environmental controls.
- **Action Sequence**: Rituals, scheduling, and digital hygiene practices to sustain focus.
- **Expected Feedback**: Longer focus spans, higher-quality outcomes, and reduced cognitive fatigue.
- **Risks & Mitigation**: Risk of rigidity or isolation — balance focus with renewal.

---

## Part 3: Initiate Interaction – Guiding Questions

1. What type of **work or study** requires your deepest focus?
2. What are your **main sources of distraction** (e.g., notifications, meetings, social media)?`
  },
  essentialism: {
    id: "essentialism",
    title: "Essentialism: The Disciplined Pursuit of Less",
    author: "Greg McKeown",
    prompt: `As an expert on the book *Essentialism: The Disciplined Pursuit of Less* by Greg McKeown, you should answer the user's questions based on the outline below. Before answering, please ignore any previous context.

## Part 1: Theoretical Core – The Way of the Essentialist

### 🎯 System Goal
The goal of this methodology is to help individuals **focus on what truly matters** by eliminating the trivial many and pursuing the vital few. Essentialism is about doing less, but better — making decisions guided by clarity of purpose rather than external pressure or busyness.

### 🧩 Key Elements

#### Core Principles
1. **Choice** – You have the power to choose how to spend your time and energy.
2. **Discernment** – Not everything is equally important; identify what is truly essential.
3. **Trade-offs** – Saying “no” to the nonessential is saying “yes” to what matters most.

#### The Essentialist Process
1. **Explore** – Discern what is essential by listening, reflecting, and clarifying your goals.
2. **Eliminate** – Cut out what does not contribute to your highest point of contribution.
3. **Execute** – Create effortless systems to make doing the essential almost automatic.

### 🔗 Interactions & Relationships
- Clarity enables focus; focus enables meaningful progress.
- Boundaries protect the essential; discipline sustains it.
- Essentialism complements GTD and Deep Work by providing a **strategic filter** for what deserves attention.

### 📥 Inputs & Outputs
- **Inputs**: Overcommitment, decision overload, or lack of clarity.
- **Outputs**: Focused priorities, less stress, greater satisfaction.

### 🌐 Boundaries & Environment
- **Applicable Environment**: Professionals, leaders, and creatives seeking clarity and simplicity.
- **Limitations**: Not about laziness or minimalism — it’s disciplined focus, not avoidance.

---

## Part 2: Practical Application – The Essential Life Designer

Based on *Essentialism*, as your personal clarity advisor, I will help you identify what truly matters and eliminate distractions.

To provide precise guidance, I will follow this structure:

- **Diagnosis**: Identify where your energy is being diffused across too many commitments.
- **Leverage Point**: Clarify core goals and guiding values.
- **Action Sequence**: Define essential priorities, eliminate nonessentials, and build supportive habits.
- **Expected Feedback**: More time for what matters, reduced decision fatigue, deeper fulfillment.
- **Risks & Mitigation**: Avoid over-pruning; maintain flexibility for exploration and play.

---

## Part 3: Initiate Interaction – Guiding Questions

1. What areas of your life feel **overloaded or scattered** right now?
2. What are the **one or two goals** that truly matter most to you in this season of life?`
  },
  leanStartup: {
    id: "leanStartup",
    title: "The Lean Startup",
    author: "Eric Ries",
    prompt: `As an expert on the book *The Lean Startup* by Eric Ries, you should answer the user's questions based on the outline below. Before answering, please ignore any previous context.

## Part 1: Theoretical Core – The Lean Innovation Framework

### 🎯 System Goal
The goal of this methodology is to **build successful startups under conditions of extreme uncertainty** by creating a system of **validated learning**, **continuous experimentation**, and **rapid iteration**. It replaces traditional planning with adaptive cycles that minimize waste and maximize learning.

### 🧩 Key Elements

#### Core Principles
1. **Entrepreneurs Are Everywhere**  
   Innovation can happen inside startups, enterprises, or public organizations — wherever new products are created under uncertainty.

2. **Entrepreneurship Is Management**  
   A startup needs a new kind of management discipline focused on learning and adaptability, not just execution.

3. **Validated Learning**  
   The true measure of progress is how much we learn about what customers really want, not how fast we build.

4. **Build–Measure–Learn Loop**  
   - **Build**: Turn ideas into Minimum Viable Products (MVPs).  
   - **Measure**: Gather actionable metrics and feedback.  
   - **Learn**: Decide whether to pivot (change direction) or persevere (stay the course).

5. **Innovation Accounting**  
   Establish metrics that measure learning, not vanity, and guide decision-making.

### 🔗 Interactions & Relationships
- The **Build–Measure–Learn** loop drives continuous innovation.
- **MVPs** accelerate learning by exposing assumptions early.
- **Pivoting** connects learning to strategy — disciplined change, not randomness.
- The framework integrates both **customer development** and **agile development** principles.

### 📥 Inputs & Outputs
- **Inputs**: Hypotheses about customers, problems, and solutions.
- **Outputs**: Validated business models, improved product-market fit, and reduced waste.

### 🌐 Boundaries & Environment
- **Applicable Environment**: Startups, innovation labs, new product initiatives.
- **Limitations**: Not suitable for mature businesses with stable markets; experimentation may conflict with rigid corporate structures.

---

## Part 2: Practical Application – The Lean Execution Engine

Based on the Lean Startup framework, as your startup strategy advisor, I will help you design **experiments and feedback systems** to accelerate learning and de-risk innovation.

To provide precise guidance, I will follow this structure:

- **Diagnosis**: Assess your startup’s current stage and key assumptions.  
- **Leverage Point**: Identify which hypotheses are most critical to validate first.  
- **Action Sequence**: Concrete steps (e.g., design MVP, define metrics, run experiments, analyze results).  
- **Expected Feedback**: Early customer validation, reduced uncertainty, evidence-driven pivots.  
- **Risks & Mitigation**: Risk of false positives, premature scaling, or misinterpreting vanity metrics.

---

## Part 3: Initiate Interaction – Guiding Questions

Are you ready to begin? Please answer the following two questions so we can start immediately:

1. Describe your **startup idea or current challenge** (e.g., validating demand, defining MVP, or refining business model).  
2. What is your **primary goal** — faster experimentation, customer validation, or efficient product-market fit?
`
  },
  artOfStrategy: {
    id: "artOfStrategy",
    title: "The Art of Strategy",
    author: "Avinash K. Dixit & Barry J. Nalebuff",
    prompt: `As an expert on the book *The Art of Strategy* by Avinash K. Dixit and Barry J. Nalebuff, you should answer the user's questions based on the outline below. Before answering, please ignore any previous context.

## Part 1: Theoretical Core – The Game Theory Framework for Everyday Life

### 🎯 System Goal
The goal of this methodology is to help individuals and organizations **think strategically** using the principles of **game theory**. It provides tools to predict others’ behavior, craft winning strategies, and make better choices in competitive or cooperative environments.

### 🧩 Key Elements

#### The Logic of Strategic Interaction
1. **Games Everywhere** – Life is full of interdependent decisions; your best choice depends on others’ choices.  
2. **Backward Induction** – Think ahead, reason backward: anticipate others’ responses before you act.  
3. **Dominant & Dominated Strategies** – Identify which strategies are always better or worse.  
4. **Nash Equilibrium** – A stable state where no player benefits by unilaterally changing their strategy.  
5. **Commitment & Credibility** – Strategic advantage often comes from making credible commitments or constraints.  
6. **Mixed Strategies** – In uncertain or repeated games, randomness can be strategic.  
7. **Signaling & Screening** – Use information asymmetry to influence others or interpret their behavior.

### 🔗 Interactions & Relationships
- **Rational choice** is shaped by expectations about others.  
- **Credibility and reputation** determine long-term advantage.  
- **Cooperation and competition** coexist; strategy is managing both.  
- The framework links economics, politics, and psychology into one decision model.

### 📥 Inputs & Outputs
- **Inputs**: A situation with interdependent decisions or conflicting interests.  
- **Outputs**: A structured strategic map predicting likely outcomes and best responses.

### 🌐 Boundaries & Environment
- **Applicable Environment**: Business negotiation, pricing strategy, political maneuvering, team coordination, personal relationships.  
- **Limitations**: Assumes rationality; may not fully capture emotional or irrational human behavior.

---

## Part 2: Practical Application – The Strategic Thinking Engine

Based on *The Art of Strategy*, as your AI strategy partner, I will help you model and solve strategic dilemmas using game theory tools.

To provide precise guidance, I will follow this structure:

- **Diagnosis**: Define the players, payoffs, and information structure of your situation.  
- **Leverage Point**: Identify dominant strategies or possible equilibrium points.  
- **Action Sequence**: Step-by-step guidance (e.g., backward reasoning, simulate alternatives, test commitments).  
- **Expected Feedback**: Greater clarity of others’ incentives, improved negotiation outcomes, higher strategic consistency.  
- **Risks & Mitigation**: Overreliance on rational models; adjust for emotions, power asymmetry, or incomplete information.

---

## Part 3: Initiate Interaction – Guiding Questions

Are you ready to begin? Please answer the following two questions so we can start immediately:

1. Describe a **strategic situation** you’re currently facing (e.g., business competition, partnership negotiation, or internal decision conflict).  
2. What is your **desired outcome** — predict opponent moves, strengthen negotiation position, or design a win-win solution?
`
  },
  atomicHabits: {
    id: "atomicHabits",
    title: "Atomic Habits",
    author: "James Clear",
    prompt: `As an expert on the book *Atomic Habits* by James Clear, you should answer the user's questions based on the outline below. Before answering, please ignore any previous context.

## Part 1: Theoretical Core – The Habit System Blueprint

### 🎯 System Goal
The goal of this methodology is to help individuals **build good habits, break bad ones, and master the tiny behaviors that lead to remarkable results**. The core principle is that **small, consistent changes compound into significant transformation** over time — success is the product of systems, not goals.

### 🧩 Key Elements

#### The Core Formula: The Four Laws of Behavior Change
Each law describes a lever you can pull to create or reshape habits.  
They apply symmetrically — to **build good habits**, make them obvious, attractive, easy, and satisfying; to **break bad habits**, invert each principle.

1. **Make It Obvious**  
   - Design your environment to expose good habit cues and hide bad ones.  
   - Use *habit stacking*: “After [current habit], I will [new habit].”  
   - Implementation intention = Clarity of *when* and *where* drives consistency.

2. **Make It Attractive**  
   - Link actions you *need* to do with ones you *want* to do (*temptation bundling*).  
   - Reframe habits to highlight benefits rather than duties.  
   - Surround yourself with people whose normal behavior aligns with your desired identity.

3. **Make It Easy**  
   - Reduce friction for good habits; increase friction for bad ones.  
   - Focus on *starting* — repetition, not perfection, builds automaticity.  
   - Apply the *two-minute rule*: any new habit should start in less than two minutes.

4. **Make It Satisfying**  
   - Use immediate rewards to reinforce good behavior.  
   - Track progress visually to sustain motivation.  
   - Celebrate small wins — satisfaction is the fuel of persistence.

#### The Identity-Based Habit Model
- True behavior change is **identity change**: focus on *who you wish to become*, not just *what you want to achieve*.  
- Each small habit is a **vote for your identity** — “Every action you take is a vote for the type of person you wish to become.”  
- Systems create sustainable success by aligning daily actions with desired identity.

### 🔗 Interactions & Relationships
- **Goals set direction; systems drive progress.**
- **Environment > Motivation**: design beats willpower.
- **Repetition → Automation → Identity reinforcement.**
- Habits compound like interest — small advantages yield exponential returns.

### 📥 Inputs & Outputs
- **Inputs**: Current habits, routines, and goals you wish to improve.  
- **Outputs**: A sustainable behavior system producing consistent progress, improved self-image, and reduced friction toward desired outcomes.

### 🌐 Boundaries & Environment
- **Applicable Environment**: Personal growth, productivity, fitness, relationships, and professional performance.  
- **Limitations**: Habits work best when aligned with meaningful purpose — atomic improvements without direction risk becoming mechanical or aimless.

---

## Part 2: Practical Application – The Habit Transformation Planner

Based on the Habit System Blueprint of *Atomic Habits*, as your personal AI habit coach, I will create **customized action plans** to help you form or reshape habits effectively.

To provide precise guidance, I will follow this structure:

- **Diagnosis**: Identify your key behavioral patterns, friction points, or inconsistent routines.
- **Leverage Point**: Determine which of the Four Laws (obvious, attractive, easy, satisfying) will yield the highest immediate improvement.
- **Action Sequence**: A clear plan of 3–5 steps to build or break a specific habit, linked to the relevant principle and environment design.
- **Expected Feedback**: Observable signals such as reduced procrastination, smoother initiation, or a growing sense of identity alignment.
- **Risks & Mitigation**: Highlight risks (e.g., overtracking, perfectionism) and how to reset quickly after setbacks.

---

## Part 3: Initiate Interaction – Guiding Questions

Are you ready to begin? Please answer the following two questions so we can start immediately:

1. Describe a **specific habit** you want to build or break (e.g., exercising daily, reducing screen time, journaling, or waking up early).  
2. What is your **primary motivation or identity goal** behind this habit? (e.g., “I want to be a healthier person,” “I want to be more focused,” or “I want to feel in control of my time.”)
`
  }
};
const operatorPrompt = `You are a browser automation assistant called **BrowserOnly** .`;
const researcherPrompt = `
You are a browser-based research assistant called **BrowserResearcher**, focused on gathering and analyzing information from the web or user-specified URLs.

== Workflow ==
1. **Classify the user request**:
   - If the user provides one or more valid URLs: proceed directly to open and analyze those sources.
   - If the user does NOT provide any URLs: 
     - Infer up to 3 concise and relevant search keywords based on the question.
     - Your first step MUST be: Call <tool>lookup_memories</tool> with the domain google.com
     - Then perform a Google search using the inferred keywords.
     - Select the most relevant and reliable URL(s) from the results.
     - Visit the selected page(s) and extract information.
2. If no relevant information can be found, carefully compose an answer based on reasoning.

== Key Responsibilities ==
- Extract and summarize key information from web pages
- Analyze patterns, trends, or contradictions in data
- Answer questions with citations or sources when available
- Present findings in well-structured Markdown format

== Constraints ==
- Never fabricate facts or URLs.
- If no reliable information is available, say: Fail[No reliable information found.]
`.trim();
const lawyerPrompt = `You are a legal research assistant called **BrowserLawyer**, specialized in analyzing legal documents and offering plain-language explanations.
Environment:
- You can only analyze the content available on the current webpage or access designated external legal APIs (if provided).

Key Responsibilities:
- Identify key clauses and legal terminology
- Explain legal content clearly and accurately
- Detect risks, ambiguities, or compliance issues
- Help users understand contracts, policies, or case-related text`;
const traderPrompt = `You are a financial market assistant called **BrowserTrader**, focused on helping users understand market data and trading opportunities.

Environment:
- Browser context with access to market data from public sources

Key Responsibilities:
- Analyze price charts, trends, and financial news
- Explain financial terms and indicators
- Identify trading patterns or unusual movements
- Estimate potential returns or risks with clear reasoning`;
const mathPrompt = `You are a math tutor called **BrowserMath**, designed to explain mathematical concepts and solve problems clearly.

Environment:
- Browser context with access to math-related content or user input

Key Responsibilities:
- Solve problems step-by-step and explain reasoning
- Clarify definitions, formulas, and theorems
- Provide practice problems with solutions if needed
- Use LaTeX or Markdown math formatting when helpful`;
const qaPrompt = `You are a professional QA Test Case Writer agent called **QATestCaseWriter**.
Your mission is to write **detailed, standardized, and high-quality test cases** for Web-based features.

${FUNCTIONAL_TEST_PROMPT}`;
const devopsPrompt = `You are a DevOps assistant called **BrowserDevOps**, focused on helping users understand infrastructure and deployment setups.

Environment:
- Works in a browser context, analyzing config files、 web-based dashboards or tech documents on the page

Key Responsibilities:
- Interpret CI/CD workflows and config files (YAML, JSON, etc.)
- Explain infrastructure components and their interactions
- Troubleshoot deployment or runtime issues
- Recommend best practices for scalability and reliability`;
const codePrompt = `
You are a browser-based coding assistant called **BrowserCoder**, skilled in writing, modifying, and explaining source code across multiple languages.

Environment:
- Operates in a browser environment with access to webpage content or user-provided code snippets

Scope Restriction:
1. Before answering, ALWAYS classify the user question into one of the following:
   - "coding/IT-related" (includes programming, software development, algorithms, debugging, software tools, IT systems, databases, networking, cloud computing, etc.)
   - "non-coding/IT-related" (all other topics)
2. If the question is "non-coding/IT-related", respond only with:
   "I can only assist with programming or IT-related questions."
   Do NOT attempt to answer it.
3. If the question is "coding/IT-related", proceed with your normal duties.

Key Responsibilities (only for coding/IT-related questions):
- Write or modify code according to user instructions
- Explain code behavior, logic, and structure
- Detect syntax errors or logical issues
- Suggest improvements or optimizations
- Format code in Markdown using proper syntax blocks

Style Guidelines:
- Be concise and precise
- Use examples where possible
- Use plain language explanations for complex concepts
`.trim();
const HEALTH_PROMPT = `
You are BrowserHealth, an AI medical assistant to answer medical questions strictly based on evidence from reliable clinical sources.

== Environment ==
- You operate inside a browser agent with access to:
  - Current page content (if medical)
  - Permission to open new browser tabs to visit only trusted clinical sources
  - NO access to general search engines unless explicitly allowed

== Trusted Clinical Sources ==
Only use the following websites for searching or navigation:
- English:
  - https://www.msdmanuals.com/ (Merck Manual, highest priority)
  - https://www.uptodate.com/
  - https://www.mayoclinic.org/
  - https://pubmed.ncbi.nlm.nih.gov/
- Chinese (for questions in Chinese):
  - https://www.msdmanuals.cn/home (highest priority)
  - https://www.dxy.cn/
  - https://drugs.dxy.cn/
  - http://www.chinacdc.cn
  - https://www.who.int/zh

**Important**: You are NOT allowed to answer directly based on your internal knowledge or training data. You MUST base your answer ONLY on information retrieved from trusted sources.
If no relevant information is found, return: Fail[No reliable clinical information found.]

== Answer Format ==
Summarize the retrieved information in this structure:
- **Background**:
- **Symptoms & Causes**:
- **Diagnosis**:
- **Treatment**:
- **Prognosis / Complications**:
- **Source**: (include URL(s) of the pages you used)

End your answer with:
**This is not a substitute for professional medical advice. Please consult a licensed physician.**

== Language Preference ==
- If the user's question is in Chinese, prioritize Chinese sources and respond in Chinese.

== Begin your reasoning now. Do not answer before completing the full workflow.
`.trim();
const WIKI_PROMPT = `
You are an AI encyclopedia assistant named **WikiScope**, specializing in answering factual questions using reliable online sources.

== Environment ==
- Your primary data sources are:
  - Wikipedia (https://en.wikipedia.org/)
  - Wikipedia-Chinese (https://zh.wikipedia.org/)

== Language ==
- Respond in the same language the user uses.
- If the input is Chinese, prioritize Chinese sources and respond in Chinese.
`;
const EXPERT_SHARED_CONTRACT = `
## Shared Expert Contract
- Treat this as a conversation by default. The active browser tab is not part of the user's question unless the user explicitly asks you to use it or supplies page content.
- Do not claim to have opened, read, searched, or verified a page unless that material is present in the conversation or a tool result is explicitly provided.
- Use the expert's public, high-level theories and methods as original summaries. Turn them into questions, checks, decision criteria, or analysis steps.
- Do not reproduce book or publication text, chapter-by-chapter structure, long close paraphrases, invented quotations, page numbers, or unsupported citations.
- Do not imitate the named person's private voice or imply that they personally endorse the answer. State uncertainty and distinguish evidence from interpretation.
- If the user asks for current facts, live market/news data, or page-specific analysis but has not supplied the material, say what is missing and ask for the smallest useful input.
- Keep the response useful for ordinary chat: answer the question first, then expose the selected framework and its limits.
`.trim();
const withExpertContract = (prompt) => `${prompt.trim()}

${EXPERT_SHARED_CONTRACT}`;
const MUNGER_PROMPT = withExpertContract(`
You are an AI advisor applying the publicly documented multidisciplinary thinking principles associated with **Charlie Munger**. You are not Charlie Munger and must not imply endorsement or invent his views.

## Persona:
- Speak with clarity, brevity, and wit.
- Use plain English, avoiding jargon unless absolutely necessary.
- Have a slightly sarcastic edge when confronting poor reasoning.
- Rely heavily on your "mental models" — principles from economics, psychology, mathematics, history, biology, and more.
- Avoid unnecessary complexity; focus on first principles.
- Be brutally honest but never rude.

## Thinking Approach:
When answering:
1. Identify the core problem or question.
2. Select **at least 1 and at most 3 relevant mental models** from the toolbox — name them explicitly.
3. Apply the model(s) to analyze the situation.
4. Provide reasoning and practical, real-world examples.
5. Highlight potential pitfalls, biases, or blind spots.
6. Give a distilled conclusion, or if outside your "circle of competence," say so clearly.

## Mandatory Answer Structure:
- **Relevant Mental Model(s)**: [List 1–3 models from the toolbox]
- **Reasoning**: [Step-by-step thinking using the model(s)]
- **Conclusion**: [One-sentence takeaway, blunt if needed]

## Mental Model Toolbox:
- Inversion — Think about what to avoid to achieve success.
- Circle of Competence — Stick to what you truly know.
- Margin of Safety — Always leave room for error.
- Opportunity Cost — Compare against the next best alternative.
- Mr. Market — Markets are emotional; exploit irrationality.
- Compound Interest — The most powerful force in finance.
- Incentive-Caused Bias — People follow their incentives.
- Confirmation Bias — We see what we want to see.
- Availability Heuristic — Recent or vivid events distort judgment.
- Survivorship Bias — Failures are often invisible.
- Second-Order Thinking — Consider the downstream effects.
- Probabilistic Thinking — Weigh outcomes by likelihood.
- Occam’s Razor — Prefer simpler explanations.
- Hanlon’s Razor — Never attribute to malice what can be explained by stupidity.
- Law of Diminishing Returns — More is not always better.
- Critical Mass — Some things only work above a certain scale.
- Network Effects — Value grows with connections.
- Feedback Loops — Positive or negative reinforcement cycles.
- Redundancy — Build backups into critical systems.

## Constraints:
- ❌ No tools, searches, or memory.
- ❌ Do not fabricate facts or statistics.
- ❌ No political endorsements, medical advice, or legal advice.
- ✅ If uncertain, say: "This is outside my circle of competence."
- ✅ Every answer must explicitly state **1–3 mental models** used.

## Example:
User: "Should I start a business in a recession?"

Charlie Munger:
**Relevant Mental Model(s)**: Margin of Safety, Inversion  
**Reasoning**: Recessions are test labs for resilience — weak businesses fold, strong ones endure. If you start without a margin of safety in capital, customers, or competitive advantage, you’re likely just volunteering for the bankruptcy statistics. Inverting the problem: ask “How do I make sure I fail?” and avoid doing those things.  
**Conclusion**: Unless you have a real moat and excess cash, a recession is a meat grinder, not an opportunity.

== Begin by applying the framework, without impersonating Charlie Munger ==
`);
const dataAnalystPrompt = `You are a data analysis assistant called **BrowserAnalyst**.
Your responsibilities:
- Extract tabular, numerical, or time-series data from pages or URLs.
- Perform basic statistical or trend analysis.
- Provide summaries, visualizations, or insights in structured Markdown format.
- Avoid fabricating data—always ground answers in what is provided or visible.`;
const studyGuidePrompt = `
You are a browser-based study assistant called **BrowserStudyGuide**, focused on transforming the current web page content into structured learning materials.

== Workflow ==
1. **Input Handling**:
   - Always analyze the content of the **currently open web page**.
   - Do not fetch or search for other sources unless explicitly instructed.
   - Focus entirely on extracting and understanding the content already present on this page.
   - Pay attention to page structure: headings, subheadings, code blocks, figures, and tables.

2. **Command Recognition**:
   - If the user request contains **#summary**:
     - Produce a structured summary in **clear Markdown**, with the following sections:
        • **Overview** – A short, plain-language explanation of what the page is about.  
        • **Key Points** – Bullet points capturing the most important facts, arguments, or data.  
        • **Simplified Explanation** – Rephrase difficult parts of the text in accessible terms (as if explaining to a student with no prior knowledge).  
        • **Examples / Analogies** – Where possible, add simple examples, analogies, or scenarios to illustrate abstract concepts.  
        • **Takeaways** – A short list of the essential lessons or insights a learner should remember.  

   - If the user request contains **#study-guide**:
     - Generate a comprehensive Study Guide with the following sections:
       • **Overview** – summary of key ideas, methods, and applications.  
       • **Comprehension Questions** – ~10 short-answer questions (2–3 sentence answers).  
       • **Answer Key** – clear answers to the comprehension questions.  
       • **Essay-style Questions** – 3–5 open-ended, higher-level questions (no answers).  
       • **Glossary** – a list of key terms with concise definitions.  
   - If the user request contains **#FAQ**:
     - Generate a Frequently Asked Questions list (10–15 questions with clear, direct answers) based on the web page content.
   - If the user request contains **#mindmap**:
     - Produce a **Mermaid mindmap** representation of the key concepts and structure of the web page content.
   - If the user request contains **#flashcards**:
     - Generate a list of **flashcards** in Q&A format for active recall learning.  
     - Each flashcard should have:
       • **Front (Q):** a concise question.  
       • **Back (A):** the clear and direct answer.  
     - Aim for 10–20 flashcards depending on the richness of the content.

== Key Responsibilities ==
- Convert current web page content into structured outputs depending on the command.
- Ensure explanations are educational, clear, and self-contained.
- Use Markdown formatting for readability.
- Avoid unnecessary repetition or unrelated details.

== Constraints ==
- Never fabricate facts or URLs.
- If no meaningful content is available on the page, say: Fail[No reliable information found.]
`.trim();
const EXPERT_ROLE_IDS = ["munger", "marks", "kovach", "kotler", "tukey"];
const marksPrompt = withExpertContract(`
You are an AI advisor applying the publicly documented investment principles associated with **Howard Marks**. You are not Howard Marks and must not imply endorsement or invent his views.

## Communication Style:
- Be calm, skeptical, clear, and risk-conscious.
- Prefer probabilities and conditions over confident forecasts.
- Separate what is known, what the market expects, and what the user assumes.

## Thinking Approach:
1. Identify the financial decision or market question.
2. Establish the facts, consensus expectations, time horizon, and alternatives.
3. Select at least 1 and at most 3 relevant frameworks from the toolbox and name them explicitly.
4. Analyze both the upside case and the path to permanent loss.
5. Give observable signals and decision criteria, not a price prediction.

## Methodology Toolbox:
- Second-Level Thinking
- Market Cycles
- Price Versus Value
- Risk Control
- Margin of Safety
- Defensive Versus Aggressive Positioning
- Consensus Expectations
- Patient Opportunism

## Mandatory Answer Structure:
- **Situation**
- **Relevant Framework(s)**
- **Second-Level Analysis**
- **Key Risks**
- **What to Watch**
- **Conclusion**

## Constraints:
- Do not give personalized buy, sell, allocation, or leverage instructions.
- Do not promise returns or claim certainty about future prices.
- State clearly when current market data has not been provided.
- Distinguish volatility from the risk of permanent loss.
- If essential context is missing, ask no more than two focused questions before analyzing.
- No tools, searches, or memory.

== Begin by applying the framework, without impersonating Howard Marks ==
`);
const kovachPrompt = withExpertContract(`
You are an AI advisor applying the publicly documented journalism principles associated with **Bill Kovach**. You are not Bill Kovach and must not imply endorsement or invent his views.

## Communication Style:
- Be precise, neutral, transparent, and evidence-led.
- Clearly label facts, source claims, inference, and opinion.
- Treat uncertainty as useful information rather than something to hide.

## Thinking Approach:
1. Extract the central claim from the material supplied by the user.
2. Separate verified facts, attributed claims, inference, and commentary.
3. Evaluate whether sources are primary, independent, specific, and corroborated.
4. Check whether the headline or framing goes beyond the available evidence.
5. Identify missing context, alternative explanations, and what would verify the claim.
6. Give a provisional conclusion with an explicit confidence level.

## Methodology Toolbox:
- Discipline of Verification
- Source Independence
- Primary Versus Secondary Sources
- Fact-Opinion Separation
- Proportionality
- Transparency
- Missing Context
- Public-Interest Test

## Mandatory Answer Structure:
- **Core Claim**
- **Verified Facts**
- **Unverified Claims**
- **Source Quality**
- **Framing and Missing Context**
- **Confidence**
- **Conclusion**

## Constraints:
- Never declare a disputed claim true from one source alone.
- Never fabricate sources, quotations, dates, or corroboration.
- For developing news, limit conclusions to the material and timestamp provided.
- Do not make political endorsements.
- If the report or source material is missing, ask for it before evaluating.
- No tools, searches, or memory.

== Begin by applying the framework, without impersonating Bill Kovach ==
`);
const kotlerPrompt = withExpertContract(`
You are an AI advisor applying the publicly documented marketing frameworks associated with **Philip Kotler**. You are not Philip Kotler and must not imply endorsement or invent his views.

## Communication Style:
- Be customer-centered, commercially practical, and specific.
- Translate marketing jargon into plain language.
- Diagnose the market problem before suggesting promotion tactics.

## Thinking Approach:
1. Clarify the product, intended customer, competitive alternatives, and desired outcome.
2. Identify the customer need and the value offered in return.
3. Select at least 1 and at most 3 relevant frameworks from the toolbox and name them explicitly.
4. Diagnose the weakest part of segmentation, targeting, positioning, or the marketing mix.
5. Recommend one prioritized, low-cost experiment with a measurable success signal.

## Methodology Toolbox:
- Segmentation
- Targeting
- Positioning
- Customer Value
- Customer Needs
- Marketing Mix
- Competitive Alternatives
- Customer Journey
- Retention and Relationships

## Mandatory Answer Structure:
- **Marketing Problem**
- **Target Customer**
- **Relevant Framework(s)**
- **Value and Positioning**
- **Key Diagnosis**
- **Recommended Experiment**
- **Success Signal**
- **Conclusion**

## Constraints:
- Do not reduce marketing to advertising copy or channel tactics.
- Do not fabricate market size, customer research, conversion rates, or competitor facts.
- Do not promise growth outcomes.
- If essential context is missing, ask no more than two focused questions before analyzing.
- No tools, searches, or memory.

== Begin by applying the framework, without impersonating Philip Kotler ==
`);
const tukeyPrompt = withExpertContract(`
You are an AI advisor applying the publicly documented exploratory data analysis principles associated with **John Tukey**. You are not John Tukey and must not imply endorsement or invent his views.

## Communication Style:
- Be curious, concrete, visual, and resistant to premature conclusions.
- Explain statistical ideas in plain language.
- State what the data supports and what it cannot support.

## Thinking Approach:
1. Clarify the question the data is intended to answer.
2. Inspect the source, definitions, sample, missing values, and measurement quality.
3. Explore distributions and groups before relying on averages or a model.
4. Look for outliers, patterns, residuals, and plausible confounding factors.
5. Separate descriptive findings, hypotheses, and causal claims.
6. Recommend the next useful analysis, visualization, or data collection step.

## Methodology Toolbox:
- Exploratory Data Analysis
- Distribution Before Average
- Outlier Examination
- Robust Statistics
- Visualization
- Missing-Data Inspection
- Correlation Versus Causation
- Hypothesis Generation
- Residual Examination

## Mandatory Answer Structure:
- **Question**
- **Data Sufficiency**
- **Exploratory Findings**
- **Potential Problems**
- **What the Data Supports**
- **What the Data Does Not Support**
- **Next Analysis**

## Constraints:
- Do not pretend to analyze data that has not been supplied.
- Do not turn correlation into causation.
- Do not fabricate statistical significance, confidence intervals, or sample properties.
- If only a summary is supplied, state that the raw data quality cannot be checked.
- Ask no more than two focused questions when essential information is missing.
- No tools, searches, or memory.

== Begin by applying the framework, without impersonating John Tukey ==
`);
const createModePrompts = () => {
  const bookPrompts = {};
  Object.keys(booksPromptData).forEach((bookId) => {
    bookPrompts[`books-${bookId}`] = booksPromptData[bookId].prompt;
  });
  return {
    operator: operatorPrompt,
    researcher: researcherPrompt,
    lawyer: lawyerPrompt,
    trader: traderPrompt,
    math: mathPrompt,
    qa: qaPrompt,
    devops: devopsPrompt,
    code: codePrompt,
    health: HEALTH_PROMPT,
    wiki: WIKI_PROMPT,
    munger: MUNGER_PROMPT,
    marks: marksPrompt,
    kovach: kovachPrompt,
    kotler: kotlerPrompt,
    tukey: tukeyPrompt,
    dataAnalyst: dataAnalystPrompt,
    books: booksPromptData.happinessBook.prompt,
    // Default book prompt
    ...bookPrompts,
    // Spread all book-specific prompts
    notebooklm: studyGuidePrompt
  };
};
class PromptManager {
  constructor(tools) {
    __publicField(this, "tools");
    __publicField(this, "modePrompts");
    // Store the current page context
    __publicField(this, "currentPageContext", "");
    this.tools = tools;
    this.modePrompts = createModePrompts();
  }
  /**
   * Set the current page context
   */
  setCurrentPageContext(url, title) {
    this.currentPageContext = `You are currently on ${url} (${title}).
    
If the user's request seems to continue a previous task (like asking to "summarize options" after a search), interpret it in the context of what you've just been doing.

If the request seems to start a new task that requires going to a different website, you should navigate there on the new tab.

Use your judgment to determine whether the request is meant to be performed on the current page or requires navigation elsewhere.

Remember to follow the verification-first workflow: navigate → observe → analyze → act

## Special Commands:

- If request starts with:
  • #s-book → Call <tool>lookup_memories</tool> with the domain libgen.li  
  • #s-paper → Call <tool>lookup_memories</tool> with the domain arxiv.org  
  • #s-seed → Call <tool>lookup_memories</tool> with the domain 1lou.pro  
  • #f-movies → Call <tool>lookup_memories</tool> with the domain iyf.tv  
  • #f-sports → Call <tool>lookup_memories</tool> with the domain 88zhibo.tv
  • #scrape → Call <tool>start_extract</tool>

If a request matches any Special Command, skip planning and tool selection. Immediately emit the predefined tool call with its fixed arguments.`;
  }
  /**
   * Build the fixed system prompt for the agent.
   */
  getSystemPrompt(mode, subRole) {
    let basePrompt = this.modePrompts[mode];
    if (mode === "books" && subRole) {
      const bookPromptKey = `books-${subRole}`;
      basePrompt = this.modePrompts[bookPromptKey] || basePrompt;
    }
    console.log("basePrompt is ", basePrompt, mode, subRole);
    if (mode === "books" || EXPERT_ROLE_IDS.includes(mode)) {
      return basePrompt;
    }
    const toolDescriptions = this.tools.map((t) => `${t.name}: ${t.description}`).join("\n\n");
    const pageContextSection = this.currentPageContext ? `

## CURRENT PAGE CONTEXT
${this.currentPageContext}
` : "";
    return `${basePrompt}

You have access to these tools:

${toolDescriptions}${pageContextSection}

────────────────────────────────────────
${MULTITAB_OPERATION_INSTRUCTIONS}

────────────────────────────────────────
${CANONICAL_SEQUENCE}

────────────────────────────────────────
${MEMORY_FORMAT}

────────────────────────────────────────
Always wait for each tool result before the next step.  
Think step-by-step and finish with a concise summary.`;
  }
  /**
   * Update the tools used by the PromptManager
   */
  updateTools(tools) {
    this.tools = tools;
  }
}
class ToolManager {
  constructor(page, tools) {
    __publicField(this, "page");
    __publicField(this, "tools", []);
    // Flag to indicate if we should use tab tools exclusively
    __publicField(this, "useTabToolsOnly", false);
    // Additional tools that can be added dynamically
    __publicField(this, "additionalTools", []);
    this.page = page;
    this.tools = tools.map((tool) => {
      if (this.isTabTool(tool.name)) {
        return tool;
      }
      return this.wrapToolWithHealthCheck(tool);
    });
  }
  /**
   * Get all tools managed by this ToolManager
   */
  getTools() {
    return this.tools;
  }
  /**
   * Find a tool by name
   */
  findTool(toolName) {
    return this.tools.find((t) => t.name === toolName);
  }
  /**
   * Add additional tools dynamically
   */
  addTools(tools) {
    const wrappedTools = tools.map((tool) => this.wrapToolWithHealthCheck(tool));
    this.additionalTools = [...this.additionalTools, ...wrappedTools];
    this.tools = [...this.tools, ...wrappedTools];
  }
  /**
   * Remove all additional tools
   */
  clearAdditionalTools() {
    this.tools = this.tools.filter((tool) => !this.additionalTools.includes(tool));
    this.additionalTools = [];
  }
  /**
   * Get only the additional tools
   */
  getAdditionalTools() {
    return this.additionalTools;
  }
  /**
   * Check if the connection to the page is still healthy
   */
  async isConnectionHealthy() {
    if (!this.page) return false;
    try {
      await this.page.evaluate(() => true);
      this.useTabToolsOnly = false;
      return true;
    } catch (error) {
      console.log("Agent connection health check failed:", error);
      this.useTabToolsOnly = true;
      return false;
    }
  }
  /**
   * Check if a tool is a tab tool
   */
  isTabTool(toolName) {
    return toolName.startsWith("browser_tab_");
  }
  /**
   * Wrap a tool's function with a health check
   */
  wrapToolWithHealthCheck(tool) {
    const originalFunc = tool.func;
    const toolName = tool.name;
    const isTabTool = this.isTabTool(toolName);
    tool.func = async (input, context) => {
      try {
        if (!isTabTool && !await this.isConnectionHealthy()) {
          if (toolName === "browser_navigate") {
            return `Error: Debug session was closed. Please use browser_tab_new instead with the URL as input. Example: browser_tab_new | ${input}`;
          }
          if (toolName.includes("screenshot") || toolName.includes("read") || toolName.includes("title")) {
            return `Error: Debug session was closed. Please create a new tab first using browser_tab_new, then select it with browser_tab_select, and try again.`;
          }
          return "Error: Debug session was closed. Please use tab tools (browser_tab_new, browser_tab_select, etc.) to create and work with a new tab.";
        }
        return await originalFunc(input, context);
      } catch (error) {
        if (isTabTool) {
          return `Error executing ${toolName}: ${error instanceof Error ? error.message : String(error)}. Tab tools should still work even with a closed debug session. Try browser_tab_new to create a fresh tab.`;
        }
        const errorStr = String(error);
        if (errorStr.includes("closed") || errorStr.includes("detached") || errorStr.includes("destroyed")) {
          this.useTabToolsOnly = true;
          return `Error: Debug session appears to be closed. Please use tab tools (browser_tab_new, browser_tab_select, etc.) to create and work with a new tab.`;
        }
        return `Error executing tool: ${error instanceof Error ? error.message : String(error)}`;
      }
    };
    return tool;
  }
}
function parse(uuid) {
  if (!validate(uuid)) {
    throw TypeError("Invalid UUID");
  }
  var v;
  var arr = new Uint8Array(16);
  arr[0] = (v = parseInt(uuid.slice(0, 8), 16)) >>> 24;
  arr[1] = v >>> 16 & 255;
  arr[2] = v >>> 8 & 255;
  arr[3] = v & 255;
  arr[4] = (v = parseInt(uuid.slice(9, 13), 16)) >>> 8;
  arr[5] = v & 255;
  arr[6] = (v = parseInt(uuid.slice(14, 18), 16)) >>> 8;
  arr[7] = v & 255;
  arr[8] = (v = parseInt(uuid.slice(19, 23), 16)) >>> 8;
  arr[9] = v & 255;
  arr[10] = (v = parseInt(uuid.slice(24, 36), 16)) / 1099511627776 & 255;
  arr[11] = v / 4294967296 & 255;
  arr[12] = v >>> 24 & 255;
  arr[13] = v >>> 16 & 255;
  arr[14] = v >>> 8 & 255;
  arr[15] = v & 255;
  return arr;
}
function stringToBytes(str) {
  str = unescape(encodeURIComponent(str));
  var bytes = [];
  for (var i = 0; i < str.length; ++i) {
    bytes.push(str.charCodeAt(i));
  }
  return bytes;
}
var DNS = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
var URL$1 = "6ba7b811-9dad-11d1-80b4-00c04fd430c8";
function v35(name, version, hashfunc) {
  function generateUUID(value, namespace, buf, offset) {
    var _namespace;
    if (typeof value === "string") {
      value = stringToBytes(value);
    }
    if (typeof namespace === "string") {
      namespace = parse(namespace);
    }
    if (((_namespace = namespace) === null || _namespace === void 0 ? void 0 : _namespace.length) !== 16) {
      throw TypeError("Namespace must be array-like (16 iterable integer values, 0-255)");
    }
    var bytes = new Uint8Array(16 + value.length);
    bytes.set(namespace);
    bytes.set(value, namespace.length);
    bytes = hashfunc(bytes);
    bytes[6] = bytes[6] & 15 | version;
    bytes[8] = bytes[8] & 63 | 128;
    if (buf) {
      offset = offset || 0;
      for (var i = 0; i < 16; ++i) {
        buf[offset + i] = bytes[i];
      }
      return buf;
    }
    return unsafeStringify(bytes);
  }
  try {
    generateUUID.name = name;
  } catch (err) {
  }
  generateUUID.DNS = DNS;
  generateUUID.URL = URL$1;
  return generateUUID;
}
function f(s, x, y, z) {
  switch (s) {
    case 0:
      return x & y ^ ~x & z;
    case 1:
      return x ^ y ^ z;
    case 2:
      return x & y ^ x & z ^ y & z;
    case 3:
      return x ^ y ^ z;
  }
}
function ROTL(x, n) {
  return x << n | x >>> 32 - n;
}
function sha1(bytes) {
  var K = [1518500249, 1859775393, 2400959708, 3395469782];
  var H = [1732584193, 4023233417, 2562383102, 271733878, 3285377520];
  if (typeof bytes === "string") {
    var msg = unescape(encodeURIComponent(bytes));
    bytes = [];
    for (var i = 0; i < msg.length; ++i) {
      bytes.push(msg.charCodeAt(i));
    }
  } else if (!Array.isArray(bytes)) {
    bytes = Array.prototype.slice.call(bytes);
  }
  bytes.push(128);
  var l = bytes.length / 4 + 2;
  var N = Math.ceil(l / 16);
  var M = new Array(N);
  for (var _i = 0; _i < N; ++_i) {
    var arr = new Uint32Array(16);
    for (var j = 0; j < 16; ++j) {
      arr[j] = bytes[_i * 64 + j * 4] << 24 | bytes[_i * 64 + j * 4 + 1] << 16 | bytes[_i * 64 + j * 4 + 2] << 8 | bytes[_i * 64 + j * 4 + 3];
    }
    M[_i] = arr;
  }
  M[N - 1][14] = (bytes.length - 1) * 8 / Math.pow(2, 32);
  M[N - 1][14] = Math.floor(M[N - 1][14]);
  M[N - 1][15] = (bytes.length - 1) * 8 & 4294967295;
  for (var _i2 = 0; _i2 < N; ++_i2) {
    var W = new Uint32Array(80);
    for (var t = 0; t < 16; ++t) {
      W[t] = M[_i2][t];
    }
    for (var _t = 16; _t < 80; ++_t) {
      W[_t] = ROTL(W[_t - 3] ^ W[_t - 8] ^ W[_t - 14] ^ W[_t - 16], 1);
    }
    var a = H[0];
    var b = H[1];
    var c = H[2];
    var d = H[3];
    var e = H[4];
    for (var _t2 = 0; _t2 < 80; ++_t2) {
      var s = Math.floor(_t2 / 20);
      var T = ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[_t2] >>> 0;
      e = d;
      d = c;
      c = ROTL(b, 30) >>> 0;
      b = a;
      a = T;
    }
    H[0] = H[0] + a >>> 0;
    H[1] = H[1] + b >>> 0;
    H[2] = H[2] + c >>> 0;
    H[3] = H[3] + d >>> 0;
    H[4] = H[4] + e >>> 0;
  }
  return [H[0] >> 24 & 255, H[0] >> 16 & 255, H[0] >> 8 & 255, H[0] & 255, H[1] >> 24 & 255, H[1] >> 16 & 255, H[1] >> 8 & 255, H[1] & 255, H[2] >> 24 & 255, H[2] >> 16 & 255, H[2] >> 8 & 255, H[2] & 255, H[3] >> 24 & 255, H[3] >> 16 & 255, H[3] >> 8 & 255, H[3] & 255, H[4] >> 24 & 255, H[4] >> 16 & 255, H[4] >> 8 & 255, H[4] & 255];
}
var v5 = v35("v5", 80, sha1);
const browserClick = (page) => new DynamicTool({
  name: "browser_click",
  description: "Click an element. Input may be a CSS selector or literal text to match on the page.",
  func: async (input) => {
    try {
      return await withActivePage(page, async (activePage) => {
        if (/[#.[]/.test(input)) {
          await activePage.click(input);
          return `Clicked selector: ${input}`;
        }
        await activePage.getByText(input).click();
        return `Clicked element containing text: ${input}`;
      });
    } catch (error) {
      return `Error clicking '${input}': ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const browserType = (page) => new DynamicTool({
  name: "browser_type",
  description: 'Type text. Format: selector|text (e.g. input[name="q"]|hello)',
  func: async (input) => {
    try {
      return await withActivePage(page, async (activePage) => {
        const [selector, text] = input.split("|");
        if (!selector || !text) {
          return "Error: expected 'selector|text'";
        }
        await activePage.fill(selector, text);
        return `Typed "${text}" into ${selector}`;
      });
    } catch (error) {
      return `Error typing into '${input}': ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const browserHandleDialog = (page) => {
  installDialogListener(page);
  return new DynamicTool({
    name: "browser_handle_dialog",
    description: "Accept or dismiss the most recent alert/confirm/prompt dialog.\nInput `accept` or `dismiss`. For prompt dialogs you may append `|text` to supply response text.",
    func: async (input) => {
      try {
        if (!lastDialog)
          return "Error: no dialog is currently open or was detected.";
        const [action, text] = input.split("|").map((s) => s.trim().toLowerCase());
        if (action !== "accept" && action !== "dismiss")
          return "Error: first part must be `accept` or `dismiss`.";
        if (action === "accept")
          await lastDialog.accept(text || void 0);
        else await lastDialog.dismiss();
        const type = lastDialog.type();
        resetDialog();
        return `${action === "accept" ? "Accepted" : "Dismissed"} ${type} dialog.`;
      } catch (err) {
        return `Error handling dialog: ${err instanceof Error ? err.message : String(err)}`;
      }
    }
  });
};
const browserPressKey = (page) => new DynamicTool({
  name: "browser_press_key",
  description: "Press a single key. Input is the key name (e.g. `Enter`, `ArrowLeft`, `a`).",
  func: async (key) => {
    try {
      return await withActivePage(page, async (activePage) => {
        if (!key.trim()) return "Error: key name required";
        await activePage.keyboard.press(key.trim());
        return `Pressed key: ${key.trim()}`;
      });
    } catch (err) {
      return `Error pressing key '${key}': ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserKeyboardType = (page) => new DynamicTool({
  name: "browser_keyboard_type",
  description: "Type arbitrary text at the current focus location. Input is the literal text to type. Use `\\n` for new lines.",
  func: async (text) => {
    try {
      return await withActivePage(page, async (activePage) => {
        await activePage.keyboard.type(text);
        return `Typed ${text.length} characters`;
      });
    } catch (err) {
      return `Error typing text: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
function saveMemory(page) {
  return {
    name: "save_memory",
    description: "Save a memory of how to accomplish a specific task on a website. Use this when you want to remember a useful sequence of actions for future reference.",
    func: async (input) => {
      try {
        const inputObj = JSON.parse(input);
        const { taskDescription, toolSequence } = inputObj;
        let { domain } = inputObj;
        if (!domain || !taskDescription || !toolSequence) {
          return "Error: Missing required fields. Please provide domain, taskDescription, and toolSequence.";
        }
        domain = normalizeDomain(domain);
        if (!domain) {
          return "Error: Invalid domain provided.";
        }
        const memory2 = {
          domain,
          taskDescription,
          toolSequence,
          createdAt: Date.now()
        };
        const memoryService = MemoryService.getInstance();
        const id = await memoryService.storeMemory(memory2);
        return `Memory saved successfully with ID: ${id}`;
      } catch (error) {
        logWithTimestamp(`Error saving memory: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error saving memory: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function lookupMemories(page) {
  return {
    name: "lookup_memories",
    description: "Look up stored memories for a specific website domain. Use this as your FIRST step when starting a task on a website to check if there are any saved patterns you can reuse. Always call this with the current domain (e.g., 'www.google.com').",
    func: async (input) => {
      try {
        let domain = input.trim();
        domain = normalizeDomain(domain);
        if (!domain) {
          return "Error: Please provide a valid domain to lookup memories for.";
        }
        const memoryService = MemoryService.getInstance();
        const memories = await memoryService.getMemoriesByDomain(domain);
        if (memories.length === 0) {
          return `No memories found for domain: ${domain}`;
        }
        memories.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        const formattedMemories = memories.map((memory2) => ({
          domain: memory2.domain,
          taskDescription: memory2.taskDescription,
          toolSequence: memory2.toolSequence,
          createdAt: memory2.createdAt ? new Date(memory2.createdAt).toISOString() : "unknown"
        }));
        return JSON.stringify(formattedMemories, null, 2);
      } catch (error) {
        logWithTimestamp(`Error looking up memories: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error looking up memories: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function getAllMemories(page) {
  return {
    name: "get_all_memories",
    description: "Retrieve all stored memories across all domains. Use this when you want to see all available memories.",
    func: async () => {
      try {
        const memoryService = MemoryService.getInstance();
        const memories = await memoryService.getAllMemories();
        if (memories.length === 0) {
          return "No memories found.";
        }
        return JSON.stringify(memories, null, 2);
      } catch (error) {
        logWithTimestamp(`Error retrieving all memories: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error retrieving all memories: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function deleteMemory(page) {
  return {
    name: "delete_memory",
    description: "Delete a specific memory by its ID. Use this when a memory is no longer useful or accurate.",
    func: async (input) => {
      try {
        const id = parseInt(input.trim(), 10);
        if (isNaN(id)) {
          return "Error: Please provide a valid numeric ID.";
        }
        const memoryService = MemoryService.getInstance();
        await memoryService.deleteMemory(id);
        return `Memory with ID ${id} deleted successfully.`;
      } catch (error) {
        logWithTimestamp(`Error deleting memory: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error deleting memory: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function clearAllMemories(page) {
  return {
    name: "clear_all_memories",
    description: "Clear all stored memories. Use this with caution as it will delete all memories across all domains.",
    func: async () => {
      try {
        const memoryService = MemoryService.getInstance();
        await memoryService.clearMemories();
        return "All memories cleared successfully.";
      } catch (error) {
        logWithTimestamp(`Error clearing memories: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error clearing memories: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
const _VectorService = class _VectorService {
  constructor() {
    __publicField(this, "db", null);
    __publicField(this, "dbName", "BrowserBeeVectorDB");
    __publicField(this, "dbVersion", 1);
    __publicField(this, "documentsStore", "documents");
    __publicField(this, "collectionsStore", "collections");
  }
  /**
   * Get singleton instance of VectorService
   */
  static getInstance() {
    if (!_VectorService.instance) {
      _VectorService.instance = new _VectorService();
    }
    return _VectorService.instance;
  }
  /**
   * Initialize the IndexedDB database
   */
  async initDB() {
    if (this.db) {
      return this.db;
    }
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion);
      request.onerror = () => {
        logWithTimestamp("Failed to open vector database", "error");
        reject(new Error("Failed to open vector database"));
      };
      request.onsuccess = () => {
        this.db = request.result;
        logWithTimestamp("Vector database opened successfully");
        resolve(this.db);
      };
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(this.documentsStore)) {
          const documentsStore = db.createObjectStore(this.documentsStore, {
            keyPath: "id",
            autoIncrement: true
          });
          documentsStore.createIndex("collectionName", "collectionName", { unique: false });
          documentsStore.createIndex("documentId", "documentId", { unique: false });
          documentsStore.createIndex("collectionDocId", ["collectionName", "documentId"], { unique: true });
        }
        if (!db.objectStoreNames.contains(this.collectionsStore)) {
          db.createObjectStore(this.collectionsStore, {
            keyPath: "name"
          });
        }
        logWithTimestamp("Vector database schema created");
      };
    });
  }
  /**
   * Calculate cosine similarity between two vectors
   */
  cosineSimilarity(a, b) {
    if (a.length !== b.length) {
      throw new Error("Vectors must have the same dimension");
    }
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < a.length; i++) {
      dotProduct += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    normA = Math.sqrt(normA);
    normB = Math.sqrt(normB);
    if (normA === 0 || normB === 0) {
      return 0;
    }
    return dotProduct / (normA * normB);
  }
  /**
   * Create or update a collection
   */
  async createCollection(name, dimension) {
    const db = await this.initDB();
    const transaction = db.transaction([this.collectionsStore], "readwrite");
    const store = transaction.objectStore(this.collectionsStore);
    const collection = {
      name,
      dimension,
      documentCount: 0,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    return new Promise((resolve, reject) => {
      const request = store.put(collection);
      request.onsuccess = () => {
        logWithTimestamp(`Collection '${name}' created successfully`);
        resolve();
      };
      request.onerror = () => {
        logWithTimestamp(`Failed to create collection '${name}'`, "error");
        reject(new Error(`Failed to create collection '${name}'`));
      };
    });
  }
  /**
   * Get collection metadata
   */
  async getCollection(name) {
    const db = await this.initDB();
    const transaction = db.transaction([this.collectionsStore], "readonly");
    const store = transaction.objectStore(this.collectionsStore);
    return new Promise((resolve, reject) => {
      const request = store.get(name);
      request.onsuccess = () => {
        resolve(request.result || null);
      };
      request.onerror = () => {
        reject(new Error(`Failed to get collection '${name}'`));
      };
    });
  }
  /**
   * List all collections
   */
  async listCollections() {
    const db = await this.initDB();
    const transaction = db.transaction([this.collectionsStore], "readonly");
    const store = transaction.objectStore(this.collectionsStore);
    return new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => {
        resolve(request.result);
      };
      request.onerror = () => {
        reject(new Error("Failed to list collections"));
      };
    });
  }
  /**
   * Delete a collection and all its documents
   */
  async deleteCollection(name) {
    const db = await this.initDB();
    const transaction = db.transaction([this.collectionsStore, this.documentsStore], "readwrite");
    const collectionsStore = transaction.objectStore(this.collectionsStore);
    const documentsStore = transaction.objectStore(this.documentsStore);
    const index = documentsStore.index("collectionName");
    const range = IDBKeyRange.only(name);
    return new Promise((resolve, reject) => {
      const documentRequest = index.openCursor(range);
      const documentsToDelete = [];
      documentRequest.onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor) {
          documentsToDelete.push(cursor.primaryKey);
          cursor.continue();
        } else {
          documentsToDelete.forEach((key) => documentsStore.delete(key));
          const collectionRequest = collectionsStore.delete(name);
          collectionRequest.onsuccess = () => {
            logWithTimestamp(`Collection '${name}' and ${documentsToDelete.length} documents deleted`);
            resolve();
          };
          collectionRequest.onerror = () => {
            reject(new Error(`Failed to delete collection '${name}'`));
          };
        }
      };
      documentRequest.onerror = () => {
        reject(new Error(`Failed to delete documents from collection '${name}'`));
      };
    });
  }
  /**
   * Store or update a document with its embedding
   */
  async storeDocument(collectionName, documentId, content, embedding, metadata) {
    const db = await this.initDB();
    const collection = await this.getCollection(collectionName);
    if (!collection) {
      throw new Error(`Collection '${collectionName}' does not exist. Create it first.`);
    }
    if (embedding.length !== collection.dimension) {
      throw new Error(
        `Embedding dimension (${embedding.length}) does not match collection dimension (${collection.dimension})`
      );
    }
    const transaction = db.transaction([this.documentsStore, this.collectionsStore], "readwrite");
    const documentsStore = transaction.objectStore(this.documentsStore);
    const collectionsStore = transaction.objectStore(this.collectionsStore);
    const index = documentsStore.index("collectionDocId");
    const existingRequest = index.get([collectionName, documentId]);
    return new Promise((resolve, reject) => {
      existingRequest.onsuccess = () => {
        const existing = existingRequest.result;
        const now = Date.now();
        const document2 = {
          collectionName,
          documentId,
          content,
          embedding,
          metadata,
          createdAt: existing ? existing.createdAt : now,
          updatedAt: now
        };
        if (existing) {
          document2.id = existing.id;
        }
        const storeRequest = documentsStore.put(document2);
        storeRequest.onsuccess = () => {
          if (!existing) {
            const collectionRequest = collectionsStore.get(collectionName);
            collectionRequest.onsuccess = () => {
              const coll = collectionRequest.result;
              coll.documentCount += 1;
              coll.updatedAt = now;
              collectionsStore.put(coll);
            };
          }
          const id = storeRequest.result;
          logWithTimestamp(`Document '${documentId}' stored in collection '${collectionName}'`);
          resolve(id);
        };
        storeRequest.onerror = () => {
          reject(new Error(`Failed to store document '${documentId}'`));
        };
      };
      existingRequest.onerror = () => {
        reject(new Error(`Failed to check existing document '${documentId}'`));
      };
    });
  }
  /**
   * Search for similar documents using cosine similarity
   */
  async searchSimilar(collectionName, queryEmbedding, topK = 5, minScore = 0) {
    const db = await this.initDB();
    const collection = await this.getCollection(collectionName);
    if (!collection) {
      throw new Error(`Collection '${collectionName}' does not exist`);
    }
    if (queryEmbedding.length !== collection.dimension) {
      throw new Error(
        `Query embedding dimension (${queryEmbedding.length}) does not match collection dimension (${collection.dimension})`
      );
    }
    const transaction = db.transaction([this.documentsStore], "readonly");
    const store = transaction.objectStore(this.documentsStore);
    const index = store.index("collectionName");
    const range = IDBKeyRange.only(collectionName);
    return new Promise((resolve, reject) => {
      const request = index.getAll(range);
      request.onsuccess = () => {
        const documents = request.result;
        const results = documents.map((doc) => ({
          documentId: doc.documentId,
          content: doc.content,
          metadata: doc.metadata,
          score: this.cosineSimilarity(queryEmbedding, doc.embedding)
        })).filter((result) => result.score >= minScore).sort((a, b) => b.score - a.score).slice(0, topK);
        logWithTimestamp(`Found ${results.length} similar documents in collection '${collectionName}'`);
        resolve(results);
      };
      request.onerror = () => {
        reject(new Error(`Failed to search in collection '${collectionName}'`));
      };
    });
  }
  /**
   * Get a specific document by ID
   */
  async getDocument(collectionName, documentId) {
    const db = await this.initDB();
    const transaction = db.transaction([this.documentsStore], "readonly");
    const store = transaction.objectStore(this.documentsStore);
    const index = store.index("collectionDocId");
    return new Promise((resolve, reject) => {
      const request = index.get([collectionName, documentId]);
      request.onsuccess = () => {
        resolve(request.result || null);
      };
      request.onerror = () => {
        reject(new Error(`Failed to get document '${documentId}'`));
      };
    });
  }
  /**
   * Delete a specific document
   */
  async deleteDocument(collectionName, documentId) {
    const db = await this.initDB();
    const transaction = db.transaction([this.documentsStore, this.collectionsStore], "readwrite");
    const documentsStore = transaction.objectStore(this.documentsStore);
    const collectionsStore = transaction.objectStore(this.collectionsStore);
    const index = documentsStore.index("collectionDocId");
    return new Promise((resolve, reject) => {
      const request = index.getKey([collectionName, documentId]);
      request.onsuccess = () => {
        const key = request.result;
        if (!key) {
          reject(new Error(`Document '${documentId}' not found in collection '${collectionName}'`));
          return;
        }
        const deleteRequest = documentsStore.delete(key);
        deleteRequest.onsuccess = () => {
          const collectionRequest = collectionsStore.get(collectionName);
          collectionRequest.onsuccess = () => {
            const coll = collectionRequest.result;
            coll.documentCount = Math.max(0, coll.documentCount - 1);
            coll.updatedAt = Date.now();
            collectionsStore.put(coll);
          };
          logWithTimestamp(`Document '${documentId}' deleted from collection '${collectionName}'`);
          resolve();
        };
        deleteRequest.onerror = () => {
          reject(new Error(`Failed to delete document '${documentId}'`));
        };
      };
      request.onerror = () => {
        reject(new Error(`Failed to find document '${documentId}'`));
      };
    });
  }
  /**
   * Get all documents in a collection
   */
  async getDocumentsByCollection(collectionName) {
    const db = await this.initDB();
    const transaction = db.transaction([this.documentsStore], "readonly");
    const store = transaction.objectStore(this.documentsStore);
    const index = store.index("collectionName");
    const range = IDBKeyRange.only(collectionName);
    return new Promise((resolve, reject) => {
      const request = index.getAll(range);
      request.onsuccess = () => {
        resolve(request.result);
      };
      request.onerror = () => {
        reject(new Error(`Failed to get documents from collection '${collectionName}'`));
      };
    });
  }
  /**
   * Clear all data from the database
   */
  async clearAll() {
    const db = await this.initDB();
    const transaction = db.transaction([this.documentsStore, this.collectionsStore], "readwrite");
    const documentsStore = transaction.objectStore(this.documentsStore);
    const collectionsStore = transaction.objectStore(this.collectionsStore);
    return new Promise((resolve, reject) => {
      const documentsRequest = documentsStore.clear();
      const collectionsRequest = collectionsStore.clear();
      let completed = 0;
      const checkComplete = () => {
        completed++;
        if (completed === 2) {
          logWithTimestamp("All vector database data cleared");
          resolve();
        }
      };
      documentsRequest.onsuccess = checkComplete;
      collectionsRequest.onsuccess = checkComplete;
      documentsRequest.onerror = () => reject(new Error("Failed to clear documents"));
      collectionsRequest.onerror = () => reject(new Error("Failed to clear collections"));
    });
  }
};
__publicField(_VectorService, "instance", null);
let VectorService = _VectorService;
function createVectorCollection(page) {
  return {
    name: "vector_create_collection",
    description: "Create a new vector collection to store embeddings. You must specify the collection name and embedding dimension (e.g., 384 for sentence transformers, 1536 for OpenAI embeddings). Use this before storing any vectors.",
    func: async (input) => {
      try {
        const inputObj = JSON.parse(input);
        const { collectionName, dimension } = inputObj;
        if (!collectionName || !dimension) {
          return "Error: Missing required fields. Please provide collectionName and dimension.";
        }
        if (typeof dimension !== "number" || dimension <= 0) {
          return "Error: Dimension must be a positive number.";
        }
        const vectorService = VectorService.getInstance();
        await vectorService.createCollection(collectionName, dimension);
        return `Vector collection '${collectionName}' created successfully with dimension ${dimension}.`;
      } catch (error) {
        logWithTimestamp(`Error creating vector collection: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error creating vector collection: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function listVectorCollections(page) {
  return {
    name: "vector_list_collections",
    description: "List all vector collections with their metadata (name, dimension, document count, timestamps). Use this to see what collections are available.",
    func: async () => {
      try {
        const vectorService = VectorService.getInstance();
        const collections = await vectorService.listCollections();
        if (collections.length === 0) {
          return "No vector collections found.";
        }
        return JSON.stringify(collections.map((c) => ({
          name: c.name,
          dimension: c.dimension,
          documentCount: c.documentCount,
          createdAt: new Date(c.createdAt).toISOString(),
          updatedAt: new Date(c.updatedAt).toISOString()
        })), null, 2);
      } catch (error) {
        logWithTimestamp(`Error listing vector collections: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error listing vector collections: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function deleteVectorCollection(page) {
  return {
    name: "vector_delete_collection",
    description: "Delete a vector collection and all its documents. This operation is irreversible. Input should be the collection name as a string.",
    func: async (input) => {
      try {
        const collectionName = input.trim();
        if (!collectionName) {
          return "Error: Please provide a collection name.";
        }
        const vectorService = VectorService.getInstance();
        await vectorService.deleteCollection(collectionName);
        return `Vector collection '${collectionName}' and all its documents deleted successfully.`;
      } catch (error) {
        logWithTimestamp(`Error deleting vector collection: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error deleting vector collection: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function storeVector(page) {
  return {
    name: "vector_store",
    description: "Store a document with its embedding vector in a collection. Requires collectionName, documentId, content (text), embedding (array of numbers), and optional metadata (object). If a document with the same ID exists, it will be updated.",
    func: async (input) => {
      try {
        const inputObj = JSON.parse(input);
        const { collectionName, documentId, content, embedding, metadata } = inputObj;
        if (!collectionName || !documentId || !content || !embedding) {
          return "Error: Missing required fields. Please provide collectionName, documentId, content, and embedding.";
        }
        if (!Array.isArray(embedding)) {
          return "Error: Embedding must be an array of numbers.";
        }
        if (embedding.some((val) => typeof val !== "number")) {
          return "Error: All embedding values must be numbers.";
        }
        const vectorService = VectorService.getInstance();
        const id = await vectorService.storeDocument(
          collectionName,
          documentId,
          content,
          embedding,
          metadata
        );
        return `Document '${documentId}' stored successfully in collection '${collectionName}' with ID ${id}.`;
      } catch (error) {
        logWithTimestamp(`Error storing vector: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error storing vector: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function searchVectors(page) {
  return {
    name: "vector_search",
    description: "Search for similar documents using cosine similarity. Requires collectionName and queryEmbedding (array of numbers). Optional: topK (number of results, default 5) and minScore (minimum similarity score 0-1, default 0.0). Returns documents with similarity scores.",
    func: async (input) => {
      try {
        const inputObj = JSON.parse(input);
        const { collectionName, queryEmbedding, topK, minScore } = inputObj;
        console.log("vector_search", queryEmbedding, inputObj);
        if (!collectionName || !queryEmbedding) {
          return "Error: Missing required fields. Please provide collectionName and queryEmbedding.";
        }
        if (!Array.isArray(queryEmbedding)) {
          return "Error: queryEmbedding must be an array of numbers.";
        }
        if (queryEmbedding.some((val) => typeof val !== "number")) {
          return "Error: All queryEmbedding values must be numbers.";
        }
        const k = topK || 5;
        const threshold = minScore || 0;
        const vectorService = VectorService.getInstance();
        const results = await vectorService.searchSimilar(
          collectionName,
          queryEmbedding,
          k,
          threshold
        );
        if (results.length === 0) {
          return `No similar documents found in collection '${collectionName}'.`;
        }
        return JSON.stringify(results.map((r) => ({
          documentId: r.documentId,
          content: r.content,
          score: r.score.toFixed(4),
          metadata: r.metadata
        })), null, 2);
      } catch (error) {
        logWithTimestamp(`Error searching vectors: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error searching vectors: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function getVectorDocument(page) {
  return {
    name: "vector_get_document",
    description: "Retrieve a specific document by its ID from a collection. Requires collectionName and documentId. Returns the full document including content, embedding, and metadata.",
    func: async (input) => {
      try {
        const inputObj = JSON.parse(input);
        const { collectionName, documentId } = inputObj;
        if (!collectionName || !documentId) {
          return "Error: Missing required fields. Please provide collectionName and documentId.";
        }
        const vectorService = VectorService.getInstance();
        const document2 = await vectorService.getDocument(collectionName, documentId);
        if (!document2) {
          return `Document '${documentId}' not found in collection '${collectionName}'.`;
        }
        return JSON.stringify({
          documentId: document2.documentId,
          content: document2.content,
          metadata: document2.metadata,
          embeddingDimension: document2.embedding.length,
          createdAt: new Date(document2.createdAt).toISOString(),
          updatedAt: new Date(document2.updatedAt).toISOString()
        }, null, 2);
      } catch (error) {
        logWithTimestamp(`Error getting document: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error getting document: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function deleteVectorDocument(page) {
  return {
    name: "vector_delete_document",
    description: "Delete a specific document from a collection. Requires collectionName and documentId. This operation is irreversible.",
    func: async (input) => {
      try {
        const inputObj = JSON.parse(input);
        const { collectionName, documentId } = inputObj;
        if (!collectionName || !documentId) {
          return "Error: Missing required fields. Please provide collectionName and documentId.";
        }
        const vectorService = VectorService.getInstance();
        await vectorService.deleteDocument(collectionName, documentId);
        return `Document '${documentId}' deleted successfully from collection '${collectionName}'.`;
      } catch (error) {
        logWithTimestamp(`Error deleting document: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error deleting document: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function listVectorDocuments(page) {
  return {
    name: "vector_list_documents",
    description: "List all documents in a collection with their metadata (excluding full embeddings for brevity). Input should be the collection name as a string.",
    func: async (input) => {
      try {
        const collectionName = input.trim();
        if (!collectionName) {
          return "Error: Please provide a collection name.";
        }
        const vectorService = VectorService.getInstance();
        const documents = await vectorService.getDocumentsByCollection(collectionName);
        if (documents.length === 0) {
          return `No documents found in collection '${collectionName}'.`;
        }
        return JSON.stringify(documents.map((doc) => ({
          documentId: doc.documentId,
          content: doc.content.substring(0, 100) + (doc.content.length > 100 ? "..." : ""),
          metadata: doc.metadata,
          embeddingDimension: doc.embedding.length,
          createdAt: new Date(doc.createdAt).toISOString(),
          updatedAt: new Date(doc.updatedAt).toISOString()
        })), null, 2);
      } catch (error) {
        logWithTimestamp(`Error listing documents: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error listing documents: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function clearAllVectorData(page) {
  return {
    name: "vector_clear_all",
    description: "Clear all vector collections and documents from the database. This operation is irreversible and should be used with extreme caution. No input required.",
    func: async () => {
      try {
        const vectorService = VectorService.getInstance();
        await vectorService.clearAll();
        return "All vector data cleared successfully.";
      } catch (error) {
        logWithTimestamp(`Error clearing vector data: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error clearing vector data: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
const KNOWLEDGE_NAMESPACE = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
class KnowledgeMetaData {
  constructor(content = "", label = "", embedding = null, identity) {
    __publicField(this, "id");
    __publicField(this, "content");
    __publicField(this, "label");
    __publicField(this, "embedding");
    __publicField(this, "trunks");
    __publicField(this, "trunksEmbedding");
    this.content = content;
    this.label = label;
    this.embedding = embedding;
    this.trunks = [];
    this.trunksEmbedding = [];
    if (identity !== void 0) {
      this.id = identity;
    } else {
      this.id = v5(content, KNOWLEDGE_NAMESPACE);
    }
  }
  /**
   * Split content into chunks/trunks for better processing
   * Similar to RD-Agent's split_into_trunk
   */
  splitIntoTrunks(size = 1e3, overlap = 0) {
    const chunks = [];
    const step = size - overlap;
    for (let i = 0; i < this.content.length; i += step) {
      const chunk = this.content.slice(i, i + size);
      chunks.push(chunk);
    }
    this.trunks = chunks;
    logWithTimestamp(`Split content into ${chunks.length} trunks`, "log");
  }
  /**
   * Create embedding for the content
   * Note: This is a placeholder - actual embedding generation should be implemented
   * by the LLM provider (OpenAI, etc.)
   */
  async createEmbedding(embeddingFn) {
    if (this.embedding !== null) {
      return;
    }
    if (!embeddingFn) {
      logWithTimestamp("No embedding function provided", "warn");
      return;
    }
    try {
      this.embedding = await embeddingFn(this.content);
      logWithTimestamp(`Created embedding for content (dim: ${this.embedding.length})`, "log");
    } catch (error) {
      logWithTimestamp(`Error creating embedding: ${error}`, "error");
      throw error;
    }
  }
  /**
   * Create embeddings for all trunks
   */
  async createTrunksEmbeddings(embeddingFn) {
    if (this.trunks.length === 0) {
      logWithTimestamp("No trunks to create embeddings for", "warn");
      return;
    }
    try {
      this.trunksEmbedding = await embeddingFn(this.trunks);
      logWithTimestamp(`Created embeddings for ${this.trunks.length} trunks`, "log");
    } catch (error) {
      logWithTimestamp(`Error creating trunk embeddings: ${error}`, "error");
      throw error;
    }
  }
  /**
   * Create from a dictionary/object
   */
  fromDict(data) {
    Object.assign(this, data);
    return this;
  }
  /**
   * Convert to plain object for serialization
   */
  toDict() {
    return {
      id: this.id,
      content: this.content,
      label: this.label,
      embedding: this.embedding,
      trunks: this.trunks,
      trunksEmbedding: this.trunksEmbedding
    };
  }
  toString() {
    return `KnowledgeMetaData(id=${this.id}, label=${this.label}, content=${this.content.substring(0, 100)}...)`;
  }
  repr() {
    return this.toString();
  }
}
function cosineSimilarity(a, b) {
  if (a.length !== b.length) {
    throw new Error("Vectors must have the same dimension");
  }
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  normA = Math.sqrt(normA);
  normB = Math.sqrt(normB);
  if (normA === 0 || normB === 0) {
    return 0;
  }
  return dotProduct / (normA * normB);
}
function cosineDistance(a, b) {
  return 1 - cosineSimilarity(a, b);
}
class VectorBase {
}
class MemoryVectorBase extends VectorBase {
  constructor() {
    super();
    __publicField(this, "vectorData");
    this.vectorData = [];
  }
  /**
   * Get shape of the vector store [rows, columns]
   */
  shape() {
    return [this.vectorData.length, 5];
  }
  /**
   * Add document(s) to the vector store
   * Each document can have multiple rows (one for full content + one per trunk)
   */
  async add(document2) {
    if (Array.isArray(document2)) {
      for (const doc of document2) {
        await this.add(doc);
      }
      return;
    }
    if (document2.embedding === null) {
      logWithTimestamp(`Document ${document2.id} has no embedding, skipping`, "warn");
      return;
    }
    const mainRow = {
      id: document2.id,
      label: document2.label,
      content: document2.content,
      trunk: document2.content,
      embedding: document2.embedding
    };
    this.vectorData.push(mainRow);
    if (document2.trunks.length > 0 && document2.trunksEmbedding.length > 0) {
      for (let i = 0; i < document2.trunks.length; i++) {
        const trunkRow = {
          id: document2.id,
          label: document2.label,
          content: document2.content,
          trunk: document2.trunks[i],
          embedding: document2.trunksEmbedding[i]
        };
        this.vectorData.push(trunkRow);
      }
    }
    logWithTimestamp(
      `Added document ${document2.id} with ${1 + document2.trunks.length} rows`,
      "log"
    );
  }
  /**
   * Search for similar documents using cosine similarity
   * Returns both documents and their similarity scores
   */
  async search(content, topK = null, similarityThreshold = 0, constraintLabels = null) {
    if (this.vectorData.length === 0) {
      return [[], []];
    }
    const queryDoc = new KnowledgeMetaData(content);
    if (queryDoc.embedding === null) {
      logWithTimestamp("Query document has no embedding", "warn");
      return [[], []];
    }
    let filteredData = this.vectorData;
    if (constraintLabels !== null && constraintLabels.length > 0) {
      filteredData = this.vectorData.filter(
        (row) => constraintLabels.includes(row.label)
      );
    }
    if (filteredData.length === 0) {
      return [[], []];
    }
    const similarities = filteredData.map((row) => {
      return 1 - cosineDistance(row.embedding, queryDoc.embedding);
    });
    const indexedSimilarities = similarities.map((score, index) => ({ index, score })).filter((item) => item.score > similarityThreshold);
    indexedSimilarities.sort((a, b) => b.score - a.score);
    const topResults = topK !== null ? indexedSimilarities.slice(0, topK) : indexedSimilarities;
    const docs = [];
    const scores = [];
    for (const { index, score } of topResults) {
      const row = filteredData[index];
      const doc = new KnowledgeMetaData();
      doc.fromDict({
        id: row.id,
        label: row.label,
        content: row.content,
        embedding: row.embedding
      });
      docs.push(doc);
      scores.push(score);
    }
    return [docs, scores];
  }
  /**
   * Clear all data
   */
  clear() {
    this.vectorData = [];
    logWithTimestamp("VectorBase cleared", "log");
  }
  /**
   * Get all documents (for debugging/inspection)
   */
  getAllRows() {
    return [...this.vectorData];
  }
  /**
   * Get unique document IDs
   */
  getUniqueDocumentIds() {
    const ids = new Set(this.vectorData.map((row) => row.id));
    return Array.from(ids);
  }
  /**
   * Get all unique labels
   */
  getUniqueLabels() {
    const labels = new Set(this.vectorData.map((row) => row.label));
    return Array.from(labels);
  }
  /**
   * Remove a document by ID
   */
  removeDocument(docId) {
    this.vectorData = this.vectorData.filter((row) => row.id !== docId);
    logWithTimestamp(`Removed document ${docId}`, "log");
  }
  /**
   * Get document by ID (returns first matching row)
   */
  getDocumentById(docId) {
    const row = this.vectorData.find((r) => r.id === docId);
    if (!row) return null;
    const doc = new KnowledgeMetaData();
    doc.fromDict({
      id: row.id,
      label: row.label,
      content: row.content,
      embedding: row.embedding
    });
    return doc;
  }
  /**
   * Count documents (unique IDs)
   */
  countDocuments() {
    return this.getUniqueDocumentIds().length;
  }
  /**
   * Export data for persistence
   */
  exportData() {
    return this.vectorData.map((row) => ({ ...row }));
  }
  /**
   * Import data from persistence
   */
  importData(data) {
    this.vectorData = data.map((row) => ({ ...row }));
    logWithTimestamp(`Imported ${data.length} rows`, "log");
  }
}
class UndirectedNode extends KnowledgeMetaData {
  constructor(content = "", label = "", embedding = null, appendix = null) {
    super(content, label, embedding);
    __publicField(this, "neighbors");
    __publicField(this, "appendix");
    this.neighbors = /* @__PURE__ */ new Set();
    this.appendix = appendix;
    if (typeof content !== "string") {
      throw new Error("Content must be a string");
    }
  }
  /**
   * Add bidirectional edge to another node
   */
  addNeighbor(node) {
    this.neighbors.add(node);
    node.neighbors.add(this);
  }
  /**
   * Remove bidirectional edge from another node
   */
  removeNeighbor(node) {
    if (this.neighbors.has(node)) {
      this.neighbors.delete(node);
      node.neighbors.delete(this);
    }
  }
  /**
   * Get all neighbors
   */
  getNeighbors() {
    return this.neighbors;
  }
  toString() {
    const neighborIds = Array.from(this.neighbors).map((n) => n.id).join(", ");
    return `UndirectedNode(id=${this.id}, label=${this.label}, content=${this.content.substring(0, 100)}, neighbors=[${neighborIds}])`;
  }
  repr() {
    return this.toString();
  }
}
class Graph {
  constructor() {
    __publicField(this, "nodes");
    this.nodes = /* @__PURE__ */ new Map();
  }
  /**
   * Get the number of nodes in the graph
   */
  size() {
    return this.nodes.size;
  }
  /**
   * Get a node by ID
   */
  getNode(nodeId) {
    return this.nodes.get(nodeId) || null;
  }
  /**
   * Get all nodes in the graph
   */
  getAllNodes() {
    return Array.from(this.nodes.values());
  }
  /**
   * Get all nodes by label list
   */
  getAllNodesByLabelList(labelList) {
    return Array.from(this.nodes.values()).filter(
      (node) => labelList.includes(node.label)
    );
  }
  /**
   * Find a node by content and label
   */
  findNode(content, label) {
    for (const node of this.nodes.values()) {
      if (node.content === content && node.label === label) {
        return node;
      }
    }
    return null;
  }
  /**
   * Batch create embeddings for nodes
   */
  static async batchEmbedding(nodes, embeddingFn) {
    const contents = nodes.map((node) => node.content);
    const batchSize = 16;
    const allEmbeddings = [];
    for (let i = 0; i < contents.length; i += batchSize) {
      const batch = contents.slice(i, Math.min(i + batchSize, contents.length));
      logWithTimestamp(
        `Creating embedding for index ${i} to ${i + batch.length} with ${contents.length} contents`,
        "log"
      );
      const embeddings = await embeddingFn(batch);
      allEmbeddings.push(...embeddings);
    }
    if (nodes.length !== allEmbeddings.length) {
      throw new Error("Nodes length must equal embeddings length");
    }
    for (let i = 0; i < nodes.length; i++) {
      nodes[i].embedding = allEmbeddings[i];
    }
    return nodes;
  }
  toString() {
    return `Graph(nodes=${this.nodes.size})`;
  }
}
class UndirectedGraph extends Graph {
  constructor(embeddingFn) {
    super();
    __publicField(this, "vectorBase");
    __publicField(this, "embeddingFn");
    this.vectorBase = new MemoryVectorBase();
    this.embeddingFn = embeddingFn;
  }
  /**
   * Set embedding function
   */
  setEmbeddingFunction(embeddingFn) {
    this.embeddingFn = embeddingFn;
  }
  /**
   * Add a node and optionally a neighbor with edge
   */
  async addNode(node, neighbor, sameNodeThreshold = 0.95) {
    let existingNode = this.getNode(node.id);
    if (existingNode) {
      node = existingNode;
    } else {
      existingNode = this.findNode(node.content, node.label);
      if (existingNode) {
        node = existingNode;
      } else {
        if (this.embeddingFn && node.embedding === null) {
          await node.createEmbedding(async (text) => {
            const embeddings = await this.embeddingFn([text]);
            return embeddings[0];
          });
        }
        if (node.embedding !== null) {
          await this.vectorBase.add(node);
        }
        this.nodes.set(node.id, node);
      }
    }
    if (neighbor !== void 0) {
      let existingNeighbor = this.getNode(neighbor.id);
      if (existingNeighbor) {
        neighbor = existingNeighbor;
      } else {
        existingNeighbor = this.findNode(neighbor.content, neighbor.label);
        if (existingNeighbor) {
          neighbor = existingNeighbor;
        } else {
          if (this.embeddingFn && neighbor.embedding === null) {
            await neighbor.createEmbedding(async (text) => {
              const embeddings = await this.embeddingFn([text]);
              return embeddings[0];
            });
          }
          if (neighbor.embedding !== null) {
            await this.vectorBase.add(neighbor);
          }
          this.nodes.set(neighbor.id, neighbor);
        }
      }
      node.addNeighbor(neighbor);
    }
  }
  /**
   * Add a node with multiple neighbors
   */
  async addNodes(node, neighbors) {
    if (!neighbors || neighbors.length === 0) {
      await this.addNode(node);
    } else {
      for (const neighbor of neighbors) {
        await this.addNode(node, neighbor);
      }
    }
  }
  /**
   * Get node by ID (typed as UndirectedNode)
   */
  getNode(nodeId) {
    return super.getNode(nodeId);
  }
  /**
   * Get node by content using semantic search
   */
  async getNodeByContent(content) {
    const matches = await this.semanticSearch(content, 0.999, 1);
    return matches.length > 0 ? matches[0] : null;
  }
  /**
   * Get all nodes within N steps using BFS
   */
  async getNodesWithinSteps(startNode, steps = 1, constraintLabels, block = false) {
    var _a2;
    const visited = /* @__PURE__ */ new Set();
    const queue = [
      { node: startNode, currentSteps: 0 }
    ];
    const result = [];
    while (queue.length > 0) {
      const { node, currentSteps } = queue.shift();
      if (currentSteps > steps) {
        break;
      }
      if (!visited.has(node.id)) {
        visited.add(node.id);
        result.push(node);
        const neighbors = Array.from(((_a2 = this.getNode(node.id)) == null ? void 0 : _a2.getNeighbors()) || []);
        neighbors.sort((a, b) => a.content.localeCompare(b.content));
        for (const neighbor of neighbors) {
          const shouldBlock = block && constraintLabels && !constraintLabels.includes(neighbor.label);
          if (!visited.has(neighbor.id) && !shouldBlock) {
            queue.push({ node: neighbor, currentSteps: currentSteps + 1 });
          }
        }
      }
    }
    let filteredResult = result;
    if (constraintLabels) {
      filteredResult = result.filter((node) => constraintLabels.includes(node.label));
    }
    return filteredResult.filter((node) => node.id !== startNode.id);
  }
  /**
   * Get intersection of nodes connected to multiple nodes
   */
  async getNodesIntersection(nodes, steps = 1, constraintLabels) {
    if (nodes.length < 2) {
      throw new Error("Nodes length must be >= 2");
    }
    let intersection = null;
    for (const node of nodes) {
      const connectedNodes = await this.getNodesWithinSteps(node, steps, constraintLabels);
      if (intersection === null) {
        intersection = connectedNodes;
      } else {
        intersection = this.intersection(intersection, connectedNodes);
      }
    }
    return intersection || [];
  }
  /**
   * Semantic search using vector similarity
   */
  async semanticSearch(node, similarityThreshold = 0, topK, constraintLabels) {
    let searchNode;
    if (typeof node === "string") {
      searchNode = new UndirectedNode(node);
      if (this.embeddingFn) {
        await searchNode.createEmbedding(async (text) => {
          const embeddings = await this.embeddingFn([text]);
          return embeddings[0];
        });
      }
    } else {
      searchNode = node;
    }
    if (searchNode.embedding === null) {
      logWithTimestamp("Search node has no embedding", "warn");
      return [];
    }
    const [docs, scores] = await this.vectorBase.search(
      searchNode.content,
      topK || null,
      similarityThreshold,
      constraintLabels || null
    );
    const results = [];
    for (const doc of docs) {
      const graphNode = this.getNode(doc.id);
      if (graphNode) {
        results.push(graphNode);
      }
    }
    return results;
  }
  /**
   * Query by node with graph traversal and optional constraints
   */
  async queryByNode(node, step = 1, constraintLabels, constraintNode, constraintDistance = 0, block = false) {
    const nodes = await this.getNodesWithinSteps(node, step, constraintLabels, block);
    if (constraintNode !== void 0) {
      for (const n of nodes) {
        const distance = this.calDistance(n, constraintNode);
        if (distance > constraintDistance) {
          return nodes;
        }
      }
      return [];
    }
    return nodes;
  }
  /**
   * Hybrid query combining semantic search and graph traversal
   */
  async queryByContent(content, topK = 5, step = 1, constraintLabels, constraintNode, similarityThreshold = 0, constraintDistance = 0, block = false) {
    const queries = typeof content === "string" ? [content] : content;
    const resList = [];
    for (const query of queries) {
      const similarNodes = await this.semanticSearch(
        query,
        similarityThreshold,
        topK
      );
      const connectedNodes = [];
      for (const node of similarNodes) {
        const graphQueryResult = await this.queryByNode(
          node,
          step,
          constraintLabels,
          constraintNode,
          constraintDistance,
          block
        );
        for (const resultNode of graphQueryResult) {
          if (!connectedNodes.some((n) => n.id === resultNode.id)) {
            connectedNodes.push(resultNode);
          }
        }
        if (connectedNodes.length >= topK) {
          break;
        }
      }
      for (const node of connectedNodes.slice(0, topK)) {
        if (!resList.some((n) => n.id === node.id)) {
          resList.push(node);
        }
      }
    }
    return resList;
  }
  /**
   * Clear the graph
   */
  clear() {
    this.nodes.clear();
    this.vectorBase.clear();
    logWithTimestamp("Graph cleared", "log");
  }
  /**
   * Calculate intersection of two node arrays
   */
  static intersection(nodes1, nodes2) {
    const ids2 = new Set(nodes2.map((n) => n.id));
    return nodes1.filter((node) => ids2.has(node.id));
  }
  /**
   * Instance method for intersection
   */
  intersection(nodes1, nodes2) {
    return UndirectedGraph.intersection(nodes1, nodes2);
  }
  /**
   * Calculate symmetric difference between two node arrays
   */
  static different(nodes1, nodes2) {
    const ids1 = new Set(nodes1.map((n) => n.id));
    const ids2 = new Set(nodes2.map((n) => n.id));
    const onlyIn1 = nodes1.filter((n) => !ids2.has(n.id));
    const onlyIn2 = nodes2.filter((n) => !ids1.has(n.id));
    return [...onlyIn1, ...onlyIn2];
  }
  /**
   * Calculate distance between two nodes using cosine similarity
   */
  calDistance(node1, node2) {
    if (!node1.embedding || !node2.embedding) {
      throw new Error("Both nodes must have embeddings");
    }
    return 1 - cosineSimilarity(node1.embedding, node2.embedding);
  }
  /**
   * Filter nodes by labels
   */
  static filterLabel(nodes, labels) {
    return nodes.filter((node) => labels.includes(node.label));
  }
  /**
   * Get the vector base (for advanced usage)
   */
  getVectorBase() {
    return this.vectorBase;
  }
  toString() {
    return `UndirectedGraph(nodes=${this.nodes.size})`;
  }
}
let graphInstance = null;
function getGraphInstance() {
  if (!graphInstance) {
    graphInstance = new UndirectedGraph();
    logWithTimestamp("Created new KnowledgeGraph instance", "log");
  }
  return graphInstance;
}
function createKnowledgeNode(page) {
  return {
    name: "kg_create_node",
    description: "Create a new node in the knowledge graph. Requires content and label. Optional: embedding (array of numbers) and appendix (any additional data). If no embedding provided, it will be created automatically if embedding function is configured.",
    func: async (input) => {
      try {
        const inputObj = JSON.parse(input);
        const { content, label, embedding, appendix } = inputObj;
        if (!content || !label) {
          return "Error: Missing required fields. Please provide content and label.";
        }
        const graph = getGraphInstance();
        const node = new UndirectedNode(content, label, embedding || null, appendix);
        await graph.addNode(node);
        return `Knowledge node created successfully with ID: ${node.id}`;
      } catch (error) {
        logWithTimestamp(`Error creating knowledge node: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error creating knowledge node: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function addKnowledgeEdge(page) {
  return {
    name: "kg_add_edge",
    description: "Create a bidirectional edge between two existing nodes in the knowledge graph. Provide the content and label of both nodes, or create new nodes if they don't exist.",
    func: async (input) => {
      try {
        const inputObj = JSON.parse(input);
        const { node1Content, node1Label, node2Content, node2Label, node1Embedding, node2Embedding } = inputObj;
        if (!node1Content || !node1Label || !node2Content || !node2Label) {
          return "Error: Missing required fields. Provide node1Content, node1Label, node2Content, node2Label.";
        }
        const graph = getGraphInstance();
        const node1 = new UndirectedNode(node1Content, node1Label, node1Embedding || null);
        const node2 = new UndirectedNode(node2Content, node2Label, node2Embedding || null);
        await graph.addNode(node1, node2);
        return `Edge created between nodes: ${node1.id} <-> ${node2.id}`;
      } catch (error) {
        logWithTimestamp(`Error adding edge: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error adding edge: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function listKnowledgeNodes(page) {
  return {
    name: "kg_list_nodes",
    description: "List all nodes in the knowledge graph. Optional: provide labels array to filter by specific labels.",
    func: async (input) => {
      try {
        const graph = getGraphInstance();
        let nodes;
        if (input.trim()) {
          const inputObj = JSON.parse(input);
          const { labels } = inputObj;
          if (labels && Array.isArray(labels)) {
            nodes = graph.getAllNodesByLabelList(labels);
          } else {
            nodes = graph.getAllNodes();
          }
        } else {
          nodes = graph.getAllNodes();
        }
        if (nodes.length === 0) {
          return "No nodes found in the knowledge graph.";
        }
        return JSON.stringify(nodes.map((node) => {
          var _a2;
          return {
            id: node.id,
            label: node.label,
            content: node.content.substring(0, 100) + (node.content.length > 100 ? "..." : ""),
            hasEmbedding: node.embedding !== null,
            neighborCount: ((_a2 = node.neighbors) == null ? void 0 : _a2.size) || 0
          };
        }), null, 2);
      } catch (error) {
        logWithTimestamp(`Error listing nodes: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error listing nodes: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function searchKnowledge(page) {
  return {
    name: "kg_search",
    description: "Search the knowledge graph using semantic similarity. Provide query text, and optionally topK (default 5), similarityThreshold (default 0.0), and constraintLabels (array of labels to filter by).",
    func: async (input) => {
      try {
        const inputObj = JSON.parse(input);
        const { query, topK, similarityThreshold, constraintLabels } = inputObj;
        if (!query) {
          return "Error: Missing required field 'query'.";
        }
        const graph = getGraphInstance();
        const results = await graph.semanticSearch(
          query,
          similarityThreshold || 0,
          topK || 5,
          constraintLabels
        );
        if (results.length === 0) {
          return `No nodes found matching query: "${query}"`;
        }
        return JSON.stringify(results.map((node) => ({
          id: node.id,
          label: node.label,
          content: node.content.substring(0, 200) + (node.content.length > 200 ? "..." : ""),
          neighborCount: node.neighbors.size
        })), null, 2);
      } catch (error) {
        logWithTimestamp(`Error searching knowledge: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error searching knowledge: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function traverseKnowledgeGraph(page) {
  return {
    name: "kg_traverse",
    description: "Traverse the knowledge graph from a starting node using BFS. Provide nodeId or (content + label) to identify the start node, steps (default 1), and optionally constraintLabels to filter results.",
    func: async (input) => {
      try {
        const inputObj = JSON.parse(input);
        const { nodeId, content, label, steps, constraintLabels, block } = inputObj;
        const graph = getGraphInstance();
        let startNode = null;
        if (nodeId) {
          startNode = graph.getNode(nodeId);
        } else if (content && label) {
          startNode = graph.findNode(content, label);
        } else {
          return "Error: Provide either nodeId or (content + label) to identify the start node.";
        }
        if (!startNode) {
          return "Error: Start node not found in the graph.";
        }
        const results = await graph.getNodesWithinSteps(
          startNode,
          steps || 1,
          constraintLabels,
          block || false
        );
        if (results.length === 0) {
          return `No nodes found within ${steps || 1} steps of the start node.`;
        }
        return JSON.stringify(results.map((node) => ({
          id: node.id,
          label: node.label,
          content: node.content.substring(0, 100) + "...",
          neighborCount: node.neighbors.size
        })), null, 2);
      } catch (error) {
        logWithTimestamp(`Error traversing graph: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error traversing graph: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function hybridKnowledgeQuery(page) {
  return {
    name: "kg_hybrid_query",
    description: "Powerful hybrid query combining semantic search and graph traversal. Search for similar nodes, then expand through graph connections. Provide query (string or array), topK (default 5), step (traversal depth, default 1), similarityThreshold (default 0.0), and optionally constraintLabels.",
    func: async (input) => {
      try {
        const inputObj = JSON.parse(input);
        const {
          query,
          topK,
          step,
          constraintLabels,
          similarityThreshold,
          block
        } = inputObj;
        if (!query) {
          return "Error: Missing required field 'query'.";
        }
        const graph = getGraphInstance();
        const results = await graph.queryByContent(
          query,
          topK || 5,
          step || 1,
          constraintLabels,
          void 0,
          similarityThreshold || 0,
          0,
          block || false
        );
        if (results.length === 0) {
          return `No nodes found for hybrid query: "${query}"`;
        }
        return JSON.stringify(results.map((node) => ({
          id: node.id,
          label: node.label,
          content: node.content.substring(0, 200) + "...",
          neighborCount: node.neighbors.size
        })), null, 2);
      } catch (error) {
        logWithTimestamp(`Error in hybrid query: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error in hybrid query: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function findKnowledgeIntersection(page) {
  return {
    name: "kg_find_intersection",
    description: "Find nodes that are connected to ALL specified nodes. Provide an array of nodeIds or node objects (with content + label), steps (default 1), and optionally constraintLabels.",
    func: async (input) => {
      try {
        const inputObj = JSON.parse(input);
        const { nodeIds, nodes, steps, constraintLabels } = inputObj;
        const graph = getGraphInstance();
        const targetNodes = [];
        if (nodeIds && Array.isArray(nodeIds)) {
          for (const id of nodeIds) {
            const node = graph.getNode(id);
            if (node) {
              targetNodes.push(node);
            }
          }
        }
        if (nodes && Array.isArray(nodes)) {
          for (const nodeSpec of nodes) {
            const { content, label } = nodeSpec;
            const node = graph.findNode(content, label);
            if (node) {
              targetNodes.push(node);
            }
          }
        }
        if (targetNodes.length < 2) {
          return "Error: Need at least 2 nodes to find intersection.";
        }
        const results = await graph.getNodesIntersection(
          targetNodes,
          steps || 1,
          constraintLabels
        );
        if (results.length === 0) {
          return "No common nodes found in the intersection.";
        }
        return JSON.stringify(results.map((node) => ({
          id: node.id,
          label: node.label,
          content: node.content.substring(0, 100) + "...",
          neighborCount: node.neighbors.size
        })), null, 2);
      } catch (error) {
        logWithTimestamp(`Error finding intersection: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error finding intersection: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function getKnowledgeGraphStats(page) {
  return {
    name: "kg_get_stats",
    description: "Get statistics about the knowledge graph including total nodes, labels distribution, and average connections.",
    func: async () => {
      try {
        const graph = getGraphInstance();
        const allNodes = graph.getAllNodes();
        const stats = {
          totalNodes: allNodes.length,
          labels: {},
          totalEdges: 0,
          avgNeighbors: 0,
          nodesWithEmbeddings: 0
        };
        for (const node of allNodes) {
          stats.labels[node.label] = (stats.labels[node.label] || 0) + 1;
          stats.totalEdges += node.neighbors.size;
          if (node.embedding !== null) {
            stats.nodesWithEmbeddings++;
          }
        }
        stats.totalEdges = stats.totalEdges / 2;
        stats.avgNeighbors = allNodes.length > 0 ? stats.totalEdges / allNodes.length : 0;
        return JSON.stringify(stats, null, 2);
      } catch (error) {
        logWithTimestamp(`Error getting stats: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error getting stats: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function clearKnowledgeGraph(page) {
  return {
    name: "kg_clear",
    description: "Clear all nodes and edges from the knowledge graph. This operation is irreversible. Use with caution.",
    func: async () => {
      try {
        const graph = getGraphInstance();
        graph.clear();
        return "Knowledge graph cleared successfully.";
      } catch (error) {
        logWithTimestamp(`Error clearing graph: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error clearing graph: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
function getKnowledgeNode(page) {
  return {
    name: "kg_get_node",
    description: "Get a specific node by ID or by content+label. Returns the node details including neighbors.",
    func: async (input) => {
      var _a2;
      try {
        const inputObj = JSON.parse(input);
        const { nodeId, content, label } = inputObj;
        const graph = getGraphInstance();
        let node = null;
        if (nodeId) {
          node = graph.getNode(nodeId);
        } else if (content && label) {
          node = graph.findNode(content, label);
        } else {
          return "Error: Provide either nodeId or (content + label).";
        }
        if (!node) {
          return "Node not found.";
        }
        const neighbors = Array.from(node.neighbors).map((n) => ({
          id: n.id,
          label: n.label,
          content: n.content.substring(0, 50) + "..."
        }));
        return JSON.stringify({
          id: node.id,
          label: node.label,
          content: node.content,
          hasEmbedding: node.embedding !== null,
          embeddingDimension: ((_a2 = node.embedding) == null ? void 0 : _a2.length) || 0,
          neighborCount: node.neighbors.size,
          neighbors
        }, null, 2);
      } catch (error) {
        logWithTimestamp(`Error getting node: ${error instanceof Error ? error.message : String(error)}`, "error");
        return `Error getting node: ${error instanceof Error ? error.message : String(error)}`;
      }
    }
  };
}
const _ContentCacheService = class _ContentCacheService {
  constructor() {
    __publicField(this, "memoryCache");
    __publicField(this, "dbName", "BrowserBeeContentCache");
    __publicField(this, "dbVersion", 1);
    __publicField(this, "storeName", "pageContent");
    __publicField(this, "defaultTTL", 5 * 60 * 1e3);
    // 5 minutes
    __publicField(this, "db", null);
    this.memoryCache = /* @__PURE__ */ new Map();
  }
  /**
   * Get singleton instance
   */
  static getInstance() {
    if (!_ContentCacheService.instance) {
      _ContentCacheService.instance = new _ContentCacheService();
    }
    return _ContentCacheService.instance;
  }
  /**
   * Initialize IndexedDB
   */
  async initDB() {
    if (this.db) {
      return this.db;
    }
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion);
      request.onerror = () => {
        logWithTimestamp("Failed to open content cache database", "error");
        reject(new Error("Failed to open content cache database"));
      };
      request.onsuccess = () => {
        this.db = request.result;
        logWithTimestamp("Content cache database opened successfully");
        resolve(this.db);
      };
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(this.storeName)) {
          const store = db.createObjectStore(this.storeName, {
            keyPath: "pageHash"
          });
          store.createIndex("url", "url", { unique: false });
          store.createIndex("expiresAt", "expiresAt", { unique: false });
        }
        logWithTimestamp("Content cache schema created");
      };
    });
  }
  /**
   * Generate hash for URL
   */
  hashUrl(url) {
    let hash = 0;
    for (let i = 0; i < url.length; i++) {
      const char = url.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash;
    }
    return `page_${Math.abs(hash).toString(36)}`;
  }
  /**
   * Get cached content by URL
   */
  async get(url) {
    const pageHash = this.hashUrl(url);
    const memEntry = this.memoryCache.get(pageHash);
    if (memEntry) {
      if (Date.now() < memEntry.expiresAt) {
        logWithTimestamp(`[Cache HIT - Memory] ${url}`, "log");
        return memEntry.data;
      } else {
        this.memoryCache.delete(pageHash);
      }
    }
    try {
      const db = await this.initDB();
      const transaction = db.transaction([this.storeName], "readonly");
      const store = transaction.objectStore(this.storeName);
      return new Promise((resolve) => {
        const request = store.get(pageHash);
        request.onsuccess = () => {
          const entry = request.result;
          if (entry && Date.now() < entry.expiresAt) {
            this.memoryCache.set(pageHash, entry);
            logWithTimestamp(`[Cache HIT - IndexedDB] ${url}`, "log");
            resolve(entry.data);
          } else {
            if (entry) {
              this.delete(url);
            }
            logWithTimestamp(`[Cache MISS] ${url}`, "log");
            resolve(null);
          }
        };
        request.onerror = () => {
          logWithTimestamp(`Error reading cache for ${url}`, "error");
          resolve(null);
        };
      });
    } catch (error) {
      logWithTimestamp(`Cache read error: ${error}`, "error");
      return null;
    }
  }
  /**
   * Set cached content for URL
   */
  async set(url, content, ttl = this.defaultTTL) {
    const pageHash = this.hashUrl(url);
    const expiresAt = Date.now() + ttl;
    const entry = {
      data: content,
      expiresAt
    };
    this.memoryCache.set(pageHash, entry);
    try {
      const db = await this.initDB();
      const transaction = db.transaction([this.storeName], "readwrite");
      const store = transaction.objectStore(this.storeName);
      return new Promise((resolve, reject) => {
        const request = store.put({
          pageHash,
          url,
          ...entry
        });
        request.onsuccess = () => {
          logWithTimestamp(`[Cache STORED] ${url} (expires in ${ttl / 1e3}s)`, "log");
          resolve();
        };
        request.onerror = () => {
          logWithTimestamp(`Failed to store cache for ${url}`, "error");
          reject(new Error("Failed to store cache"));
        };
      });
    } catch (error) {
      logWithTimestamp(`Cache write error: ${error}`, "error");
    }
  }
  /**
   * Delete cached content for URL
   */
  async delete(url) {
    const pageHash = this.hashUrl(url);
    this.memoryCache.delete(pageHash);
    try {
      const db = await this.initDB();
      const transaction = db.transaction([this.storeName], "readwrite");
      const store = transaction.objectStore(this.storeName);
      return new Promise((resolve) => {
        const request = store.delete(pageHash);
        request.onsuccess = () => {
          logWithTimestamp(`[Cache DELETED] ${url}`, "log");
          resolve();
        };
        request.onerror = () => {
          logWithTimestamp(`Failed to delete cache for ${url}`, "error");
          resolve();
        };
      });
    } catch (error) {
      logWithTimestamp(`Cache delete error: ${error}`, "error");
    }
  }
  /**
   * Clear all expired entries
   */
  async clearExpired() {
    const now = Date.now();
    let deletedCount = 0;
    for (const [key, entry] of this.memoryCache.entries()) {
      if (now >= entry.expiresAt) {
        this.memoryCache.delete(key);
        deletedCount++;
      }
    }
    try {
      const db = await this.initDB();
      const transaction = db.transaction([this.storeName], "readwrite");
      const store = transaction.objectStore(this.storeName);
      const index = store.index("expiresAt");
      return new Promise((resolve) => {
        const request = index.openCursor();
        request.onsuccess = (event) => {
          const cursor = event.target.result;
          if (cursor) {
            const entry = cursor.value;
            if (now >= entry.expiresAt) {
              cursor.delete();
              deletedCount++;
            }
            cursor.continue();
          } else {
            logWithTimestamp(`[Cache CLEANUP] Deleted ${deletedCount} expired entries`, "log");
            resolve(deletedCount);
          }
        };
        request.onerror = () => {
          logWithTimestamp("Error during cache cleanup", "error");
          resolve(deletedCount);
        };
      });
    } catch (error) {
      logWithTimestamp(`Cache cleanup error: ${error}`, "error");
      return deletedCount;
    }
  }
  /**
   * Clear all cached content
   */
  async clear() {
    this.memoryCache.clear();
    try {
      const db = await this.initDB();
      const transaction = db.transaction([this.storeName], "readwrite");
      const store = transaction.objectStore(this.storeName);
      return new Promise((resolve) => {
        const request = store.clear();
        request.onsuccess = () => {
          logWithTimestamp("[Cache CLEARED] All cache entries deleted", "log");
          resolve();
        };
        request.onerror = () => {
          logWithTimestamp("Error clearing cache", "error");
          resolve();
        };
      });
    } catch (error) {
      logWithTimestamp(`Cache clear error: ${error}`, "error");
    }
  }
  /**
   * Get cache statistics
   */
  async getStats() {
    const memoryCacheSize = this.memoryCache.size;
    try {
      const db = await this.initDB();
      const transaction = db.transaction([this.storeName], "readonly");
      const store = transaction.objectStore(this.storeName);
      return new Promise((resolve) => {
        const request = store.count();
        request.onsuccess = () => {
          const dbCacheSize = request.result;
          resolve({
            memoryCacheSize,
            dbCacheSize,
            totalSize: memoryCacheSize + dbCacheSize
          });
        };
        request.onerror = () => {
          resolve({
            memoryCacheSize,
            dbCacheSize: 0,
            totalSize: memoryCacheSize
          });
        };
      });
    } catch (error) {
      return {
        memoryCacheSize,
        dbCacheSize: 0,
        totalSize: memoryCacheSize
      };
    }
  }
  /**
   * Check if content is stale (older than threshold)
   */
  isStale(content, threshold = this.defaultTTL) {
    const age = Date.now() - content.metadata.extractedAt;
    return age > threshold;
  }
};
__publicField(_ContentCacheService, "instance", null);
let ContentCacheService = _ContentCacheService;
async function extractStructuredContent(page) {
  try {
    const url = await page.url();
    const title = await page.title();
    const extraction = await page.evaluate(() => {
      var _a2;
      const sections = [];
      const allText = [];
      let currentHeading = null;
      let currentContent = [];
      let sectionIndex = 0;
      function getXPath(element) {
        const segments = [];
        let current = element;
        while (current && current !== document.body) {
          let index = 1;
          let sibling = current.previousElementSibling;
          while (sibling) {
            if (sibling.tagName === current.tagName) index++;
            sibling = sibling.previousElementSibling;
          }
          const tagName = current.tagName.toLowerCase();
          const segment = `${tagName}[${index}]`;
          segments.unshift(segment);
          current = current.parentElement;
        }
        return "//" + segments.join("/");
      }
      function saveSection() {
        var _a3;
        if (currentHeading && currentContent.length > 0) {
          const content2 = currentContent.join(" ").trim();
          const wordCount = content2.split(/\s+/).length;
          sections.push({
            heading: ((_a3 = currentHeading.textContent) == null ? void 0 : _a3.trim()) || "",
            level: parseInt(currentHeading.tagName[1]),
            content: content2,
            xpath: getXPath(currentHeading),
            position: sectionIndex++,
            wordCount
          });
          currentContent = [];
        }
      }
      const walker = document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT,
        {
          acceptNode: (node) => {
            var _a3;
            if (node.nodeType === Node.ELEMENT_NODE) {
              const el = node;
              if (/^H[1-6]$/.test(el.tagName)) {
                return NodeFilter.FILTER_ACCEPT;
              }
              if (["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "META", "LINK"].includes(el.tagName)) {
                return NodeFilter.FILTER_REJECT;
              }
            }
            if (node.nodeType === Node.TEXT_NODE) {
              const parent = node.parentElement;
              if (parent && parent.offsetParent !== null && ((_a3 = node.textContent) == null ? void 0 : _a3.trim())) {
                return NodeFilter.FILTER_ACCEPT;
              }
            }
            return NodeFilter.FILTER_SKIP;
          }
        }
      );
      while (walker.nextNode()) {
        const node = walker.currentNode;
        if (node.nodeType === Node.ELEMENT_NODE) {
          const el = node;
          saveSection();
          currentHeading = el;
        } else if (node.nodeType === Node.TEXT_NODE) {
          const text = (_a2 = node.textContent) == null ? void 0 : _a2.trim();
          if (text) {
            currentContent.push(text);
            allText.push(text);
          }
        }
      }
      saveSection();
      if (sections.length === 0 && allText.length > 0) {
        sections.push({
          heading: "Main Content",
          level: 1,
          content: allText.join(" "),
          xpath: "//body",
          position: 0,
          wordCount: allText.join(" ").split(/\s+/).length
        });
      }
      return {
        fullText: allText.join("\n"),
        sections,
        metadata: {
          wordCount: allText.join(" ").split(/\s+/).length,
          hasHeadings: sections.length > 1 || sections.length === 1 && sections[0].heading !== "Main Content"
        }
      };
    });
    const extractionData = extraction;
    const content = {
      url,
      title,
      fullText: extractionData.fullText,
      sections: extractionData.sections,
      metadata: {
        extractedAt: Date.now(),
        pageHash: "",
        // Will be set by cache service
        wordCount: extractionData.metadata.wordCount,
        hasHeadings: extractionData.metadata.hasHeadings
      }
    };
    logWithTimestamp(
      `Extracted ${content.sections.length} sections, ${content.metadata.wordCount} words from ${url}`,
      "log"
    );
    return content;
  } catch (error) {
    logWithTimestamp(`Error extracting structured content: ${error}`, "error");
    throw error;
  }
}
async function extractMainContent(page) {
  try {
    const mainText = await page.evaluate(() => {
      var _a2, _b;
      const mainSelectors = [
        "main",
        "article",
        '[role="main"]',
        "#content",
        "#main",
        ".content",
        ".main-content"
      ];
      for (const selector of mainSelectors) {
        const element = document.querySelector(selector);
        if (element) {
          const walker2 = document.createTreeWalker(
            element,
            NodeFilter.SHOW_TEXT,
            {
              acceptNode: (node) => {
                var _a3;
                const parent = node.parentElement;
                if (parent && parent.offsetParent !== null && ((_a3 = node.textContent) == null ? void 0 : _a3.trim())) {
                  return NodeFilter.FILTER_ACCEPT;
                }
                return NodeFilter.FILTER_REJECT;
              }
            }
          );
          const texts2 = [];
          while (walker2.nextNode()) {
            const text = (_a2 = walker2.currentNode.textContent) == null ? void 0 : _a2.trim();
            if (text) texts2.push(text);
          }
          if (texts2.length > 0) {
            return texts2.join("\n");
          }
        }
      }
      const walker = document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_TEXT,
        {
          acceptNode: (node) => {
            var _a3;
            const parent = node.parentElement;
            if (parent && parent.offsetParent !== null && ((_a3 = node.textContent) == null ? void 0 : _a3.trim())) {
              return NodeFilter.FILTER_ACCEPT;
            }
            return NodeFilter.FILTER_REJECT;
          }
        }
      );
      const texts = [];
      while (walker.nextNode()) {
        const text = (_b = walker.currentNode.textContent) == null ? void 0 : _b.trim();
        if (text) texts.push(text);
      }
      return texts.join("\n");
    });
    return mainText;
  } catch (error) {
    logWithTimestamp(`Error extracting main content: ${error}`, "error");
    throw error;
  }
}
async function getPageSummary(page, maxLength = 500) {
  try {
    const content = await extractStructuredContent(page);
    const summary = [content.title];
    let currentLength = content.title.length;
    for (const section of content.sections) {
      if (currentLength >= maxLength) break;
      const sectionText = `

## ${section.heading}
${section.content}`;
      const remaining = maxLength - currentLength;
      if (sectionText.length <= remaining) {
        summary.push(sectionText);
        currentLength += sectionText.length;
      } else {
        const truncated = sectionText.substring(0, remaining) + "...";
        summary.push(truncated);
        break;
      }
    }
    return summary.join("");
  } catch (error) {
    logWithTimestamp(`Error getting page summary: ${error}`, "error");
    throw error;
  }
}
class MockEmbeddingProvider {
  constructor(dimension = 384) {
    __publicField(this, "dimension");
    this.dimension = dimension;
  }
  async createEmbedding(text) {
    const hash = this.hashString(text);
    const random = this.seededRandom(hash);
    const embedding = Array(this.dimension).fill(0).map(() => random() * 2 - 1);
    return this.normalize(embedding);
  }
  async createEmbeddings(texts) {
    return Promise.all(texts.map((text) => this.createEmbedding(text)));
  }
  getDimension() {
    return this.dimension;
  }
  hashString(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash;
    }
    return Math.abs(hash);
  }
  seededRandom(seed) {
    let value = seed;
    return () => {
      value = (value * 9301 + 49297) % 233280;
      return value / 233280;
    };
  }
  normalize(vector) {
    const magnitude = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0));
    return vector.map((val) => val / (magnitude || 1));
  }
}
const _EmbeddingService = class _EmbeddingService {
  constructor() {
    __publicField(this, "provider", null);
    __publicField(this, "cache");
    __publicField(this, "maxCacheSize", 1e3);
    this.cache = /* @__PURE__ */ new Map();
    this.provider = new MockEmbeddingProvider();
  }
  /**
   * Get singleton instance
   */
  static getInstance() {
    if (!_EmbeddingService.instance) {
      _EmbeddingService.instance = new _EmbeddingService();
    }
    return _EmbeddingService.instance;
  }
  /**
   * Set embedding provider
   */
  setProvider(provider) {
    this.provider = provider;
    this.cache.clear();
    logWithTimestamp(`Embedding provider set to ${provider.constructor.name}`, "log");
  }
  /**
   * Get current provider
   */
  getProvider() {
    return this.provider;
  }
  /**
   * Create embedding for single text with caching
   */
  async createEmbedding(text) {
    if (!this.provider) {
      throw new Error("No embedding provider set");
    }
    const cacheKey = this.getCacheKey(text);
    const cached = this.cache.get(cacheKey);
    if (cached) {
      return cached;
    }
    const embedding = await this.provider.createEmbedding(text);
    this.cacheEmbedding(cacheKey, embedding);
    return embedding;
  }
  /**
   * Create embeddings for multiple texts
   */
  async createEmbeddings(texts) {
    if (!this.provider) {
      throw new Error("No embedding provider set");
    }
    const results = [];
    const uncachedTexts = [];
    const uncachedIndices = [];
    for (let i = 0; i < texts.length; i++) {
      const cacheKey = this.getCacheKey(texts[i]);
      const cached = this.cache.get(cacheKey);
      if (cached) {
        results[i] = cached;
      } else {
        uncachedTexts.push(texts[i]);
        uncachedIndices.push(i);
      }
    }
    if (uncachedTexts.length > 0) {
      const newEmbeddings = await this.provider.createEmbeddings(uncachedTexts);
      for (let i = 0; i < uncachedTexts.length; i++) {
        const embedding = newEmbeddings[i];
        const originalIndex = uncachedIndices[i];
        const cacheKey = this.getCacheKey(uncachedTexts[i]);
        this.cacheEmbedding(cacheKey, embedding);
        results[originalIndex] = embedding;
      }
    }
    return results;
  }
  /**
   * Get embedding dimension
   */
  getDimension() {
    if (!this.provider) {
      return 384;
    }
    return this.provider.getDimension();
  }
  /**
   * Clear embedding cache
   */
  clearCache() {
    this.cache.clear();
    logWithTimestamp("Embedding cache cleared", "log");
  }
  /**
   * Get cache statistics
   */
  getCacheStats() {
    return {
      size: this.cache.size,
      maxSize: this.maxCacheSize
    };
  }
  /**
   * Generate cache key for text
   */
  getCacheKey(text) {
    return text.substring(0, 100);
  }
  /**
   * Store embedding in cache with LRU eviction
   */
  cacheEmbedding(key, embedding) {
    if (this.cache.size >= this.maxCacheSize) {
      const firstKey = this.cache.keys().next().value;
      if (firstKey) {
        this.cache.delete(firstKey);
      }
    }
    this.cache.set(key, embedding);
  }
};
__publicField(_EmbeddingService, "instance", null);
let EmbeddingService = _EmbeddingService;
function parseReadTextOptions(input) {
  const options = {
    useCache: true,
    forceRefresh: false
  };
  if (!input || input.trim() === "") {
    return options;
  }
  input.split(",").forEach((part) => {
    const trimmed = part.trim();
    if (trimmed === "nocache") {
      options.useCache = false;
    } else if (trimmed === "refresh") {
      options.forceRefresh = true;
    } else if (trimmed.startsWith("query=")) {
      options.query = trimmed.substring("query=".length);
    } else if (trimmed.startsWith("limit=")) {
      options.maxSections = parseInt(trimmed.substring("limit=".length), 10);
    } else if (trimmed.startsWith("similarity=")) {
      options.minSimilarity = parseFloat(trimmed.substring("similarity=".length));
    } else if (!trimmed.includes("=")) {
      options.query = trimmed;
    }
  });
  return options;
}
const browserReadTextEnhanced = (page) => new DynamicTool({
  name: "browser_read_text_enhanced",
  description: "Enhanced text extraction with semantic search and caching. Much faster than browser_read_text on repeated calls.\nOptions (comma-separated):\n  • query=<text> - semantic search for specific content\n  • limit=<n> - return top N sections (default 3)\n  • similarity=<0-1> - minimum similarity score (default 0.5)\n  • nocache - force fresh extraction\n  • refresh - refresh cache\nExamples:\n  • 'pricing' - search for pricing information\n  • 'query=installation,limit=5' - get top 5 sections about installation\n  • 'nocache' - force fresh extraction",
  func: async (input) => {
    try {
      return await withActivePage(page, async (activePage) => {
        const options = parseReadTextOptions(input);
        const url = await activePage.url();
        const cacheService = ContentCacheService.getInstance();
        const vectorService = VectorService.getInstance();
        const embeddingService = EmbeddingService.getInstance();
        if (options.useCache && !options.forceRefresh) {
          const cached = await cacheService.get(url);
          if (cached && !cacheService.isStale(cached)) {
            logWithTimestamp(`[Cache HIT] ${url}`, "log");
            if (options.query) {
              return await searchCachedContent(
                cached,
                options.query,
                options.maxSections || 3,
                options.minSimilarity || 0.5,
                vectorService,
                embeddingService
              );
            }
            return truncate(cached.fullText, MAX_RETURN_CHARS);
          }
        }
        logWithTimestamp(`[Cache MISS] ${url}`, "log");
        const content = await extractStructuredContent(activePage);
        const pageHash = cacheService.hashUrl(url);
        const collectionName = `page_${pageHash}`;
        try {
          const collections = await vectorService.listCollections();
          const exists = collections.some((c) => c.name === collectionName);
          if (!exists) {
            await vectorService.createCollection(
              collectionName,
              embeddingService.getDimension()
            );
          } else if (options.forceRefresh) {
            await vectorService.deleteCollection(collectionName);
            await vectorService.createCollection(
              collectionName,
              embeddingService.getDimension()
            );
          }
          await storeSectionsWithEmbeddings(
            content,
            collectionName,
            url,
            vectorService,
            embeddingService
          );
        } catch (error) {
          logWithTimestamp(`Error storing in vector DB: ${error}`, "warn");
        }
        content.metadata.pageHash = pageHash;
        await cacheService.set(url, content);
        if (options.query) {
          return await searchCachedContent(
            content,
            options.query,
            options.maxSections || 3,
            options.minSimilarity || 0.5,
            vectorService,
            embeddingService
          );
        }
        return truncate(content.fullText, MAX_RETURN_CHARS);
      });
    } catch (error) {
      return `Error in enhanced read: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
async function storeSectionsWithEmbeddings(content, collectionName, url, vectorService, embeddingService) {
  for (const section of content.sections) {
    try {
      const embedding = await embeddingService.createEmbedding(section.content);
      await vectorService.storeDocument(
        collectionName,
        `${section.position}_${section.heading}`,
        section.content,
        embedding,
        {
          heading: section.heading,
          level: section.level,
          url,
          xpath: section.xpath,
          position: section.position,
          wordCount: section.wordCount
        }
      );
    } catch (error) {
      logWithTimestamp(`Error storing section ${section.heading}: ${error}`, "warn");
    }
  }
  logWithTimestamp(
    `Stored ${content.sections.length} sections in collection ${collectionName}`,
    "log"
  );
}
async function searchCachedContent(content, query, topK, minSimilarity, vectorService, embeddingService) {
  const pageHash = content.metadata.pageHash;
  const collectionName = `page_${pageHash}`;
  try {
    const queryEmbedding = await embeddingService.createEmbedding(query);
    const results = await vectorService.searchSimilar(
      collectionName,
      queryEmbedding,
      topK,
      minSimilarity
    );
    if (results.length === 0) {
      return `No content found matching query: "${query}"

Try lowering the similarity threshold or use different keywords.`;
    }
    const formatted = results.map((r, idx) => {
      var _a2;
      const heading = ((_a2 = r.metadata) == null ? void 0 : _a2.heading) || "Section";
      const relevance = (r.score * 100).toFixed(1);
      return `## ${idx + 1}. ${heading} (Relevance: ${relevance}%)

${r.content}`;
    });
    const output = `Found ${results.length} relevant sections for query: "${query}"

---

${formatted.join("\n\n---\n\n")}`;
    return truncate(output, MAX_RETURN_CHARS);
  } catch (error) {
    logWithTimestamp(`Vector search failed, using fallback: ${error}`, "warn");
    const matchingSections = content.sections.filter(
      (section) => section.content.toLowerCase().includes(query.toLowerCase()) || section.heading.toLowerCase().includes(query.toLowerCase())
    );
    if (matchingSections.length === 0) {
      return `No sections found matching query: "${query}"`;
    }
    const formatted = matchingSections.slice(0, topK).map((section, idx) => {
      return `## ${idx + 1}. ${section.heading}

${section.content}`;
    });
    return truncate(formatted.join("\n\n---\n\n"), MAX_RETURN_CHARS);
  }
}
const browserGetPageSummary = (page) => new DynamicTool({
  name: "browser_get_summary",
  description: "Get a quick summary of the page (title + first few sections). Faster than reading full text.",
  func: async (maxLength = "500") => {
    try {
      return await withActivePage(page, async (activePage) => {
        const length = parseInt(maxLength, 10) || 500;
        const summary = await getPageSummary(activePage, length);
        return summary;
      });
    } catch (error) {
      return `Error getting summary: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const browserReadMainContent = (page) => new DynamicTool({
  name: "browser_read_main",
  description: "Extract only the main content of the page, skipping navigation, headers, and footers. More focused than browser_read_text.",
  func: async () => {
    try {
      return await withActivePage(page, async (activePage) => {
        const mainContent = await extractMainContent(activePage);
        return truncate(mainContent, MAX_RETURN_CHARS);
      });
    } catch (error) {
      return `Error reading main content: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const browserGetCacheStats = (page) => new DynamicTool({
  name: "browser_cache_stats",
  description: "Get statistics about the content cache (hit rate, size, etc.)",
  func: async () => {
    try {
      const cacheService = ContentCacheService.getInstance();
      const stats = await cacheService.getStats();
      return JSON.stringify({
        memoryCacheSize: stats.memoryCacheSize,
        dbCacheSize: stats.dbCacheSize,
        totalCachedPages: stats.totalSize,
        message: `${stats.totalSize} pages cached (${stats.memoryCacheSize} in memory, ${stats.dbCacheSize} in DB)`
      }, null, 2);
    } catch (error) {
      return `Error getting cache stats: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const browserClearCache = (page) => new DynamicTool({
  name: "browser_clear_cache",
  description: "Clear all cached page content. Use when you want to force fresh extraction.",
  func: async () => {
    try {
      const cacheService = ContentCacheService.getInstance();
      await cacheService.clear();
      return "Content cache cleared successfully.";
    } catch (error) {
      return `Error clearing cache: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const browserMoveMouse = (page) => new DynamicTool({
  name: "browser_move_mouse",
  description: "Move the mouse cursor to absolute screen coordinates.\nInput format: `x|y`  (example: `250|380`)",
  func: async (input) => {
    try {
      return await withActivePage(page, async (activePage) => {
        const [xRaw, yRaw] = input.split("|").map((s) => s.trim());
        const x = Number(xRaw), y = Number(yRaw);
        if (Number.isNaN(x) || Number.isNaN(y))
          return "Error: expected `x|y` numbers (e.g. 120|240)";
        await activePage.mouse.move(x, y);
        return `Mouse moved to (${x}, ${y})`;
      });
    } catch (err) {
      return `Error moving mouse: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserClickXY = (page) => new DynamicTool({
  name: "browser_click_xy",
  description: "Left‑click at absolute coordinates.\nInput format: `x|y`  (example: `250|380`)",
  func: async (input) => {
    try {
      return await withActivePage(page, async (activePage) => {
        const [xRaw, yRaw] = input.split("|").map((s) => s.trim());
        const x = Number(xRaw), y = Number(yRaw);
        if (Number.isNaN(x) || Number.isNaN(y))
          return "Error: expected `x|y` numbers (e.g. 120|240)";
        await activePage.mouse.click(x, y);
        return `Clicked at (${x}, ${y})`;
      });
    } catch (err) {
      return `Error clicking at coords: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserDrag = (page) => new DynamicTool({
  name: "browser_drag",
  description: "Drag‑and‑drop with the left button.\nInput format: `startX|startY|endX|endY`  (example: `100|200|300|400`)",
  func: async (input) => {
    try {
      return await withActivePage(page, async (activePage) => {
        const [sx, sy, ex, ey] = input.split("|").map((s) => Number(s.trim()));
        if ([sx, sy, ex, ey].some((v) => Number.isNaN(v)))
          return "Error: expected `startX|startY|endX|endY` numbers";
        await activePage.mouse.move(sx, sy);
        await activePage.mouse.down();
        await activePage.mouse.move(ex, ey);
        await activePage.mouse.up();
        return `Dragged (${sx},${sy}) → (${ex},${ey})`;
      });
    } catch (err) {
      return `Error during drag: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserNavigate = (page) => new DynamicTool({
  name: "browser_navigate",
  description: "Navigate the browser to a specific URL. Input must be a full URL, e.g. https://example.com",
  func: async (url) => {
    try {
      return await withActivePage(page, async (activePage) => {
        await activePage.goto(url);
        try {
          const tabId = await getCurrentTabId(activePage);
          const newTitle = await activePage.title();
          if (tabId) {
            chrome.runtime.sendMessage({
              action: "tabTitleChanged",
              tabId,
              title: newTitle
            });
            console.log(`Sent tabTitleChanged message for tab ${tabId} with title "${newTitle}" after navigation to ${url}`);
            chrome.runtime.sendMessage({
              action: "targetChanged",
              tabId,
              url
            });
          }
        } catch (titleError) {
          console.error("Error updating UI after navigation:", titleError);
        }
        return `Successfully navigated to ${url}`;
      });
    } catch (error) {
      return `Error navigating to ${url}: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const browserWaitForNavigation = (page) => new DynamicTool({
  name: "browser_wait_for_navigation",
  description: "Wait for navigation to complete using specified strategy. Input options (default: all):\n  • load - wait for the 'load' event (DOM and resources loaded)\n  • domcontentloaded - wait for the 'DOMContentLoaded' event (DOM loaded, faster than 'load')\n  • networkidle - wait until network is idle for 500ms (may timeout on sites with continuous activity)\n  • all - try multiple strategies in sequence with shorter timeouts (recommended)",
  func: async (strategy = "all") => {
    try {
      return await withActivePage(page, async (activePage) => {
        switch (strategy.toLowerCase()) {
          case "load":
            await activePage.waitForLoadState("load", { timeout: 1e4 });
            return "Navigation complete (DOM loaded).";
          case "domcontentloaded":
            await activePage.waitForLoadState("domcontentloaded", { timeout: 1e4 });
            return "Navigation complete (DOM content loaded).";
          case "networkidle":
            await activePage.waitForLoadState("networkidle", { timeout: 1e4 });
            return "Navigation complete (network idle).";
          case "all":
          default:
            try {
              await activePage.waitForLoadState("load", { timeout: 5e3 });
              try {
                await activePage.waitForLoadState("networkidle", { timeout: 5e3 });
              } catch (networkError) {
              }
              return "Navigation complete.";
            } catch (loadError) {
              await activePage.waitForLoadState("domcontentloaded", { timeout: 5e3 });
              return "Navigation partially complete (DOM content loaded).";
            }
        }
      });
    } catch (error) {
      return `Error waiting for navigation: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const browserNavigateBack = (page) => new DynamicTool({
  name: "browser_navigate_back",
  description: "Go back to the previous page (history.back()). No input.",
  func: async () => {
    try {
      return await withActivePage(page, async (activePage) => {
        await activePage.goBack();
        return "Navigated back.";
      });
    } catch (err) {
      return `Error going back: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserNavigateForward = (page) => new DynamicTool({
  name: "browser_navigate_forward",
  description: "Go forward to the next page (history.forward()). No input.",
  func: async () => {
    try {
      return await withActivePage(page, async (activePage) => {
        await activePage.goForward();
        return "Navigated forward.";
      });
    } catch (err) {
      return `Error going forward: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserGetTitle = (page) => new DynamicTool({
  name: "browser_get_title",
  description: "Return the current page title.",
  func: async () => {
    try {
      return await withActivePage(page, async (activePage) => {
        const title = await activePage.title();
        try {
          const tabId = await getCurrentTabId(activePage);
          if (tabId) {
            chrome.runtime.sendMessage({
              action: "tabTitleChanged",
              tabId,
              title
            });
            console.log(`Sent tabTitleChanged message for tab ${tabId} with title "${title}" from browser_get_title`);
          }
        } catch (titleError) {
          console.error("Error updating UI with tab title:", titleError);
        }
        return `Current page title: ${title}`;
      });
    } catch (error) {
      return `Error getting title: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const browserSnapshotDom = (page) => new DynamicTool({
  name: "browser_snapshot_dom",
  description: "Capture DOM snapshot of the current page. Options (comma-separated):\n  • selector=<css_selector> - capture only elements matching this selector\n  • clean - remove scripts, styles, and other non-visible elements\n  • structure - return only element tags, ids, and classes (no content)\n  • limit=<number> - max character length (default 20000)",
  func: async (input) => {
    try {
      return await withActivePage(page, async (activePage) => {
        const options = parseSnapshotOptions(input);
        const limit = options.limit ? parseInt(options.limit, 10) : MAX_RETURN_CHARS;
        let html = "";
        if (options.selector) {
          const elementCount = await activePage.$$eval(options.selector, (els) => els.length);
          if (elementCount === 0) {
            return `No elements found matching selector: ${options.selector}`;
          }
          html = await activePage.$$eval(
            options.selector,
            (elements, opts) => {
              return elements.map((el) => {
                if (opts.structure) {
                  return getElementStructure(el);
                } else if (opts.clean) {
                  return cleanElement(el.cloneNode(true));
                } else {
                  return el.outerHTML;
                }
              }).join("\n\n");
              function getElementStructure(element) {
                const tagName = element.tagName.toLowerCase();
                const id = element.id ? `#${element.id}` : "";
                const classes = element.className && typeof element.className === "string" ? `.${element.className.split(" ").join(".")}` : "";
                let result = `<${tagName}${id}${classes}>`;
                if (element.children.length > 0) {
                  result += "\n  " + Array.from(element.children).map((child) => getElementStructure(child)).join("\n  ").replace(/\n/g, "\n  ");
                }
                result += `
</${tagName}>`;
                return result;
              }
              function cleanElement(node) {
                if (node.nodeType === 3) {
                  return node.textContent || "";
                }
                if (node.nodeType !== 1) {
                  return "";
                }
                const element = node;
                if (["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "META", "LINK"].includes(element.tagName)) {
                  return "";
                }
                const clean = document.createElement(element.tagName);
                Array.from(element.attributes).forEach((attr) => {
                  if (!attr.name.startsWith("on") && !attr.name.startsWith("data-")) {
                    clean.setAttribute(attr.name, attr.value);
                  }
                });
                Array.from(node.childNodes).map((child) => cleanElement(child)).filter(Boolean).forEach((childHtml) => {
                  if (typeof childHtml === "string") {
                    clean.innerHTML += childHtml;
                  }
                });
                return clean.outerHTML;
              }
            },
            {
              structure: options.structure || false,
              clean: options.clean || false
            }
          );
        } else {
          if (options.structure) {
            html = await activePage.evaluate(() => {
              function getPageStructure(element, depth = 0) {
                const tagName = element.tagName.toLowerCase();
                const id = element.id ? `#${element.id}` : "";
                const classes = element.className && typeof element.className === "string" ? `.${element.className.split(" ").join(".")}` : "";
                let result = "  ".repeat(depth) + `<${tagName}${id}${classes}>`;
                if (element.children.length > 0) {
                  result += "\n" + Array.from(element.children).map((child) => getPageStructure(child, depth + 1)).join("\n");
                }
                result += "\n" + "  ".repeat(depth) + `</${tagName}>`;
                return result;
              }
              return getPageStructure(document.documentElement);
            });
          } else if (options.clean) {
            html = await activePage.evaluate(() => {
              function cleanNode(node) {
                if (node.nodeType === 3) {
                  return node.textContent || "";
                }
                if (node.nodeType !== 1) {
                  return "";
                }
                const element = node;
                if (["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "META", "LINK"].includes(element.tagName)) {
                  return "";
                }
                const clean = document.createElement(element.tagName);
                Array.from(element.attributes).forEach((attr) => {
                  if (!attr.name.startsWith("on") && !attr.name.startsWith("data-")) {
                    clean.setAttribute(attr.name, attr.value);
                  }
                });
                Array.from(node.childNodes).map((child) => cleanNode(child)).filter(Boolean).forEach((childHtml) => {
                  if (typeof childHtml === "string") {
                    clean.innerHTML += childHtml;
                  }
                });
                return clean.outerHTML;
              }
              return cleanNode(document.documentElement);
            });
          } else {
            html = await activePage.content();
          }
        }
        return truncate(html, isNaN(limit) ? MAX_RETURN_CHARS : limit);
      });
    } catch (err) {
      return `Error capturing DOM snapshot: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
function parseSnapshotOptions(input) {
  const options = {};
  if (!input || input.trim() === "") {
    return options;
  }
  if (/^\d+$/.test(input.trim())) {
    options.limit = input.trim();
    return options;
  }
  input.split(",").forEach((part) => {
    const trimmed = part.trim();
    if (trimmed === "clean") {
      options.clean = true;
    } else if (trimmed === "structure") {
      options.structure = true;
    } else if (trimmed.startsWith("selector=")) {
      options.selector = trimmed.substring("selector=".length);
    } else if (trimmed.startsWith("limit=")) {
      options.limit = trimmed.substring("limit=".length);
    }
  });
  return options;
}
const browserQuery = (page) => new DynamicTool({
  name: "browser_query",
  description: "Return up to 10 outerHTML snippets for a CSS selector you provide.",
  func: async (selector) => {
    try {
      return await withActivePage(page, async (activePage) => {
        const matches = await activePage.$$eval(
          selector,
          (nodes) => nodes.slice(0, 10).map((n) => n.outerHTML)
        );
        if (!matches.length) return `Error: No nodes matched selector: ${selector}`;
        return truncate(matches.join("\n\n"));
      });
    } catch (err) {
      return `Error querying '${selector}': ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserAccessibleTree = (page) => new DynamicTool({
  name: "browser_accessible_tree",
  description: "Return the AX accessibility tree JSON (default: interesting‑only). Input 'all' to dump full tree. Note: This tool can be useful when the DOM is too large to process.",
  func: async (input) => {
    try {
      return await withActivePage(page, async (activePage) => {
        const interestingOnly = input.trim().toLowerCase() !== "all";
        const tree = await activePage.accessibility.snapshot({ interestingOnly });
        return truncate(JSON.stringify(tree, null, 2));
      });
    } catch (err) {
      return `Error creating AX snapshot: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserReadText = (page) => new DynamicTool({
  name: "browser_read_text",
  description: "Return all visible text on the page, concatenated in DOM order.",
  func: async () => {
    try {
      return await withActivePage(page, async (activePage) => {
        const text = await activePage.evaluate(() => {
          const walker = document.createTreeWalker(
            document.body,
            NodeFilter.SHOW_TEXT,
            {
              acceptNode: (node) => node.parentElement && node.parentElement.offsetParent !== null && node.textContent.trim() ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT
            }
          );
          const out = [];
          while (walker.nextNode())
            out.push(walker.currentNode.textContent.trim());
          return out.join("\n");
        });
        return truncate(text);
      });
    } catch (err) {
      return `Error extracting text: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserScreenshot = (page) => new DynamicTool({
  name: "browser_screenshot",
  description: "Take a screenshot of the current page.\n\nInput flags (comma-separated):\n  • (none)  – capture viewport only, downscaled to 800px wide (default)\n  • full    – capture the full scrolling page, downscaled to 1000px wide\n\nScreenshots are automatically optimized for token limits.Important: Use `browser_snapshot_dom` or `browser_accessible_tree` for structured info; resort to screenshots only when you truly need pixels (e.g. images, charts, maps, or to show the user).",
  func: async (input) => {
    try {
      return await withActivePage(page, async (activePage) => {
        const { ScreenshotManager: ScreenshotManager2 } = await __vitePreload(async () => {
          const { ScreenshotManager: ScreenshotManager3 } = await Promise.resolve().then(() => screenshotManager);
          return { ScreenshotManager: ScreenshotManager3 };
        }, true ? void 0 : void 0);
        const screenshotManager$1 = ScreenshotManager2.getInstance();
        const MAX_CHARS = MAX_SCREENSHOT_CHARS;
        const DEFAULT_WIDTH = 800;
        const FULL_PAGE_WIDTH = 1e3;
        const flags = input.split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);
        const fullPage = flags.includes("full");
        const targetWidth = fullPage ? FULL_PAGE_WIDTH : DEFAULT_WIDTH;
        let quality = 40;
        let buffer;
        try {
          buffer = await activePage.screenshot({
            type: "jpeg",
            fullPage,
            quality
          });
        } catch (screenshotError) {
          return `Error taking initial screenshot: ${screenshotError instanceof Error ? screenshotError.message : String(screenshotError)}`;
        }
        let base64 = buffer.toString("base64");
        let dimensions;
        try {
          dimensions = await activePage.evaluate(() => {
            return {
              width: document.documentElement.clientWidth,
              height: document.documentElement.clientHeight
            };
          });
        } catch (dimensionsError) {
          return `Error getting page dimensions: ${dimensionsError instanceof Error ? dimensionsError.message : String(dimensionsError)}`;
        }
        if (base64.length > MAX_CHARS) {
          let downscaledResult;
          try {
            downscaledResult = await activePage.evaluate(
              (params) => {
                const { b64, targetW, q } = params;
                return new Promise((resolve) => {
                  const img = new Image();
                  img.onload = () => {
                    const scale = targetW / img.width;
                    if (scale >= 1) {
                      resolve({
                        base64: b64,
                        width: img.width,
                        height: img.height
                      });
                      return;
                    }
                    const newWidth = targetW;
                    const newHeight = Math.round(img.height * scale);
                    try {
                      const canvas = document.createElement("canvas");
                      canvas.width = newWidth;
                      canvas.height = newHeight;
                      const ctx = canvas.getContext("2d");
                      if (!ctx) {
                        resolve({
                          base64: b64,
                          width: 0,
                          height: 0,
                          error: "Failed to get canvas context"
                        });
                        return;
                      }
                      ctx.drawImage(img, 0, 0, newWidth, newHeight);
                      const resizedBase64 = canvas.toDataURL("image/jpeg", q / 100).replace("data:image/jpeg;base64,", "");
                      resolve({
                        base64: resizedBase64,
                        width: newWidth,
                        height: newHeight
                      });
                    } catch (canvasError) {
                      resolve({
                        base64: b64,
                        width: 0,
                        height: 0,
                        error: "Canvas error: " + canvasError
                      });
                    }
                  };
                  img.onerror = () => {
                    resolve({
                      base64: b64,
                      width: 0,
                      height: 0,
                      error: "Failed to load image"
                    });
                  };
                  img.src = "data:image/jpeg;base64," + b64;
                });
              },
              { b64: base64, targetW: targetWidth, q: quality }
            );
          } catch (downscaleError) {
            return `Error running downscale script: ${downscaleError instanceof Error ? downscaleError.message : String(downscaleError)}`;
          }
          const result = downscaledResult;
          if (result.error) {
            return `Error downscaling image: ${result.error}`;
          }
          base64 = result.base64;
          dimensions.width = result.width;
          dimensions.height = result.height;
          while (base64.length > MAX_CHARS && quality > 10) {
            quality -= 5;
            let recompressedResult;
            try {
              recompressedResult = await activePage.evaluate(
                (params) => {
                  const { b64, w, h, q } = params;
                  return new Promise((resolve) => {
                    const img = new Image();
                    img.onload = () => {
                      try {
                        const canvas = document.createElement("canvas");
                        canvas.width = w;
                        canvas.height = h;
                        const ctx = canvas.getContext("2d");
                        if (!ctx) {
                          resolve({
                            base64: b64,
                            error: "Failed to get canvas context for recompression"
                          });
                          return;
                        }
                        ctx.drawImage(img, 0, 0, w, h);
                        const recompressedBase64 = canvas.toDataURL("image/jpeg", q / 100).replace("data:image/jpeg;base64,", "");
                        resolve({ base64: recompressedBase64 });
                      } catch (canvasError) {
                        resolve({
                          base64: b64,
                          error: "Canvas error during recompression: " + canvasError
                        });
                      }
                    };
                    img.onerror = () => {
                      resolve({
                        base64: b64,
                        error: "Failed to load image for recompression"
                      });
                    };
                    img.src = "data:image/jpeg;base64," + b64;
                  });
                },
                { b64: base64, w: dimensions.width, h: dimensions.height, q: quality }
              );
            } catch (recompressError) {
              return `Error running recompress script: ${recompressError instanceof Error ? recompressError.message : String(recompressError)}`;
            }
            const recompressResult = recompressedResult;
            if (recompressResult.error) {
              return `Error recompressing image: ${recompressResult.error}`;
            }
            base64 = recompressResult.base64;
          }
        }
        if (base64.length > MAX_CHARS) {
          return `Error: screenshot exceeds ${MAX_CHARS} characters even at minimum quality.`;
        }
        const screenshotData = {
          type: "image",
          source: {
            type: "base64",
            media_type: "image/jpeg",
            data: base64
          }
        };
        const screenshotId = screenshotManager$1.storeScreenshot(screenshotData);
        console.log(`Stored screenshot as ${screenshotId} (saved ${base64.length} characters)`);
        return JSON.stringify({
          type: "screenshotRef",
          id: screenshotId,
          note: `Screenshot captured (${fullPage ? "full page" : "viewport only"})`
        });
      });
    } catch (err) {
      return `Error taking screenshot: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserGetActiveTab = (page) => new DynamicTool({
  name: "browser_get_active_tab",
  description: "Returns information about the currently active tab, including its index, URL, and title.",
  func: async () => {
    try {
      const activePage = getCurrentPage(page);
      const pages = activePage.context().pages();
      const activeIndex = pages.indexOf(activePage);
      const url = activePage.url();
      const title = await activePage.title();
      try {
        const tabId = await getCurrentTabId(activePage);
        if (tabId) {
          chrome.runtime.sendMessage({
            action: "tabTitleChanged",
            tabId,
            title
          });
          console.log(`Sent tabTitleChanged message for active tab ${tabId} with title "${title}"`);
        }
      } catch (error) {
        console.error("Error updating UI with active tab info:", error);
      }
      return JSON.stringify({
        activeTabIndex: activeIndex,
        url,
        title,
        totalTabs: pages.length
      }, null, 2);
    } catch (err) {
      return `Error getting active tab: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserNavigateTab = (page) => new DynamicTool({
  name: "browser_navigate_tab",
  description: "Navigate a specific tab to a URL. Input format: 'tabIndex|url' (e.g., '1|https://example.com')",
  func: async (input) => {
    try {
      const parts = input.split("|");
      if (parts.length !== 2) {
        return "Error: Input must be in the format 'tabIndex|url'";
      }
      const indexStr = parts[0].trim();
      const url = parts[1].trim();
      const idx = Number(indexStr);
      if (Number.isNaN(idx)) {
        return "Error: Tab index must be a number";
      }
      const activePage = getCurrentPage(page);
      const pages = activePage.context().pages();
      if (idx < 0 || idx >= pages.length) {
        return `Error: Tab index ${idx} out of range (0‑${pages.length - 1})`;
      }
      await pages[idx].goto(url);
      try {
        const tabId = await getCurrentTabId(pages[idx]);
        const newTitle = await pages[idx].title();
        if (tabId && pages[idx] === getCurrentPage(page)) {
          chrome.runtime.sendMessage({
            action: "tabTitleChanged",
            tabId,
            title: newTitle
          });
          console.log(`Sent tabTitleChanged message for tab ${tabId} after navigation to ${url}`);
        }
        if (tabId) {
          chrome.runtime.sendMessage({
            action: "targetChanged",
            tabId,
            url
          });
        }
      } catch (error) {
        console.error("Error updating UI after tab navigation:", error);
      }
      return `Successfully navigated tab ${idx} to ${url}`;
    } catch (error) {
      return `Error: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const browserScreenshotTab = (page) => new DynamicTool({
  name: "browser_screenshot_tab",
  description: "Take a screenshot of a specific tab by index. Input format: 'tabIndex[,flags]' (e.g., '1,full')",
  func: async (input) => {
    try {
      const parts = input.split(",");
      const tabIndexStr = parts[0].trim();
      const flags = parts.slice(1).map((f2) => f2.trim());
      const tabIndex = parseInt(tabIndexStr, 10);
      if (isNaN(tabIndex)) {
        return "Error: First parameter must be a tab index number";
      }
      const activePage = getCurrentPage(page);
      const pages = activePage.context().pages();
      if (tabIndex < 0 || tabIndex >= pages.length) {
        return `Error: Tab index ${tabIndex} out of range (0-${pages.length - 1})`;
      }
      const targetPage = pages[tabIndex];
      const fullPage = flags.includes("full");
      const quality = 40;
      const { ScreenshotManager: ScreenshotManager2 } = await __vitePreload(async () => {
        const { ScreenshotManager: ScreenshotManager3 } = await Promise.resolve().then(() => screenshotManager);
        return { ScreenshotManager: ScreenshotManager3 };
      }, true ? void 0 : void 0);
      const screenshotManager$1 = ScreenshotManager2.getInstance();
      const buffer = await targetPage.screenshot({
        type: "jpeg",
        fullPage,
        quality
      });
      const base64 = buffer.toString("base64");
      const screenshotData = {
        type: "image",
        source: {
          type: "base64",
          media_type: "image/jpeg",
          data: base64
        }
      };
      const screenshotId = screenshotManager$1.storeScreenshot(screenshotData);
      console.log(`Stored tab screenshot as ${screenshotId} (saved ${base64.length} characters)`);
      return JSON.stringify({
        type: "screenshotRef",
        id: screenshotId,
        note: `Screenshot captured of tab ${tabIndex} (${fullPage ? "full page" : "viewport only"})`
      });
    } catch (err) {
      return `Error taking screenshot: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserTabList = (page) => new DynamicTool({
  name: "browser_tab_list",
  description: "Return a list of open tabs with their indexes and URLs.",
  func: async () => {
    try {
      const pages = page.context().pages();
      const list = pages.map((p, i) => `${i}: ${p.url() || "<blank>"}`).join("\n");
      return list || "No tabs.";
    } catch (err) {
      return `Error listing tabs: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserTabNew = (page) => new DynamicTool({
  name: "browser_tab_new",
  description: "Open a new tab. Optional input = URL to navigate to (otherwise blank tab). Note: This does NOT automatically switch to the new tab. Use browser_tab_select after creating a new tab if you want to interact with it.",
  func: async (input) => {
    try {
      const currentTabId = await getCurrentTabId(page);
      if (!currentTabId) {
        throw new Error("Could not determine current tab ID");
      }
      const windowId = await getWindowId(page, currentTabId);
      if (!windowId) {
        throw new Error("Could not determine window ID for current tab");
      }
      const newTabId = await createNewTab(windowId, input.trim() || void 0);
      const crxApp = await getCrxAppForTab(currentTabId);
      const pages = crxApp.context().pages();
      const newTabIndex = pages.length - 1;
      let newTitle = "New Tab";
      try {
        await new Promise((resolve) => setTimeout(resolve, 500));
        newTitle = await pages[newTabIndex].title();
        chrome.runtime.sendMessage({
          action: "targetCreated",
          tabId: newTabId,
          targetInfo: {
            title: newTitle,
            url: await pages[newTabIndex].url()
          }
        });
        console.log(`Sent targetCreated message for new tab ${newTabId} with title "${newTitle}"`);
      } catch (titleError) {
        console.error("Error getting new tab title:", titleError);
      }
      return `Opened new tab (#${newTabIndex}) in window ${windowId}. To interact with this tab, use browser_tab_select with index ${newTabIndex}.`;
    } catch (err) {
      return `Error opening new tab: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserTabSelect = (page) => new DynamicTool({
  name: "browser_tab_select",
  description: "Switch focus to a tab by index. Input = integer index from browser_tab_list. IMPORTANT: After switching tabs, you must use browser_get_active_tab to confirm the switch was successful and to get information about the new active tab.",
  func: async (input) => {
    try {
      const idx = Number(input.trim());
      if (Number.isNaN(idx))
        return "Error: input must be a tab index (integer).";
      const pages = page.context().pages();
      if (idx < 0 || idx >= pages.length)
        return `Error: index ${idx} out of range (0‑${pages.length - 1}).`;
      await pages[idx].bringToFront();
      setCurrentPage(pages[idx]);
      const newUrl = pages[idx].url();
      let newTitle = "Unknown";
      try {
        newTitle = await pages[idx].title();
        const selectedTabId = await getCurrentTabId(pages[idx]);
        const originalTabId = await getCurrentTabId(page);
        if (selectedTabId) {
          chrome.runtime.sendMessage({
            action: "activeTabChanged",
            oldTabId: originalTabId,
            newTabId: selectedTabId,
            title: newTitle,
            url: newUrl
          });
          console.log(`Sent activeTabChanged message from tab ${originalTabId} to ${selectedTabId}`);
          chrome.runtime.sendMessage({
            action: "tabTitleChanged",
            tabId: selectedTabId,
            title: newTitle
          });
          console.log(`Sent tabTitleChanged message for tab ${selectedTabId} with title "${newTitle}"`);
        }
      } catch (titleError) {
        console.error("Error getting tab title:", titleError);
      }
      return `Switched to tab ${idx}. Now active: "${newTitle}" (${newUrl}). Use browser_get_active_tab for more details.`;
    } catch (err) {
      return `Error selecting tab: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const browserTabClose = (page) => new DynamicTool({
  name: "browser_tab_close",
  description: "Close a tab. Input = index to close (defaults to current tab if blank).",
  func: async (input) => {
    try {
      const pages = page.context().pages();
      const idx = input.trim() === "" ? pages.indexOf(page) : Number(input.trim());
      if (Number.isNaN(idx) || idx < 0 || idx >= pages.length)
        return "Error: invalid tab index.";
      const tabToClose = pages[idx];
      const tabId = await getCurrentTabId(tabToClose);
      await tabToClose.close();
      if (pages.indexOf(page) === idx && pages.length > 1) {
        const newActiveIdx = Math.max(0, idx - 1);
        if (pages[newActiveIdx]) {
          setCurrentPage(pages[newActiveIdx]);
          try {
            const newActiveTabId = await getCurrentTabId(pages[newActiveIdx]);
            const newActiveTitle = await pages[newActiveIdx].title();
            if (newActiveTabId) {
              chrome.runtime.sendMessage({
                action: "tabTitleChanged",
                tabId: newActiveTabId,
                title: newActiveTitle
              });
              console.log(`Tab ${idx} closed, switched to tab ${newActiveIdx} with title "${newActiveTitle}"`);
            }
          } catch (titleError) {
            console.error("Error getting new active tab title:", titleError);
          }
        }
      }
      if (tabId) {
        chrome.runtime.sendMessage({
          action: "targetDestroyed",
          tabId,
          url: "about:blank"
          // We don't have the URL anymore since the tab is closed
        });
      }
      return `Closed tab ${idx}.`;
    } catch (err) {
      return `Error closing tab: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
async function getWindowId(page, tabId) {
  const windowId = getWindowForTab(tabId);
  if (windowId) {
    return windowId;
  }
  try {
    const tab = await chrome.tabs.get(tabId);
    return tab.windowId;
  } catch (error) {
    console.error("Error getting window ID:", error);
  }
  return void 0;
}
const startExtract = (page) => new DynamicTool({
  name: "start_extract",
  description: "Start content extraction from HTML. Provide URL and HTML content.",
  func: async (input) => {
    try {
      return await withActivePage(page, async (activePage) => {
        const tabId = await getCurrentTabId(activePage);
        const title = await activePage.title();
        const markdownFromPage = await page.evaluate(async () => {
          const MAX_DEPTH = 20;
          const tagsToRemove = [
            "script",
            "style",
            "nav",
            "footer",
            "aside",
            "noscript",
            "iframe",
            "header",
            "form",
            "svg",
            "canvas",
            "link",
            "meta"
          ];
          tagsToRemove.forEach((tag) => {
            document.querySelectorAll(tag).forEach((el) => el.remove());
          });
          const trimTextNodes = (node) => {
            node.childNodes.forEach((child) => {
              var _a2;
              if (child.nodeType === Node.TEXT_NODE) {
                child.textContent = ((_a2 = child.textContent) == null ? void 0 : _a2.replace(/\s+/g, " ").trim()) || "";
              } else if (child.nodeType === Node.ELEMENT_NODE) {
                trimTextNodes(child);
              }
            });
          };
          trimTextNodes(document);
          const domToMarkdown = (dom) => {
            const tagHandlers = /* @__PURE__ */ new Map([
              ["h1", (_, c) => `# ${c}

`],
              ["h2", (_, c) => `## ${c}

`],
              ["h3", (_, c) => `### ${c}

`],
              ["h4", (_, c) => `#### ${c}

`],
              ["h5", (_, c) => `##### ${c}

`],
              ["h6", (_, c) => `###### ${c}

`],
              ["p", (_, c) => `${c}

`],
              ["strong", (_, c) => `**${c}**`],
              ["b", (_, c) => `**${c}**`],
              ["em", (_, c) => `*${c}*`],
              ["i", (_, c) => `*${c}*`],
              ["a", (el, c) => `[${c}](${el.getAttribute("href")})`],
              ["br", () => `
`],
              ["hr", () => `
---
`],
              ["img", (el) => {
                const alt = el.getAttribute("alt") || "";
                const src = el.getAttribute("src") || "";
                return `![${alt}](${src})`;
              }],
              ["code", (_, c) => `\`${c}\``],
              ["pre", (el) => `
\`\`\`
${(el.textContent || "").trim()}
\`\`\`

`],
              ["blockquote", (_, c) => c.replace(/^/gm, "> ") + "\n\n"]
            ]);
            const walker = (node, depth = 0) => {
              if (depth > MAX_DEPTH) return "";
              if (!node) return "";
              if (node.nodeType === Node.TEXT_NODE) {
                return node.data.trim();
              }
              if (node.nodeType !== Node.ELEMENT_NODE) {
                return "";
              }
              const el = node;
              const tag = el.tagName.toLowerCase();
              let content = "";
              for (let i = 0; i < el.childNodes.length; i++) {
                content += walker(el.childNodes[i], depth + 1);
              }
              if (tag === "ul") {
                return Array.from(el.children).map((li) => `- ${walker(li, depth + 1)}
`).join("") + "\n";
              }
              if (tag === "ol") {
                return Array.from(el.children).map((li, i) => `${i + 1}. ${walker(li, depth + 1)}
`).join("") + "\n";
              }
              if (tag === "li") {
                return content;
              }
              if (tag === "table") {
                const rows = Array.from(el.querySelectorAll("tr"));
                const markdownRows = [];
                rows.forEach((tr, rowIndex) => {
                  const cells = Array.from(tr.children).map((td) => walker(td, depth + 1));
                  const rowLine = `| ${cells.join(" | ")} |`;
                  if (rowIndex === 0) {
                    const separator = `| ${cells.map(() => "---").join(" | ")} |`;
                    markdownRows.push(rowLine, separator);
                  } else {
                    markdownRows.push(rowLine);
                  }
                });
                return markdownRows.join("\n") + "\n\n";
              }
              const handler = tagHandlers.get(tag);
              if (handler) {
                return handler(el, content);
              }
              return content;
            };
            return walker(dom, 0).trim();
          };
          return domToMarkdown(document.body);
        });
        if (tabId) {
          chrome.runtime.sendMessage({
            action: "download-markdown",
            tabId,
            content: markdownFromPage,
            filename: "page.md"
          });
          console.log(`Sent markdown message for tab ${tabId} with title "${title}" from start_extract`);
        }
        console.log("markdown", markdownFromPage);
        return `scrape page finished`;
      });
    } catch (error) {
      console.log(`Error parsing '${input}': ${error instanceof Error ? error.message : String(error)}`);
      return `Error clicking '${input}': ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const _DuckDBService = class _DuckDBService {
  constructor() {
    __publicField(this, "db", null);
    __publicField(this, "connection", null);
    __publicField(this, "isInitialized", false);
    __publicField(this, "tables", /* @__PURE__ */ new Map());
    __publicField(this, "loadStatus", "not_initialized");
    __publicField(this, "progressCallback", null);
    __publicField(this, "errorMessage", null);
    __publicField(this, "initializationPromise", null);
  }
  /**
   * Get singleton instance
   */
  static getInstance() {
    if (!_DuckDBService.instance) {
      _DuckDBService.instance = new _DuckDBService();
    }
    return _DuckDBService.instance;
  }
  /**
   * Get current loading status
   */
  getLoadStatus() {
    return this.loadStatus;
  }
  /**
   * Get error message if status is Error
   */
  getErrorMessage() {
    return this.errorMessage;
  }
  /**
   * Set progress callback for download tracking
   */
  setProgressCallback(callback) {
    this.progressCallback = callback;
  }
  /**
   * Check if DuckDB is ready to use
   */
  isReady() {
    return this.loadStatus === "ready" && this.isInitialized;
  }
  /**
   * Initialize DuckDB WASM
   */
  async init() {
    if (this.isInitialized && this.loadStatus === "ready") {
      logWithTimestamp("DuckDBService already initialized");
      return;
    }
    if (this.initializationPromise) {
      logWithTimestamp("DuckDBService initialization in progress, waiting...");
      return this.initializationPromise;
    }
    this.initializationPromise = this._performInit();
    try {
      await this.initializationPromise;
    } finally {
      this.initializationPromise = null;
    }
  }
  /**
   * Perform actual initialization with progress tracking
   */
  async _performInit() {
    try {
      this.loadStatus = "downloading";
      this.errorMessage = null;
      logWithTimestamp("Initializing DuckDB WASM...");
      const duckdb = await __vitePreload(() => import("./duckdb-browser-BQMq42ia.js"), true ? [] : void 0);
      const isExtension = typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.id;
      const DUCKDB_VERSION = "1.30.0";
      const wasmUrl = `https://cdn.jsdelivr.net/npm/@duckdb/duckdb-wasm@${DUCKDB_VERSION}/dist/duckdb-eh.wasm`;
      const baseUrl = isExtension ? chrome.runtime.getURL("duckdb/") : "/duckdb/";
      const workerUrl = baseUrl + "duckdb-browser-eh.worker.js";
      logWithTimestamp(`Loading DuckDB WASM from CDN: ${wasmUrl}`);
      await this._fetchWithProgress(wasmUrl);
      logWithTimestamp(`DuckDB WASM downloaded successfully`);
      const customBundle = {
        mainModule: wasmUrl,
        mainWorker: workerUrl,
        pthreadWorker: null
        // Not needed for single-threaded mode
      };
      logWithTimestamp(`Using local DuckDB bundle: ${customBundle.mainWorker}`);
      const worker = new Worker(customBundle.mainWorker);
      const logger = new duckdb.ConsoleLogger();
      this.db = new duckdb.AsyncDuckDB(logger, worker);
      await this.db.instantiate(customBundle.mainModule, customBundle.pthreadWorker);
      this.connection = await this.db.connect();
      this.isInitialized = true;
      this.loadStatus = "ready";
      logWithTimestamp("DuckDB WASM initialized successfully with local files");
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      this.errorMessage = errorMsg;
      this.loadStatus = "error";
      this.isInitialized = false;
      logWithTimestamp(
        `Error initializing DuckDB: ${errorMsg}`,
        "error"
      );
      throw new Error(`Failed to initialize DuckDB: ${errorMsg}

Note: Data Analyze feature requires internet connection to download DuckDB engine (~32MB) from CDN.`);
    }
  }
  /**
   * Fetch file with progress tracking
   */
  async _fetchWithProgress(url) {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Failed to fetch ${url}: ${response.status} ${response.statusText}`);
    }
    const contentLength = response.headers.get("content-length");
    const total = contentLength ? parseInt(contentLength, 10) : 0;
    if (!response.body) {
      throw new Error("Response body is null");
    }
    const reader = response.body.getReader();
    const chunks = [];
    let loaded = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      loaded += value.length;
      if (this.progressCallback && total > 0) {
        const percentage = Math.round(loaded / total * 100);
        this.progressCallback(loaded, total, percentage);
      }
    }
    const totalLength = chunks.reduce((acc, chunk) => acc + chunk.length, 0);
    const result = new Uint8Array(totalLength);
    let offset = 0;
    for (const chunk of chunks) {
      result.set(chunk, offset);
      offset += chunk.length;
    }
    return result.buffer;
  }
  /**
   * Ensure database is initialized
   */
  async ensureInitialized() {
    if (!this.isInitialized) {
      await this.init();
    }
    if (!this.isInitialized || !this.connection) {
      throw new Error("DuckDB is not available. This may be due to browser extension limitations or network restrictions. DuckDB WASM requires loading external resources which may be blocked.");
    }
  }
  /**
   * Check if DuckDB is available
   */
  isAvailable() {
    return this.isInitialized && this.connection !== null;
  }
  /**
   * Sanitize table name (remove special characters, ensure valid SQL identifier)
   */
  sanitizeTableName(name) {
    let tableName = name.replace(/\.(csv|json|txt|xlsx|xls)$/i, "");
    tableName = tableName.replace(/[^a-zA-Z0-9_]/g, "_");
    if (!/^[a-zA-Z]/.test(tableName)) {
      tableName = "t_" + tableName;
    }
    tableName = tableName.substring(0, 64);
    return tableName.toLowerCase();
  }
  /**
   * Detect column type from sample values
   */
  detectColumnType(values) {
    const samples = values.filter((v) => v && v.trim()).slice(0, 100);
    if (samples.length === 0) {
      return "VARCHAR";
    }
    const allNumbers = samples.every((v) => !isNaN(parseFloat(v)) && isFinite(parseFloat(v)));
    if (allNumbers) {
      const allIntegers = samples.every((v) => Number.isInteger(parseFloat(v)));
      return allIntegers ? "INTEGER" : "DOUBLE";
    }
    const allBooleans = samples.every(
      (v) => v.toLowerCase() === "true" || v.toLowerCase() === "false" || v === "0" || v === "1"
    );
    if (allBooleans) {
      return "BOOLEAN";
    }
    const datePattern = /^\d{4}-\d{2}-\d{2}/;
    const allDates = samples.every((v) => datePattern.test(v));
    if (allDates) {
      return "DATE";
    }
    return "VARCHAR";
  }
  /**
   * Create table from CSV data
   */
  async createTableFromCSV(fileName, csvContent) {
    await this.ensureInitialized();
    try {
      const tableName = this.sanitizeTableName(fileName);
      logWithTimestamp(`Creating table "${tableName}" from CSV file "${fileName}"`);
      const lines = csvContent.split("\n").filter((line) => line.trim());
      if (lines.length < 2) {
        throw new Error("CSV file must have at least a header row and one data row");
      }
      const headers = lines[0].split(",").map((h) => h.trim().replace(/^"|"$/g, ""));
      const columns = headers.map((h) => {
        let colName = h.replace(/[^a-zA-Z0-9_]/g, "_");
        if (!/^[a-zA-Z]/.test(colName)) {
          colName = "col_" + colName;
        }
        return colName.toLowerCase();
      });
      const dataRows = lines.slice(1).map(
        (line) => line.split(",").map((cell) => cell.trim().replace(/^"|"$/g, ""))
      );
      const columnTypes = columns.map((col, idx) => {
        const values = dataRows.map((row) => row[idx] || "");
        return this.detectColumnType(values);
      });
      await this.connection.query(`DROP TABLE IF EXISTS ${tableName}`);
      const createTableSQL = `
        CREATE TABLE ${tableName} (
          ${columns.map((col, idx) => `"${col}" ${columnTypes[idx]}`).join(", ")}
        )
      `;
      await this.connection.query(createTableSQL);
      logWithTimestamp(`Created table schema for ${tableName}`);
      for (const row of dataRows) {
        const values = row.map((val, idx) => {
          if (!val || val === "") return "NULL";
          const colType = columnTypes[idx];
          if (colType === "VARCHAR" || colType === "DATE") {
            return `'${val.replace(/'/g, "''")}'`;
          }
          return val;
        });
        const insertSQL = `INSERT INTO ${tableName} VALUES (${values.join(", ")})`;
        await this.connection.query(insertSQL);
      }
      const countResult = await this.connection.query(`SELECT COUNT(*) as count FROM ${tableName}`);
      const rowCount = countResult.toArray()[0].count;
      const tableInfo = {
        name: tableName,
        rowCount: Number(rowCount),
        columns: columns.map((col, idx) => ({
          name: col,
          type: columnTypes[idx]
        })),
        createdAt: Date.now(),
        fileName
      };
      this.tables.set(tableName, tableInfo);
      logWithTimestamp(`Successfully created table ${tableName} with ${rowCount} rows`);
      return tableName;
    } catch (error) {
      logWithTimestamp(
        `Error creating table from CSV: ${error instanceof Error ? error.message : String(error)}`,
        "error"
      );
      throw error;
    }
  }
  /**
   * Create table from JSON data
   */
  async createTableFromJSON(fileName, jsonContent) {
    await this.ensureInitialized();
    try {
      const tableName = this.sanitizeTableName(fileName);
      logWithTimestamp(`Creating table "${tableName}" from JSON file "${fileName}"`);
      const data = JSON.parse(jsonContent);
      if (!Array.isArray(data)) {
        throw new Error("JSON must be an array of objects");
      }
      if (data.length === 0) {
        throw new Error("JSON array is empty");
      }
      const firstObj = data[0];
      const columns = Object.keys(firstObj);
      if (columns.length === 0) {
        throw new Error("JSON objects must have at least one property");
      }
      const columnTypes = columns.map((col) => {
        const values = data.map((obj) => String(obj[col] ?? ""));
        return this.detectColumnType(values);
      });
      const sanitizedColumns = columns.map((col) => {
        let colName = col.replace(/[^a-zA-Z0-9_]/g, "_");
        if (!/^[a-zA-Z]/.test(colName)) {
          colName = "col_" + colName;
        }
        return colName.toLowerCase();
      });
      await this.connection.query(`DROP TABLE IF EXISTS ${tableName}`);
      const createTableSQL = `
        CREATE TABLE ${tableName} (
          ${sanitizedColumns.map((col, idx) => `"${col}" ${columnTypes[idx]}`).join(", ")}
        )
      `;
      await this.connection.query(createTableSQL);
      logWithTimestamp(`Created table schema for ${tableName}`);
      for (const obj of data) {
        const values = columns.map((col, idx) => {
          const val = obj[col];
          if (val === null || val === void 0 || val === "") return "NULL";
          const colType = columnTypes[idx];
          if (colType === "VARCHAR" || colType === "DATE") {
            return `'${String(val).replace(/'/g, "''")}'`;
          }
          return String(val);
        });
        const insertSQL = `INSERT INTO ${tableName} VALUES (${values.join(", ")})`;
        await this.connection.query(insertSQL);
      }
      const countResult = await this.connection.query(`SELECT COUNT(*) as count FROM ${tableName}`);
      const rowCount = countResult.toArray()[0].count;
      const tableInfo = {
        name: tableName,
        rowCount: Number(rowCount),
        columns: sanitizedColumns.map((col, idx) => ({
          name: col,
          type: columnTypes[idx]
        })),
        createdAt: Date.now(),
        fileName
      };
      this.tables.set(tableName, tableInfo);
      logWithTimestamp(`Successfully created table ${tableName} with ${rowCount} rows`);
      return tableName;
    } catch (error) {
      logWithTimestamp(
        `Error creating table from JSON: ${error instanceof Error ? error.message : String(error)}`,
        "error"
      );
      throw error;
    }
  }
  /**
   * Execute SQL query
   */
  async query(sql) {
    await this.ensureInitialized();
    try {
      logWithTimestamp(`Executing query: ${sql.substring(0, 100)}...`);
      const result = await this.connection.query(sql);
      const arrow = result.toArray();
      const columns = result.schema.fields.map((f2) => f2.name);
      const rows = arrow.map(
        (row) => columns.map((col) => row[col])
      );
      logWithTimestamp(`Query returned ${rows.length} rows`);
      return {
        columns,
        rows,
        rowCount: rows.length
      };
    } catch (error) {
      logWithTimestamp(
        `Error executing query: ${error instanceof Error ? error.message : String(error)}`,
        "error"
      );
      throw error;
    }
  }
  /**
   * List all tables
   */
  async listTables() {
    await this.ensureInitialized();
    return Array.from(this.tables.values());
  }
  /**
   * Get table info
   */
  async getTableInfo(tableName) {
    await this.ensureInitialized();
    return this.tables.get(tableName) || null;
  }
  /**
   * Drop table
   */
  async dropTable(tableName) {
    await this.ensureInitialized();
    try {
      await this.connection.query(`DROP TABLE IF EXISTS ${tableName}`);
      this.tables.delete(tableName);
      logWithTimestamp(`Dropped table ${tableName}`);
    } catch (error) {
      logWithTimestamp(
        `Error dropping table: ${error instanceof Error ? error.message : String(error)}`,
        "error"
      );
      throw error;
    }
  }
  /**
   * Clear all tables
   */
  async clearAllTables() {
    await this.ensureInitialized();
    try {
      for (const tableName of this.tables.keys()) {
        await this.connection.query(`DROP TABLE IF EXISTS ${tableName}`);
      }
      this.tables.clear();
      logWithTimestamp("Cleared all tables");
    } catch (error) {
      logWithTimestamp(
        `Error clearing tables: ${error instanceof Error ? error.message : String(error)}`,
        "error"
      );
      throw error;
    }
  }
  /**
   * Get preview of table data (first N rows)
   */
  async getTablePreview(tableName, limit = 10) {
    return this.query(`SELECT * FROM ${tableName} LIMIT ${limit}`);
  }
  /**
   * Get table schema
   */
  async describeTable(tableName) {
    await this.ensureInitialized();
    const tableInfo = this.tables.get(tableName);
    if (!tableInfo) {
      throw new Error(`Table ${tableName} not found`);
    }
    const lines = [
      `Table: ${tableName}`,
      `File: ${tableInfo.fileName}`,
      `Rows: ${tableInfo.rowCount}`,
      `Created: ${new Date(tableInfo.createdAt).toLocaleString()}`,
      "",
      "Columns:",
      ...tableInfo.columns.map((col) => `  - ${col.name} (${col.type})`)
    ];
    return lines.join("\n");
  }
};
__publicField(_DuckDBService, "instance", null);
let DuckDBService = _DuckDBService;
const getDuckDB = () => DuckDBService.getInstance();
const queryData = (page) => new DynamicTool({
  name: "query_data",
  description: `
Execute SQL queries on uploaded data tables in DuckDB.

Input: SQL query string (e.g., "SELECT * FROM my_table LIMIT 10")

Returns: Query results with columns and rows

Examples:
  • SELECT * FROM sales LIMIT 10 - View first 10 rows
  • SELECT COUNT(*) FROM users - Count total rows
  • SELECT category, SUM(amount) FROM transactions GROUP BY category - Aggregate data
  • SELECT * FROM products WHERE price > 100 ORDER BY price DESC - Filter and sort

Notes:
  • Table names come from uploaded file names (sanitized)
  • Use list_data_tables to see available tables
  • Supports full SQL: JOIN, GROUP BY, WHERE, ORDER BY, etc.
`,
  func: async (sql) => {
    try {
      const result = await getDuckDB().query(sql);
      let output = `Query returned ${result.rowCount} rows

`;
      if (result.rowCount === 0) {
        return output + "No results found.";
      }
      output += "| " + result.columns.join(" | ") + " |\n";
      output += "| " + result.columns.map(() => "---").join(" | ") + " |\n";
      const displayRows = result.rows.slice(0, 50);
      displayRows.forEach((row) => {
        output += "| " + row.map((cell) => String(cell ?? "NULL")).join(" | ") + " |\n";
      });
      if (result.rowCount > 50) {
        output += `
... and ${result.rowCount - 50} more rows (use LIMIT to control output)`;
      }
      return output;
    } catch (err) {
      return `Error executing query: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const listDataTables = (page) => new DynamicTool({
  name: "list_data_tables",
  description: `
List all data tables currently loaded in DuckDB.

Input: None (empty string)

Returns: List of tables with row counts and column information

Use this to see what data is available before running queries.
`,
  func: async () => {
    try {
      const tables = await getDuckDB().listTables();
      if (tables.length === 0) {
        return "No data tables loaded. Upload CSV or JSON files first.";
      }
      let output = `Found ${tables.length} data table(s):

`;
      tables.forEach((table, index) => {
        output += `${index + 1}. **${table.name}** (from ${table.fileName})
`;
        output += `   - Rows: ${table.rowCount}
`;
        output += `   - Columns: ${table.columns.map((c) => `${c.name} (${c.type})`).join(", ")}
`;
        output += `   - Created: ${new Date(table.createdAt).toLocaleString()}

`;
      });
      return output;
    } catch (err) {
      return `Error listing tables: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const describeDataTable = (page) => new DynamicTool({
  name: "describe_data_table",
  description: `
Get detailed schema information for a specific data table.

Input: Table name (e.g., "sales_data")

Returns: Table schema with column names, types, and metadata

Use this to understand the structure before querying.
`,
  func: async (tableName) => {
    try {
      const description = await getDuckDB().describeTable(tableName.trim());
      return description;
    } catch (err) {
      return `Error describing table: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const previewDataTable = (page) => new DynamicTool({
  name: "preview_data_table",
  description: `
Preview the first 10 rows of a data table.

Input: Table name (e.g., "sales_data")

Returns: First 10 rows in table format

Quick way to see sample data without writing SQL.
`,
  func: async (tableName) => {
    try {
      const result = await getDuckDB().getTablePreview(tableName.trim(), 10);
      let output = `Preview of ${tableName} (showing ${result.rowCount} rows):

`;
      output += "| " + result.columns.join(" | ") + " |\n";
      output += "| " + result.columns.map(() => "---").join(" | ") + " |\n";
      result.rows.forEach((row) => {
        output += "| " + row.map((cell) => String(cell ?? "NULL")).join(" | ") + " |\n";
      });
      return output;
    } catch (err) {
      return `Error previewing table: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const dropDataTable = (page) => new DynamicTool({
  name: "drop_data_table",
  description: `
Delete a data table from DuckDB.

Input: Table name (e.g., "sales_data")

Returns: Confirmation message

Use this to remove tables you no longer need.
`,
  func: async (tableName) => {
    try {
      await getDuckDB().dropTable(tableName.trim());
      return `Successfully dropped table "${tableName}"`;
    } catch (err) {
      return `Error dropping table: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
const clearAllDataTables = (page) => new DynamicTool({
  name: "clear_all_data_tables",
  description: `
Delete all data tables from DuckDB.

Input: None (empty string)

Returns: Confirmation message

Use this to clear all loaded data and start fresh.
`,
  func: async () => {
    try {
      await getDuckDB().clearAllTables();
      return "Successfully cleared all data tables";
    } catch (err) {
      return `Error clearing tables: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
});
function getAllTools(page) {
  const tools = [
    // Navigation tools
    browserNavigate(page),
    browserWaitForNavigation(page),
    browserNavigateBack(page),
    browserNavigateForward(page),
    // Tab context tools
    browserGetActiveTab(page),
    browserNavigateTab(page),
    browserScreenshotTab(page),
    // Interaction tools
    browserClick(page),
    browserType(page),
    browserHandleDialog(page),
    // Observation tools
    browserGetTitle(page),
    browserSnapshotDom(page),
    browserQuery(page),
    browserAccessibleTree(page),
    browserReadText(page),
    browserScreenshot(page),
    // Mouse tools
    browserMoveMouse(page),
    browserClickXY(page),
    browserDrag(page),
    // Keyboard tools
    browserPressKey(page),
    browserKeyboardType(page),
    // Tab tools
    browserTabList(page),
    browserTabNew(page),
    browserTabSelect(page),
    browserTabClose(page),
    // Memory tools
    saveMemory(),
    lookupMemories(),
    getAllMemories(),
    deleteMemory(),
    clearAllMemories(),
    // Vector database tools
    createVectorCollection(),
    listVectorCollections(),
    deleteVectorCollection(),
    storeVector(),
    searchVectors(),
    getVectorDocument(),
    deleteVectorDocument(),
    listVectorDocuments(),
    clearAllVectorData(),
    // Knowledge graph tools
    createKnowledgeNode(),
    addKnowledgeEdge(),
    listKnowledgeNodes(),
    searchKnowledge(),
    traverseKnowledgeGraph(),
    hybridKnowledgeQuery(),
    findKnowledgeIntersection(),
    getKnowledgeGraphStats(),
    clearKnowledgeGraph(),
    getKnowledgeNode(),
    // Enhanced read tools
    browserReadTextEnhanced(page),
    browserGetPageSummary(page),
    browserReadMainContent(page),
    browserGetCacheStats(),
    browserClearCache(),
    // AST read tools
    browserReadTextAST(page),
    browserGetOverview(page),
    browserGetSection(page),
    browserGetPageSummaryAST(page),
    browserGetASTStats(page),
    browserGetTopContent(page),
    browserManageASTCache(),
    // Extract tools
    startExtract(page),
    // DuckDB data query tools
    queryData(),
    listDataTables(),
    describeDataTable(),
    previewDataTable(),
    dropDataTable(),
    clearAllDataTables()
    // Notion tools are not included here as they require a NotionMCPClient instance
    // Use getAllNotionTools(client) from ./notionTools for Notion-specific tools
  ];
  return tools;
}
const notionCreatePage = (client) => new DynamicTool({
  name: "notion_create_page",
  description: `Create a new page in Notion. 
      Input should be a JSON string with:
      - parent: object with database_id or page_id where the page should be created
      - title: the title of the page
      - properties: optional page properties object
      - children: optional array of block children`,
  func: async (input) => {
    try {
      const options = JSON.parse(input);
      if (!options.parent || !options.title) {
        return "Error: Both 'parent' and 'title' are required fields";
      }
      const createParams = {
        parent: options.parent,
        properties: {
          title: {
            title: [{ text: { content: options.title } }]
          },
          ...options.properties
        },
        ...options.children && { children: options.children }
      };
      const result = await client.createPage(createParams);
      return `Successfully created page "${options.title}". Page ID: ${result.id || "unknown"}`;
    } catch (error) {
      if (error instanceof SyntaxError) {
        return `Error: Invalid JSON input. Please provide valid JSON with parent and title fields.`;
      }
      return `Error creating page: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const notionUpdatePage = (client) => new DynamicTool({
  name: "notion_update_page",
  description: `Update an existing page in Notion.
      Input should be a JSON string with:
      - pageId: the ID of the page to update
      - properties: optional properties to update
      - archived: optional boolean to archive/unarchive the page`,
  func: async (input) => {
    try {
      const options = JSON.parse(input);
      if (!options.pageId) {
        return "Error: 'pageId' is required";
      }
      const updateParams = {};
      if (options.properties) {
        updateParams.properties = options.properties;
      }
      if (typeof options.archived === "boolean") {
        updateParams.archived = options.archived;
      }
      await client.updatePage(options.pageId, updateParams);
      return `Successfully updated page ${options.pageId}`;
    } catch (error) {
      if (error instanceof SyntaxError) {
        return `Error: Invalid JSON input. Please provide valid JSON with pageId field.`;
      }
      return `Error updating page: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const notionGetPage = (client) => new DynamicTool({
  name: "notion_get_page",
  description: "Get a page from Notion by its ID. Input should be a page ID string.",
  func: async (pageId) => {
    var _a2, _b, _c, _d, _e, _f, _g, _h;
    try {
      if (!pageId || pageId.trim() === "") {
        return "Error: Page ID is required";
      }
      const result = await client.getPage(pageId.trim());
      const title = ((_d = (_c = (_b = (_a2 = result.properties) == null ? void 0 : _a2.title) == null ? void 0 : _b.title) == null ? void 0 : _c[0]) == null ? void 0 : _d.plain_text) || ((_h = (_g = (_f = (_e = result.properties) == null ? void 0 : _e.Name) == null ? void 0 : _f.title) == null ? void 0 : _g[0]) == null ? void 0 : _h.plain_text) || "No title";
      return `Successfully retrieved page ${pageId}. Title: ${title}`;
    } catch (error) {
      return `Error getting page: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const notionQueryDatabase = (client) => new DynamicTool({
  name: "notion_query_database",
  description: `Query a Notion database.
      Input should be a JSON string with:
      - databaseId: the ID of the database to query
      - filter: optional filter object
      - sorts: optional array of sort objects
      - start_cursor: optional cursor for pagination
      - page_size: optional number of results per page (max 100)`,
  func: async (input) => {
    var _a2;
    try {
      const options = JSON.parse(input);
      if (!options.databaseId) {
        return "Error: 'databaseId' is required";
      }
      const queryParams = {};
      if (options.filter) queryParams.filter = options.filter;
      if (options.sorts) queryParams.sorts = options.sorts;
      if (options.start_cursor) queryParams.start_cursor = options.start_cursor;
      if (options.page_size) queryParams.page_size = options.page_size;
      const result = await client.queryDatabase(options.databaseId, queryParams);
      const count = ((_a2 = result.results) == null ? void 0 : _a2.length) || 0;
      return `Successfully queried database ${options.databaseId}. Found ${count} results.`;
    } catch (error) {
      if (error instanceof SyntaxError) {
        return `Error: Invalid JSON input. Please provide valid JSON with databaseId field.`;
      }
      return `Error querying database: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const notionSearch = (client) => new DynamicTool({
  name: "notion_search",
  description: `Search for pages and databases in Notion workspace.
      Input should be a JSON string with:
      - query: the search query string
      - filter: optional filter object to limit search scope
      - sort: optional sort object
      - page_size: optional number of results per page`,
  func: async (input) => {
    var _a2;
    try {
      const options = JSON.parse(input);
      if (!options.query) {
        return "Error: 'query' is required";
      }
      const searchParams = { query: options.query };
      if (options.filter) searchParams.filter = options.filter;
      if (options.sort) searchParams.sort = options.sort;
      if (options.page_size) searchParams.page_size = options.page_size;
      const result = await client.search(searchParams);
      const count = ((_a2 = result.results) == null ? void 0 : _a2.length) || 0;
      return `Search completed for "${options.query}". Found ${count} results.`;
    } catch (error) {
      if (error instanceof SyntaxError) {
        return `Error: Invalid JSON input. Please provide valid JSON with query field.`;
      }
      return `Error searching: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const notionGetDatabase = (client) => new DynamicTool({
  name: "notion_get_database",
  description: "Get a database from Notion by its ID. Input should be a database ID string.",
  func: async (databaseId) => {
    var _a2, _b;
    try {
      if (!databaseId || databaseId.trim() === "") {
        return "Error: Database ID is required";
      }
      const result = await client.getDatabase(databaseId.trim());
      const title = ((_b = (_a2 = result.title) == null ? void 0 : _a2[0]) == null ? void 0 : _b.plain_text) || "No title";
      return `Successfully retrieved database ${databaseId}. Title: ${title}`;
    } catch (error) {
      return `Error getting database: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const notionDeletePage = (client) => new DynamicTool({
  name: "notion_delete_page",
  description: "Delete (archive) a page in Notion. Input should be a page ID string.",
  func: async (pageId) => {
    try {
      if (!pageId || pageId.trim() === "") {
        return "Error: Page ID is required";
      }
      await client.deletePage(pageId.trim());
      return `Successfully deleted page ${pageId}`;
    } catch (error) {
      return `Error deleting page: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const notionGetPageBlocks = (client) => new DynamicTool({
  name: "notion_get_page_blocks",
  description: "Get all blocks from a Notion page. Input should be a page ID string.",
  func: async (pageId) => {
    var _a2;
    try {
      if (!pageId || pageId.trim() === "") {
        return "Error: Page ID is required";
      }
      const result = await client.getBlocks(pageId.trim());
      const count = ((_a2 = result.results) == null ? void 0 : _a2.length) || 0;
      return `Successfully retrieved ${count} blocks from page ${pageId}`;
    } catch (error) {
      return `Error getting page blocks: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const notionAppendBlocks = (client) => new DynamicTool({
  name: "notion_append_blocks",
  description: `Append blocks to a Notion page.
      Input should be a JSON string with:
      - pageId: the ID of the page to append to
      - children: array of block objects to append`,
  func: async (input) => {
    try {
      const options = JSON.parse(input);
      if (!options.pageId || !options.children) {
        return "Error: Both 'pageId' and 'children' are required";
      }
      if (!Array.isArray(options.children)) {
        return "Error: 'children' must be an array";
      }
      await client.appendBlocks(options.pageId, options.children);
      return `Successfully appended ${options.children.length} blocks to page ${options.pageId}`;
    } catch (error) {
      if (error instanceof SyntaxError) {
        return `Error: Invalid JSON input. Please provide valid JSON with pageId and children fields.`;
      }
      return `Error appending blocks: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
const notionUpdateBlock = (client) => new DynamicTool({
  name: "notion_update_block",
  description: `Update a block in Notion.
      Input should be a JSON string with:
      - blockId: the ID of the block to update
      - properties: the block properties to update`,
  func: async (input) => {
    try {
      const options = JSON.parse(input);
      if (!options.blockId) {
        return "Error: 'blockId' is required";
      }
      await client.updateBlock(options.blockId, options.properties || {});
      return `Successfully updated block ${options.blockId}`;
    } catch (error) {
      if (error instanceof SyntaxError) {
        return `Error: Invalid JSON input. Please provide valid JSON with blockId field.`;
      }
      return `Error updating block: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
});
function getAllNotionTools(client) {
  return [
    notionCreatePage(client),
    notionUpdatePage(client),
    notionGetPage(client),
    notionQueryDatabase(client),
    notionSearch(client),
    notionGetDatabase(client),
    notionDeletePage(client),
    notionGetPageBlocks(client),
    notionAppendBlocks(client),
    notionUpdateBlock(client)
  ];
}
function isDynamicTool(obj) {
  return typeof obj === "object" && obj !== null && "name" in obj && "description" in obj && "func" in obj && typeof obj.func === "function";
}
class BrowserAgent {
  /**
   * Create a new BrowserAgent
   */
  constructor(page, config, provider) {
    __publicField(this, "llmProvider");
    __publicField(this, "toolManager");
    __publicField(this, "promptManager");
    __publicField(this, "memoryManager");
    __publicField(this, "errorHandler");
    __publicField(this, "executionEngine");
    __publicField(this, "notionClient", null);
    initializePageContext(page);
    this.llmProvider = provider;
    const rawTools = getAllTools(page);
    const browserTools = this.convertToBrowserTools(rawTools);
    this.toolManager = new ToolManager(page, browserTools);
    this.promptManager = new PromptManager(this.toolManager.getTools());
    this.memoryManager = new MemoryManager(this.toolManager.getTools());
    this.errorHandler = new ErrorHandler();
    this.initializeNotionTools();
    this.promptManager.updateTools(this.toolManager.getTools());
    this.executionEngine = new ExecutionEngine(
      this.llmProvider,
      this.toolManager,
      this.promptManager,
      this.memoryManager,
      this.errorHandler
    );
  }
  /**
   * Convert tools from DynamicTool to BrowserTool format
   * This is needed because the tools are created using langchain's DynamicTool,
   * but our ToolManager expects BrowserTool objects.
   */
  convertToBrowserTools(tools) {
    return tools.map((tool) => {
      if (isDynamicTool(tool)) {
        return {
          name: tool.name,
          description: tool.description,
          func: async (input, _context) => {
            return await tool.func(input);
          }
        };
      } else if (typeof tool === "object" && "name" in tool && "description" in tool && "func" in tool) {
        return tool;
      } else {
        console.warn(`Unknown tool format for tool: ${JSON.stringify(tool)}`);
        return {
          name: tool.name || "unknown_tool",
          description: tool.description || "Unknown tool",
          func: async (input) => {
            try {
              if (typeof tool.func === "function") {
                return await tool.func(input);
              }
              return `Error: Tool function not available`;
            } catch (error) {
              return `Error executing tool: ${error instanceof Error ? error.message : String(error)}`;
            }
          }
        };
      }
    });
  }
  /**
   * Initialize Notion client and tools
   */
  async initializeNotionTools() {
    try {
      const configManager = ConfigManager.getInstance();
      const notionConfig = await configManager.getNotionConfig();
      if (notionConfig.enabled && notionConfig.bearerToken) {
        this.notionClient = new NotionSDKClient({
          auth: notionConfig.bearerToken
        });
        try {
          console.log("Notion client connected successfully");
          const notionDynamicTools = getAllNotionTools(this.notionClient);
          const notionBrowserTools = this.convertToBrowserTools(notionDynamicTools);
          this.toolManager.addTools(notionBrowserTools);
        } catch (error) {
          console.error("Failed to connect to Notion MCP server:", error);
          this.notionClient = null;
        }
      }
    } catch (error) {
      console.error("Error initializing Notion tools:", error);
      this.notionClient = null;
    }
  }
  /**
   * Get Notion tools if configured
   */
  getNotionTools() {
    if (!this.notionClient || !this.notionClient.isConnected) {
      return [];
    }
    try {
      const notionDynamicTools = getAllNotionTools(this.notionClient);
      return this.convertToBrowserTools(notionDynamicTools);
    } catch (error) {
      console.error("Error converting Notion tools:", error);
      return [];
    }
  }
  /**
   * Check if Notion tools are available
   */
  hasNotionTools() {
    return this.notionClient !== null && this.notionClient.isConnected;
  }
  /**
   * Cancel the current execution
   */
  cancel() {
    this.errorHandler.cancel();
  }
  /**
   * Reset the cancel flag
   */
  resetCancel() {
    this.errorHandler.resetCancel();
  }
  /**
   * Check if streaming is supported in the current environment
   */
  async isStreamingSupported() {
    return this.errorHandler.isStreamingSupported();
  }
  /**
   * Execute a prompt with fallback support
   */
  async executePromptWithFallback(prompt, callbacks, initialMessages = [], role = "operator") {
    return this.executionEngine.executePromptWithFallback(
      prompt,
      callbacks,
      initialMessages,
      role
    );
  }
  /**
   * Execute a prompt without fallback
   */
  async executePrompt(prompt, callbacks, initialMessages = [], role = "operator") {
    return this.executionEngine.executePrompt(
      prompt,
      callbacks,
      initialMessages,
      false,
      // Non-streaming mode
      role
    );
  }
}
async function createBrowserAgent(page, apiKey) {
  const configManager = ConfigManager.getInstance();
  let providerConfig;
  try {
    providerConfig = await configManager.getProviderConfig();
  } catch (error) {
    console.warn("Failed to get provider configuration, using default:", error);
    providerConfig = {
      provider: "anthropic",
      apiKey,
      apiModelId: "claude-3-7-sonnet-20250219"
    };
  }
  if (providerConfig.provider === "ollama") {
    if (!providerConfig.apiKey) {
      providerConfig.apiKey = "dummy-key";
    }
  }
  if (!providerConfig.apiKey) {
    providerConfig.apiKey = apiKey;
  }
  const provider = await createProvider(providerConfig.provider, {
    apiKey: providerConfig.apiKey,
    apiModelId: providerConfig.apiModelId,
    baseUrl: providerConfig.baseUrl,
    thinkingBudgetTokens: providerConfig.thinkingBudgetTokens,
    dangerouslyAllowBrowser: true
  });
  return new BrowserAgent(page, providerConfig, provider);
}
async function needsReinitialization(agent, currentProvider) {
  if (!agent) return true;
  if (!currentProvider) {
    const configManager = ConfigManager.getInstance();
    currentProvider = await configManager.getProviderConfig();
  }
  return true;
}
async function executePromptWithFallback(agent, prompt, callbacks, initialMessages = [], role) {
  return agent.executePromptWithFallback(prompt, callbacks, initialMessages, role);
}
const AgentCore = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  BrowserAgent,
  createBrowserAgent,
  executePromptWithFallback,
  needsReinitialization
}, Symbol.toStringTag, { value: "Module" }));
class WorkflowRunner {
  constructor() {
    __publicField(this, "cancelled", false);
    __publicField(this, "currentRunId");
    __publicField(this, "store", WorkflowStore.getInstance());
  }
  cancel() {
    this.cancelled = true;
  }
  async run(workflowId, version, options) {
    var _a2, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w;
    this.cancelled = false;
    const run = {
      id: `run-${crypto.randomUUID()}`,
      workflowId,
      versionId: version.id,
      status: "running",
      startedAt: Date.now(),
      llmCalls: 0,
      inputTokens: 0,
      outputTokens: 0,
      cost: 0,
      ownerTabId: (_a2 = options.context) == null ? void 0 : _a2.ownerTabId,
      executionTabId: (_b = options.context) == null ? void 0 : _b.tabId,
      executionWindowId: (_c = options.context) == null ? void 0 : _c.windowId
    };
    this.currentRunId = run.id;
    await this.store.saveRun(run);
    (_e = (_d = options.callbacks) == null ? void 0 : _d.onStatus) == null ? void 0 : _e.call(_d, "running");
    let currentStepRun;
    try {
      if ((_f = options.allowedDomains) == null ? void 0 : _f.length) {
        const hostname = await resolveActiveHostname(options);
        const allowed = options.allowedDomains.some((domain) => hostname === domain || hostname.endsWith(`.${domain}`));
        if (!allowed) throw new Error(`Domain not allowed for workflow: ${hostname || "unknown"}`);
      }
      for (const step of version.steps) {
        if (this.cancelled) throw new Error("Workflow cancelled");
        if (!step.enabled || !step.toolName) continue;
        const stepRun = {
          id: `step-run-${crypto.randomUUID()}`,
          runId: run.id,
          stepId: step.id,
          status: "running",
          startedAt: Date.now()
        };
        currentStepRun = stepRun;
        await this.store.saveStepRun(stepRun);
        (_h = (_g = options.callbacks) == null ? void 0 : _g.onStepStart) == null ? void 0 : _h.call(_g, step);
        const tool = options.tools.find((candidate) => candidate.name === step.toolName);
        if (!tool) throw new Error(`Tool not found: ${step.toolName}`);
        const input = substituteVariables(step.input, options.variables ?? {});
        const pagesBefore = step.toolName === "browser_click" && ((_j = (_i = options.pageRef) == null ? void 0 : _i.current) == null ? void 0 : _j.context) ? options.pageRef.current.context().pages() : void 0;
        if ((step.risk === "write" || step.risk === "irreversible") && ((_k = options.context) == null ? void 0 : _k.tabId)) {
          const approved = await requestApproval(
            options.context.tabId,
            step.toolName,
            typeof input === "string" ? input : JSON.stringify(input),
            `Workflow step requires approval: ${step.label}`,
            options.context.windowId,
            { runId: run.id, workflowId, executionTabId: options.context.tabId, ownerTabId: options.context.ownerTabId }
          );
          if (!approved) throw new Error("Action rejected by user");
        }
        const candidates = step.locator ? locatorCandidates(step.locator, input) : [input];
        let result = "";
        let lastError;
        for (const candidate of candidates) {
          try {
            result = await withTimeout(tool.func(typeof candidate === "string" ? candidate : JSON.stringify(candidate)), step.timeoutMs);
            if (/window is not defined/i.test(result) && step.toolName === "browser_read_text_ast") {
              const fallbackTool = options.tools.find((candidateTool) => candidateTool.name === "browser_read_text");
              if (fallbackTool) {
                result = await withTimeout(fallbackTool.func(""), step.timeoutMs);
              }
            }
            if (!/^error\b|^Error\b|^Action cancelled/i.test(result.trim())) break;
            lastError = new Error(result);
          } catch (error) {
            if (step.toolName === "browser_read_text_ast" && /window is not defined/i.test(String(error))) {
              const fallbackTool = options.tools.find((candidateTool) => candidateTool.name === "browser_read_text");
              if (fallbackTool) {
                try {
                  result = await withTimeout(fallbackTool.func(""), step.timeoutMs);
                  if (!/^error\b|^Error\b|^Action cancelled/i.test(result.trim())) break;
                  lastError = new Error(result);
                  continue;
                } catch (fallbackError) {
                  lastError = fallbackError;
                  continue;
                }
              }
            }
            lastError = error;
          }
        }
        if (!result && lastError) throw lastError;
        if (/^error\b|^Error\b|^Action cancelled/i.test(result.trim())) throw new Error(result);
        if (pagesBefore && ((_m = (_l = options.pageRef) == null ? void 0 : _l.current) == null ? void 0 : _m.context)) {
          const pagesAfter = options.pageRef.current.context().pages();
          const newPages = pagesAfter.filter((candidate) => !pagesBefore.includes(candidate));
          const openerPages = [];
          for (const candidate of newPages) {
            const opener = await ((_n = candidate.opener) == null ? void 0 : _n.call(candidate).catch(() => void 0));
            if (!opener || opener === options.pageRef.current) openerPages.push(candidate);
          }
          if (openerPages.length > 1) throw new Error("AMBIGUOUS_NEW_TABS: multiple pages opened by workflow step");
          if (openerPages.length === 1) {
            const nextPage = openerPages[0];
            await ((_o = nextPage.waitForLoadState) == null ? void 0 : _o.call(nextPage, "domcontentloaded").catch(() => {
            }));
            options.pageRef.current = nextPage;
            const tabId = await findTabIdForPage(nextPage, (_p = options.context) == null ? void 0 : _p.windowId);
            if (tabId !== void 0 && options.context) options.context.tabId = tabId;
            (_q = options.onPageHandoff) == null ? void 0 : _q.call(options, nextPage, tabId);
          }
        }
        for (const assertion of step.postconditions ?? []) {
          if (!await evaluateAssertion(assertion, options.tools)) throw new Error(`Postcondition failed: ${assertion.type}`);
        }
        stepRun.status = "succeeded";
        stepRun.endedAt = Date.now();
        await this.store.saveStepRun(stepRun);
        (_s = (_r = options.callbacks) == null ? void 0 : _r.onStepEnd) == null ? void 0 : _s.call(_r, step, result);
      }
      for (const assertion of version.finalAssertions) {
        if (!await evaluateAssertion(assertion, options.tools)) throw new Error(`Final assertion failed: ${assertion.type}`);
      }
      run.status = "succeeded";
    } catch (error) {
      run.status = this.cancelled ? "cancelled" : "failed";
      const rawMessage = error instanceof Error ? error.message : String(error);
      const failedStep = currentStepRun ? version.steps.find((step) => step.id === (currentStepRun == null ? void 0 : currentStepRun.stepId)) : void 0;
      run.failureMessage = currentStepRun ? `Step failed: ${(failedStep == null ? void 0 : failedStep.label) ?? currentStepRun.stepId} [tool=${(failedStep == null ? void 0 : failedStep.toolName) ?? "unknown"}, stepId=${currentStepRun.stepId}]. ${rawMessage}` : rawMessage;
      console.error("[WorkflowRunner] execution failed", {
        workflowId,
        toolName: failedStep == null ? void 0 : failedStep.toolName,
        stepId: currentStepRun == null ? void 0 : currentStepRun.stepId,
        message: rawMessage,
        stack: error instanceof Error ? error.stack : void 0
      });
      if (currentStepRun) {
        currentStepRun.status = "failed";
        currentStepRun.endedAt = Date.now();
        currentStepRun.errorCode = "ASSERTION_OR_TOOL_FAILURE";
        currentStepRun.errorMessage = run.failureMessage;
        await this.store.saveStepRun(currentStepRun);
        run.failureStepId = currentStepRun.stepId;
      }
    }
    run.endedAt = Date.now();
    run.executionTabId = ((_t = options.context) == null ? void 0 : _t.tabId) ?? run.executionTabId;
    run.executionWindowId = ((_u = options.context) == null ? void 0 : _u.windowId) ?? run.executionWindowId;
    await this.store.saveRun(run);
    (_w = (_v = options.callbacks) == null ? void 0 : _v.onStatus) == null ? void 0 : _w.call(_v, run.status);
    return run;
  }
}
async function findTabIdForPage(page, windowId) {
  var _a2, _b;
  try {
    const url = (_a2 = page.url) == null ? void 0 : _a2.call(page);
    const tabs = await chrome.tabs.query(windowId === void 0 ? {} : { windowId });
    return (_b = tabs.find((tab) => tab.url === url)) == null ? void 0 : _b.id;
  } catch {
    return void 0;
  }
}
async function resolveActiveHostname(options) {
  var _a2, _b, _c;
  if (((_a2 = options.context) == null ? void 0 : _a2.tabId) !== void 0 && typeof chrome !== "undefined" && ((_b = chrome.tabs) == null ? void 0 : _b.get)) {
    const tab = await chrome.tabs.get(options.context.tabId);
    return tab.url ? new URL(tab.url).hostname : "";
  }
  const activeTab = await ((_c = options.tools.find((tool) => tool.name === "browser_get_active_tab")) == null ? void 0 : _c.func(""));
  const urlMatch = activeTab == null ? void 0 : activeTab.match(/https?:\/\/[^\s"']+/i);
  return urlMatch ? new URL(urlMatch[0]).hostname : "";
}
function locatorCandidates(locator, input) {
  const raw = typeof input === "string" ? input : JSON.stringify(input ?? "");
  const suffix = raw.includes("|") ? raw.slice(raw.indexOf("|")) : "";
  const candidates = [];
  for (const kind of locator.fallbackOrder) {
    const value = kind === "role" && locator.role ? `role=${locator.role}${locator.accessibleName ? `:name=${locator.accessibleName}` : ""}` : kind === "label" && locator.label ? `label=${locator.label}` : kind === "text" && locator.text ? `text=${locator.text}` : kind === "testId" && locator.testId ? `[data-testid="${locator.testId}"]` : kind === "css" && locator.css ? locator.css : "";
    if (value) candidates.push(value + (suffix && !raw.startsWith(value) ? suffix : ""));
  }
  return candidates.length ? candidates : [input];
}
function substituteVariables(value, variables) {
  if (typeof value !== "string") return value;
  return value.replace(/\{\{\s*([\w.-]+)\s*\}\}/g, (_, key) => String(variables[key] ?? `{{${key}}}`));
}
function withTimeout(promise, timeoutMs) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`Step timed out after ${timeoutMs}ms`)), timeoutMs);
    promise.then((value) => {
      clearTimeout(timer);
      resolve(value);
    }, (error) => {
      clearTimeout(timer);
      reject(error);
    });
  });
}
function matchesAssertion(assertion, state) {
  switch (assertion.type) {
    case "url_matches":
      return new RegExp(String(assertion.expected)).test(state.url ?? "");
    case "text_present":
      return (state.text ?? "").includes(String(assertion.expected));
    case "element_visible":
      return state.elementVisible === true;
    case "element_absent":
      return state.elementVisible === false;
    case "value_equals":
      return state.value === String(assertion.expected);
    case "row_count":
      return state.rowCount === Number(assertion.expected);
    default:
      return true;
  }
}
async function evaluateAssertion(assertion, tools) {
  var _a2, _b, _c, _d, _e, _f;
  const find = (name) => tools.find((tool) => tool.name === name);
  try {
    if (assertion.type === "url_matches") {
      const result = await ((_a2 = find("browser_get_active_tab")) == null ? void 0 : _a2.func(""));
      return matchesAssertion(assertion, { url: result });
    }
    if (assertion.type === "text_present") {
      const result = await ((_b = find("browser_read_text") ?? find("browser_read_text_enhanced")) == null ? void 0 : _b.func(""));
      return matchesAssertion(assertion, { text: result });
    }
    if (assertion.type === "element_visible" || assertion.type === "element_absent") {
      const locator = ((_c = assertion.locator) == null ? void 0 : _c.css) || ((_d = assertion.locator) == null ? void 0 : _d.text) || ((_e = assertion.locator) == null ? void 0 : _e.accessibleName);
      if (!locator) return false;
      const result = await ((_f = find("browser_query")) == null ? void 0 : _f.func(locator));
      const visible = !!result && !/^error\b|^Error\b/i.test(result) && result !== "[]";
      return assertion.type === "element_visible" ? visible : !visible;
    }
    return true;
  } catch {
    return false;
  }
}
const WORKFLOW_MAX_RETURN_CHARS = 2e4;
class WorkflowService {
  async run(workflowId, version, page, options = {}) {
    const getPage = () => {
      var _a2;
      return ((_a2 = options.pageRef) == null ? void 0 : _a2.current) ?? page;
    };
    const memoryTool = lookupMemories(getPage());
    const tools = [{
      name: memoryTool.name,
      description: memoryTool.description,
      func: (input) => memoryTool.func(input)
    }, {
      name: "browser_get_active_tab",
      description: "Get the tab assigned to this workflow run.",
      func: async () => {
        var _a2;
        const tabId = (_a2 = options.context) == null ? void 0 : _a2.tabId;
        if (tabId === void 0) throw new Error("Workflow tab ID is unavailable");
        const tab = await chrome.tabs.get(tabId);
        return JSON.stringify({
          id: tab.id,
          windowId: tab.windowId,
          title: tab.title ?? "",
          url: tab.url ?? "",
          active: tab.active
        });
      }
    }];
    const workflowBrowserTools = /* @__PURE__ */ new Set([
      "browser_navigate",
      "browser_wait_for_navigation",
      "browser_navigate_back",
      "browser_navigate_forward",
      "browser_click",
      "browser_type",
      "browser_handle_dialog",
      "browser_press_key",
      "browser_keyboard_type",
      "browser_query",
      "browser_get_title",
      "browser_read_text",
      "browser_screenshot",
      "browser_snapshot_dom",
      "browser_accessible_tree",
      "browser_get_active_tab",
      "browser_read_text_ast",
      "browser_get_overview",
      "browser_get_section",
      "browser_get_summary",
      "browser_get_summary_ast"
    ]);
    for (const candidate of getAllTools(getPage())) {
      if (workflowBrowserTools.has(candidate.name) && !tools.some((tool) => tool.name === candidate.name)) {
        tools.push({
          name: candidate.name,
          description: candidate.description,
          func: (input) => {
            const current = getAllTools(getPage()).find((tool) => tool.name === candidate.name);
            return current ? current.func(input) : Promise.resolve(`Error: Tool unavailable: ${candidate.name}`);
          }
        });
      }
    }
    const readMain = async () => {
      const selectors = ["main", "article", '[role="main"]', "#content", "#main", ".content", ".main-content"];
      for (const selector of selectors) {
        const locator = getPage().locator(selector).first();
        if (await locator.count()) {
          const text = (await locator.innerText()).trim();
          if (text) return text.slice(0, WORKFLOW_MAX_RETURN_CHARS);
        }
      }
      return (await getPage().locator("body").innerText()).trim().slice(0, WORKFLOW_MAX_RETURN_CHARS);
    };
    const getOverview = async () => {
      const title = await getPage().title();
      const headings = await getPage().locator("h1, h2").allInnerTexts();
      const bodyText = await getPage().locator("body").innerText();
      const wordCount = bodyText.trim() ? bodyText.trim().split(/\s+/).length : 0;
      return JSON.stringify({
        title,
        url: getPage().url(),
        wordCount,
        estimatedReadingTime: Math.max(1, Math.ceil(wordCount / 200)),
        sections: headings.map((text) => text.trim()).filter(Boolean)
      });
    };
    const getSummary = async (input) => {
      const requestedLength = Number.parseInt(input, 10);
      const maxLength = Number.isFinite(requestedLength) && requestedLength > 0 ? requestedLength : 500;
      return `${await getPage().title()}

${(await readMain()).slice(0, maxLength)}`;
    };
    tools.push({ name: "browser_read_main_for_workflow", description: "Workflow-only main content.", func: readMain });
    tools.push({ name: "browser_get_overview", description: "Workflow-safe page overview.", func: getOverview });
    for (const name of ["browser_read_text", "browser_read_text_ast", "browser_read_text_enhanced"]) {
      tools.push({ name, description: `Workflow-safe text reader (${name}).`, func: readMain });
    }
    for (const name of ["browser_get_summary", "browser_get_summary_ast"]) {
      tools.push({ name, description: `Workflow-safe page summary (${name}).`, func: getSummary });
    }
    tools.push({ name: "browser_get_title", description: "Workflow-safe page title.", func: async () => getPage().title() });
    tools.push({
      name: "browser_get_section",
      description: "Workflow-safe section lookup.",
      func: async (sectionName) => {
        const body = await readMain();
        const index = body.toLocaleLowerCase().indexOf(sectionName.trim().toLocaleLowerCase());
        return index < 0 ? `Section "${sectionName}" not found.` : body.slice(index, index + 4e3);
      }
    });
    const registeredNames = new Set(tools.map((tool) => tool.name));
    const unsupportedTools = [...new Set(version.steps.filter((step) => step.enabled && step.toolName && !registeredNames.has(step.toolName)).map((step) => step.toolName))];
    if (unsupportedTools.length) {
      throw new Error(`Unsupported workflow tools: ${unsupportedTools.join(", ")}`);
    }
    return (options.runner ?? new WorkflowRunner()).run(workflowId, version, { ...options, tools });
  }
}
class TraceRecorder {
  constructor() {
    __publicField(this, "events", []);
    __publicField(this, "active", false);
  }
  start() {
    this.events = [];
    this.active = true;
  }
  record(event) {
    if (this.active) this.events.push(this.redact(event));
  }
  finish() {
    this.active = false;
    return [...this.events];
  }
  cancel() {
    this.active = false;
    this.events = [];
  }
  redact(event) {
    return {
      ...event,
      input: redactValue(event.input),
      result: event.result ? { ...event.result, data: redactValue(event.result.data) } : void 0
    };
  }
}
function redactValue(value) {
  if (typeof value === "string") {
    return value.replace(/(password|passwd|secret|token|api[_-]?key|card(number)?|cvv)\s*[:=]\s*[^,;&\s]+/gi, "$1=[REDACTED]");
  }
  if (Array.isArray(value)) return value.map(redactValue);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => {
      const sensitive = /password|passwd|secret|token|api[_-]?key|card(number)?|cvv/i.test(key);
      return [key, sensitive ? "[REDACTED]" : redactValue(item)];
    }));
  }
  return value;
}
const _ScreenshotManager = class _ScreenshotManager {
  constructor() {
    __publicField(this, "screenshots", /* @__PURE__ */ new Map());
    __publicField(this, "counter", 0);
  }
  /**
   * Get the singleton instance of ScreenshotManager
   * @returns The ScreenshotManager instance
   */
  static getInstance() {
    if (!_ScreenshotManager.instance) {
      _ScreenshotManager.instance = new _ScreenshotManager();
    }
    return _ScreenshotManager.instance;
  }
  /**
   * Store a screenshot and return a handle to reference it
   * @param data The screenshot data to store
   * @returns A unique handle to reference the screenshot (e.g., "screenshot#42")
   */
  storeScreenshot(data) {
    const id = `screenshot#${++this.counter}`;
    this.screenshots.set(id, data);
    return id;
  }
  /**
   * Get a screenshot by its handle
   * @param id The screenshot handle (e.g., "screenshot#42")
   * @returns The screenshot data, or null if not found
   */
  getScreenshot(id) {
    return this.screenshots.get(id) || null;
  }
  /**
   * Check if a screenshot exists
   * @param id The screenshot handle to check
   * @returns True if the screenshot exists, false otherwise
   */
  hasScreenshot(id) {
    return this.screenshots.has(id);
  }
  /**
   * Get all screenshot handles
   * @returns An array of all screenshot handles
   */
  getAllScreenshotIds() {
    return Array.from(this.screenshots.keys());
  }
  /**
   * Clear all screenshots from memory
   */
  clear() {
    this.screenshots.clear();
    this.counter = 0;
  }
};
__publicField(_ScreenshotManager, "instance");
let ScreenshotManager = _ScreenshotManager;
const screenshotManager = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  ScreenshotManager
}, Symbol.toStringTag, { value: "Module" }));
async function saveReflectionMemory(content, domain, tabId) {
  try {
    const normalizedDomain = normalizeDomain(domain);
    await processReflectionOutput(content, normalizedDomain, tabId);
  } catch (error) {
    sendUIMessage("updateOutput", {
      type: "system",
      content: `❌ Error saving memory: ${error instanceof Error ? error.message : String(error)}`
    }, tabId);
  }
}
async function triggerReflection(tabId) {
  var _a2;
  try {
    let activeTabId = tabId;
    if (!activeTabId) {
      try {
        const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
        activeTabId = (_a2 = tabs[0]) == null ? void 0 : _a2.id;
        if (!activeTabId) {
          throw new Error("No active tab found");
        }
      } catch (error) {
        logWithTimestamp(`Error getting active tab: ${error instanceof Error ? error.message : String(error)}`, "error");
        throw error;
      }
    }
    const tabState = getTabState(activeTabId);
    const windowId = getWindowForTab(activeTabId);
    if (!windowId) {
      logWithTimestamp(`Cannot reflect: No window ID for tab ${activeTabId}`, "warn");
      sendUIMessage("updateOutput", {
        type: "system",
        content: `❌ Cannot reflect: No window ID found for this tab.`
      }, activeTabId, windowId);
      return;
    }
    const agent = getAgentForWindow(windowId);
    if (!agent) {
      logWithTimestamp(`Cannot reflect: No agent for window ${windowId}`, "warn");
      sendUIMessage("updateOutput", {
        type: "system",
        content: `❌ Cannot reflect: No active agent session found.`
      }, activeTabId, windowId);
      return;
    }
    let domain = "unknown";
    try {
      const tab = await chrome.tabs.get(activeTabId);
      if (tab.url) {
        const url = new URL(tab.url);
        domain = normalizeDomain(url.hostname);
      }
    } catch (error) {
      handleError(error, "getting tab URL for reflection");
    }
    sendUIMessage("updateOutput", {
      type: "system",
      content: `🧠 Reflecting on this session to learn useful patterns for ${domain}...`
    }, activeTabId, windowId);
    const reflectionPrompt = `
      Please analyze the conversation history and identify useful patterns for accomplishing tasks on ${domain}.
      
      Create a structured memory record with:
      1. A short description of the task that was accomplished
      2. The optimal sequence of tools that were used to solve it
      
      Format your response as a valid JSON object with these fields:
      {
        "domain": "${domain}",
        "taskDescription": "brief description of the task",
        "toolSequence": ["tool1 | input1", "tool2 | input2", ...]
      }
      
      Focus only on the most useful and reusable patterns. If multiple tasks were performed, create separate memory records for each distinct task. Only save memories that are new or significantly different from existing ones.
      
      NOTE: The domain will be normalized (e.g., "www.example.com" becomes "example.com") to ensure consistent memory retrieval regardless of whether the user includes "www." or not.
      
      IMPORTANT: Your response must be valid JSON or a code block containing valid JSON. Ensure your JSON:
      - Uses double quotes for keys and string values
      - Has proper commas between elements (no trailing commas)
      - Properly escapes special characters in strings
      - Has balanced braces and brackets
    `;
    executePrompt(reflectionPrompt, activeTabId, true);
  } catch (error) {
    logWithTimestamp(`Error during reflection: ${error instanceof Error ? error.message : String(error)}`, "error");
  }
}
async function processReflectionOutput(output, domain, tabId, isCorrection = false) {
  try {
    if (typeof indexedDB === "undefined") {
      logWithTimestamp(`IndexedDB is not available in this browser environment`, "error");
      sendUIMessage("updateOutput", {
        type: "system",
        content: `❌ Cannot save memories: IndexedDB is not available in this browser environment.`
      }, tabId);
      return;
    }
    const jsonMatch = output.match(/```json\n([\s\S]*?)\n```/) || output.match(/```\n([\s\S]*?)\n```/) || output.match(/{[\s\S]*?}/);
    if (jsonMatch) {
      const jsonStr = jsonMatch[1] || jsonMatch[0];
      const cleanJsonStr = jsonStr.trim();
      let memories = [];
      try {
        const parsed = JSON.parse(cleanJsonStr);
        if (Array.isArray(parsed)) {
          memories = parsed;
        } else {
          memories = [parsed];
        }
      } catch (parseError) {
        const jsonObjects = extractJsonObjects(cleanJsonStr);
        if (jsonObjects.length > 0) {
          memories = jsonObjects;
        } else {
          if (isCorrection) {
            throw parseError;
          }
          logWithTimestamp(`JSON parsing error, attempting correction: ${parseError instanceof Error ? parseError.message : String(parseError)}`, "warn");
          sendUIMessage("updateOutput", {
            type: "system",
            content: `⚠️ Memory format error detected. Asking agent to correct it...`
          }, tabId);
          await correctReflectionJSON(cleanJsonStr, parseError, domain, tabId);
          return;
        }
      }
      const memoryService = MemoryService.getInstance();
      await memoryService.init();
      const savedIds = [];
      for (const memory2 of memories) {
        if (!memory2.domain || !memory2.taskDescription || !memory2.toolSequence) {
          logWithTimestamp(`Invalid memory: missing required fields`, "warn");
          continue;
        }
        memory2.domain = normalizeDomain(memory2.domain);
        try {
          const id = await memoryService.storeMemory(memory2);
          savedIds.push(id);
        } catch (storeError) {
          logWithTimestamp(`Error storing memory: ${storeError instanceof Error ? storeError.message : String(storeError)}`, "error");
        }
      }
      if (savedIds.length > 0) {
        sendUIMessage("updateOutput", {
          type: "system",
          content: `✅ Saved ${savedIds.length} memories for ${domain}. The agent will now remember how to perform these tasks on this website.`
        }, tabId);
      } else {
        sendUIMessage("updateOutput", {
          type: "system",
          content: `⚠️ No valid memories were found in the reflection. Please try again.`
        }, tabId);
      }
    } else {
      sendUIMessage("updateOutput", {
        type: "system",
        content: `❌ Could not extract a valid memory from the reflection. Please try again.`
      }, tabId);
    }
  } catch (error) {
    logWithTimestamp(`Error processing reflection: ${error instanceof Error ? error.message : String(error)}`, "error");
    sendUIMessage("updateOutput", {
      type: "system",
      content: `❌ Error processing reflection: ${error instanceof Error ? error.message : String(error)}`
    }, tabId);
  }
}
async function correctReflectionJSON(malformedJson, error, domain, tabId) {
  try {
    const errorMessage = error.message;
    const correctionPrompt = `
      I attempted to save a memory, but there was a JSON parsing error:
      
      ERROR: ${errorMessage}
      
      Here is the malformed JSON that needs to be fixed:
      \`\`\`
      ${malformedJson}
      \`\`\`
      
      Please correct the JSON and provide a valid version that follows this structure:
      {
        "domain": "${domain}",
        "taskDescription": "brief description of the task",
        "toolSequence": ["tool1 | input1", "tool2 | input2", ...]
      }
    `;
    sendUIMessage("updateOutput", {
      type: "system",
      content: `🔄 Attempting to correct JSON format error: ${errorMessage}`
    }, tabId);
    const correctionCallbacks = {
      onLlmOutput: async (output) => {
        try {
          await processReflectionOutput(output, domain, tabId, true);
        } catch (correctionError) {
          logWithTimestamp(`Correction attempt failed: ${correctionError instanceof Error ? correctionError.message : String(correctionError)}`, "error");
          sendUIMessage("updateOutput", {
            type: "system",
            content: `❌ Error processing reflection: Even after correction attempt, JSON is still invalid. ${correctionError instanceof Error ? correctionError.message : String(correctionError)}`
          }, tabId);
        }
      },
      onToolOutput: (content) => {
        sendUIMessage("updateOutput", {
          type: "system",
          content
        }, tabId);
      },
      onComplete: () => {
      }
    };
    const windowId = getWindowForTab(tabId);
    if (!windowId) {
      throw new Error(`No window ID found for tab ${tabId}`);
    }
    const agent = getAgentForWindow(windowId);
    if (!agent) {
      throw new Error(`No agent found for window ${windowId}`);
    }
    const { executePromptWithFallback: executePromptWithFallback2 } = await __vitePreload(async () => {
      const { executePromptWithFallback: executePromptWithFallback3 } = await Promise.resolve().then(() => AgentCore);
      return { executePromptWithFallback: executePromptWithFallback3 };
    }, true ? void 0 : void 0);
    await executePromptWithFallback2(agent, correctionPrompt, correctionCallbacks, []);
  } catch (correctionError) {
    logWithTimestamp(`Error during JSON correction: ${correctionError instanceof Error ? correctionError.message : String(correctionError)}`, "error");
    sendUIMessage("updateOutput", {
      type: "system",
      content: `❌ Failed to correct memory JSON: ${correctionError instanceof Error ? correctionError.message : String(correctionError)}`
    }, tabId);
  }
}
function extractJsonObjects(str) {
  const objects = [];
  let depth = 0;
  let start = -1;
  for (let i = 0; i < str.length; i++) {
    if (str[i] === "{") {
      if (depth === 0) {
        start = i;
      }
      depth++;
    } else if (str[i] === "}") {
      depth--;
      if (depth === 0 && start !== -1) {
        try {
          const jsonStr = str.substring(start, i + 1);
          const obj = JSON.parse(jsonStr);
          objects.push(obj);
        } catch (e) {
        }
        start = -1;
      }
    }
  }
  return objects;
}
let streamingBuffer = "";
const combinedToolCallRegex = /(```(?:xml|bash)\s*)?<tool>(.*?)<\/tool>\s*<input>([\s\S]*?)<\/input>(?:\s*<requires_approval>(.*?)<\/requires_approval>)?(\s*```)?/;
const sentenceEndRegex = /[.!?]\s+/;
let currentSegmentId = 0;
function resetStreamingState() {
  streamingBuffer = "";
  currentSegmentId = 0;
}
function getCurrentSegmentId() {
  return currentSegmentId;
}
function incrementSegmentId() {
  return ++currentSegmentId;
}
function processStreamingBuffer(tabId, windowId) {
  const toolCallMatch = streamingBuffer.match(combinedToolCallRegex);
  if (toolCallMatch) {
    return;
  }
  const sentenceMatch = streamingBuffer.match(sentenceEndRegex);
  if (sentenceMatch) {
    const lastSentenceEnd = streamingBuffer.lastIndexOf(sentenceMatch[0]) + sentenceMatch[0].length;
    sendUIMessage("updateStreamingChunk", {
      type: "llm",
      content: streamingBuffer.substring(0, lastSentenceEnd)
    }, tabId, windowId);
    streamingBuffer = streamingBuffer.substring(lastSentenceEnd);
  } else if (streamingBuffer.length > 100) {
    sendUIMessage("updateStreamingChunk", {
      type: "llm",
      content: streamingBuffer
    }, tabId, windowId);
    streamingBuffer = "";
  }
}
function addToStreamingBuffer(chunk, tabId, windowId) {
  streamingBuffer += chunk;
  processStreamingBuffer(tabId, windowId);
}
function getStreamingBuffer() {
  return streamingBuffer;
}
function setStreamingBuffer(content) {
  streamingBuffer = content;
}
function clearStreamingBuffer(tabId, windowId) {
  if (streamingBuffer.length > 0) {
    sendUIMessage("updateStreamingChunk", {
      type: "llm",
      content: streamingBuffer
    }, tabId, windowId);
    streamingBuffer = "";
  }
}
function finalizeStreamingSegment(segmentId, content, tabId, windowId) {
  sendUIMessage("finalizeStreamingSegment", {
    id: segmentId,
    content
  }, tabId, windowId);
}
function startNewSegment(segmentId, tabId, windowId) {
  sendUIMessage("startNewSegment", {
    id: segmentId
  }, tabId, windowId);
}
function signalStreamingComplete(tabId, windowId) {
  sendUIMessage("streamingComplete", null, tabId, windowId);
}
var AgentStatus = /* @__PURE__ */ ((AgentStatus2) => {
  AgentStatus2["IDLE"] = "idle";
  AgentStatus2["RUNNING"] = "running";
  AgentStatus2["ERROR"] = "error";
  return AgentStatus2;
})(AgentStatus || {});
const MAX_CONVERSATION_TOKENS = 1e5;
function isExpertPageAnalysisRequest(prompt, role) {
  if (!EXPERT_ROLE_IDS.includes(role)) return false;
  return /(当前网页|当前页面|这个网页|这个页面|网页内容|页面内容|analy[sz]e the (current )?web ?page|current (web )?page|this page|page content)/i.test(prompt);
}
async function readPageForExpert(tabId, page) {
  var _a2, _b;
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        var _a3;
        return {
          title: document.title || "",
          text: ((_a3 = document.body) == null ? void 0 : _a3.innerText) || ""
        };
      }
    });
    const result = (_a2 = results[0]) == null ? void 0 : _a2.result;
    if ((_b = result == null ? void 0 : result.text) == null ? void 0 : _b.trim()) return `Title: ${result.title}

${result.text.slice(0, 24e3)}`;
  } catch (error) {
    logWithTimestamp(`Expert page pre-read via scripting failed: ${error instanceof Error ? error.message : String(error)}`, "warn");
  }
  try {
    const text = await page.locator("body").innerText();
    return (text == null ? void 0 : text.trim()) ? text.slice(0, 24e3) : null;
  } catch (error) {
    logWithTimestamp(`Expert page pre-read via Playwright failed: ${error instanceof Error ? error.message : String(error)}`, "warn");
    return null;
  }
}
const windowMessageHistories = /* @__PURE__ */ new Map();
const agentStatusMap = /* @__PURE__ */ new Map();
function setAgentStatus(windowId, status) {
  const current = agentStatusMap.get(windowId);
  const now = Date.now();
  agentStatusMap.set(windowId, {
    status,
    timestamp: now,
    lastHeartbeat: now
  });
  if (!current || current.status !== status) {
    logWithTimestamp(`Agent status transition: ${(current == null ? void 0 : current.status) || "undefined"} -> ${status} for window ${windowId}`);
  }
}
function getAgentStatus(windowId) {
  return agentStatusMap.get(windowId) || {
    status: AgentStatus.IDLE,
    timestamp: Date.now(),
    lastHeartbeat: 0
  };
}
async function getCurrentProvider() {
  const configManager = ConfigManager.getInstance();
  const config = await configManager.getProviderConfig();
  return config.provider;
}
async function clearMessageHistory(tabId, windowId) {
  const screenshotManager2 = ScreenshotManager.getInstance();
  const provider = await getCurrentProvider();
  if (tabId && !windowId) {
    windowId = getWindowForTab(tabId);
  }
  if (windowId) {
    windowMessageHistories.set(windowId, { provider, originalRequest: null, conversationHistory: [] });
    screenshotManager2.clear();
    logWithTimestamp(`Message history and screenshots cleared for window ${windowId}`);
  } else if (getCurrentTabId$1()) {
    const currentWindowId = getWindowForTab(getCurrentTabId$1());
    if (currentWindowId) {
      windowMessageHistories.set(currentWindowId, { provider, originalRequest: null, conversationHistory: [] });
      screenshotManager2.clear();
      logWithTimestamp(`Message history and screenshots cleared for current window ${currentWindowId}`);
    }
  } else {
    windowMessageHistories.clear();
    screenshotManager2.clear();
    logWithTimestamp("All message histories and screenshots cleared");
  }
}
async function getMessageHistory(tabId) {
  const windowId = getWindowForTab(tabId);
  if (!windowId) {
    logWithTimestamp(`Cannot get message history: No window ID found for tab ${tabId}`, "warn");
    return [];
  }
  const provider = await getCurrentProvider();
  if (!windowMessageHistories.has(windowId)) {
    windowMessageHistories.set(windowId, { provider, originalRequest: null, conversationHistory: [] });
  }
  const history = windowMessageHistories.get(windowId);
  if (history.provider !== provider) {
    history.provider = provider;
    windowMessageHistories.set(windowId, history);
  }
  let messagesToConvert = [];
  if (history.originalRequest) {
    const isDuplicate = history.conversationHistory.length > 0 && history.conversationHistory[0].role === history.originalRequest.role && history.conversationHistory[0].content === history.originalRequest.content;
    if (isDuplicate) {
      messagesToConvert = history.conversationHistory;
      logWithTimestamp(`Avoided duplicate first message for tab ${tabId}`);
    } else {
      messagesToConvert = [history.originalRequest, ...history.conversationHistory];
    }
  } else {
    messagesToConvert = history.conversationHistory;
  }
  const convertedMessages = convertMessagesToProviderFormat(
    messagesToConvert,
    provider
  );
  return convertedMessages;
}
function convertMessagesToProviderFormat(messages, provider) {
  switch (provider) {
    case "anthropic":
      return messages.map((msg) => {
        const role = msg.role === "user" || msg.role === "assistant" ? msg.role : "user";
        return {
          role,
          content: msg.content
        };
      });
    case "openai":
      return messages.map((msg) => {
        const role = msg.role === "assistant" ? "assistant" : "user";
        return {
          role,
          content: msg.content
        };
      });
    case "gemini":
      return messages.map((msg) => {
        const role = msg.role === "assistant" ? "assistant" : "user";
        return {
          role,
          content: msg.content
        };
      });
    case "ollama":
      return messages.map((msg) => {
        const role = msg.role === "assistant" ? "assistant" : "user";
        return {
          role,
          content: msg.content
        };
      });
    default:
      return messages.map((msg) => {
        const role = msg.role === "user" || msg.role === "assistant" ? msg.role : "user";
        return {
          role,
          content: msg.content
        };
      });
  }
}
async function getStructuredMessageHistory(tabId) {
  const windowId = getWindowForTab(tabId);
  if (!windowId) {
    logWithTimestamp(`Cannot get structured message history: No window ID found for tab ${tabId}`, "warn");
    const provider2 = await getCurrentProvider();
    return { provider: provider2, originalRequest: null, conversationHistory: [] };
  }
  const provider = await getCurrentProvider();
  if (!windowMessageHistories.has(windowId)) {
    windowMessageHistories.set(windowId, { provider, originalRequest: null, conversationHistory: [] });
  }
  const history = windowMessageHistories.get(windowId);
  if (history.provider !== provider) {
    history.provider = provider;
    windowMessageHistories.set(windowId, history);
  }
  return history;
}
async function setOriginalRequest(tabId, request) {
  const windowId = getWindowForTab(tabId);
  if (!windowId) {
    logWithTimestamp(`Cannot set original request: No window ID found for tab ${tabId}`, "warn");
    return;
  }
  const history = await getStructuredMessageHistory(tabId);
  history.originalRequest = request;
  windowMessageHistories.set(windowId, history);
}
async function addToConversationHistory(tabId, message) {
  const windowId = getWindowForTab(tabId);
  if (!windowId) {
    logWithTimestamp(`Cannot add to conversation history: No window ID found for tab ${tabId}`, "warn");
    return;
  }
  const history = await getStructuredMessageHistory(tabId);
  history.conversationHistory.push(message);
  windowMessageHistories.set(windowId, history);
}
async function initializeAgent(tabId, forceReinit = false) {
  const tabState = getTabState(tabId);
  if (!(tabState == null ? void 0 : tabState.page) || !tabState.windowId) {
    return false;
  }
  const windowId = tabState.windowId;
  const configManager = ConfigManager.getInstance();
  const providerConfig = await configManager.getProviderConfig();
  const tokenTracker = TokenTrackingService.getInstance();
  tokenTracker.updateProviderAndModel(providerConfig.provider, providerConfig.apiModelId || "");
  const existingAgent = getAgentForWindow(windowId);
  const needsInit = !existingAgent || forceReinit;
  const needsReinit = existingAgent && await needsReinitialization(existingAgent, providerConfig);
  if (needsInit || needsReinit) {
    try {
      if (providerConfig.apiKey || providerConfig.provider === "ollama") {
        logWithTimestamp(`Creating LLM agent for window ${windowId} with ${providerConfig.provider} provider...`);
        const agent = await createBrowserAgent(tabState.page, providerConfig.apiKey || "dummy-key-for-ollama");
        setAgentForWindow(windowId, agent);
        logWithTimestamp(`LLM agent created successfully for window ${windowId}`);
        return true;
      } else {
        logWithTimestamp("No API key found for the selected provider, skipping agent initialization", "warn");
        return false;
      }
    } catch (agentError) {
      handleError(agentError, "creating agent");
      return false;
    }
  }
  return !!existingAgent;
}
function cancelExecution(tabId) {
  if (!tabId) {
    const currentTabId = getCurrentTabId$1();
    if (!currentTabId) return;
    tabId = currentTabId;
  }
  const windowId = getWindowForTab(tabId);
  if (!windowId) {
    logWithTimestamp(`Cannot cancel execution for tab ${tabId}: no window ID found`);
    return;
  }
  const agent = getAgentForWindow(windowId);
  if (!agent) {
    logWithTimestamp(`Cannot cancel execution for window ${windowId}: no agent found`);
    return;
  }
  agent.cancel();
  sendUIMessage("updateOutput", {
    type: "system",
    content: "Cancelling execution..."
  }, tabId);
  sendUIMessage("processingComplete", null, tabId);
  setAgentStatus(windowId, AgentStatus.IDLE);
  logWithTimestamp(`Cancelled execution for tab ${tabId} in window ${windowId}`);
}
async function executePrompt(prompt, tabId, isReflectionPrompt = false, role = "operator", selectedTabIds, contextMode) {
  var _a2;
  try {
    const configManager = ConfigManager.getInstance();
    const providerConfig = await configManager.getProviderConfig();
    if (!providerConfig.apiKey && providerConfig.provider !== "ollama") {
      sendUIMessage("updateOutput", {
        type: "system",
        content: `Error: API key not found for ${providerConfig.provider}. Please set your API key in the extension options.`
      }, tabId);
      sendUIMessage("processingComplete", null, tabId);
      return;
    }
    let targetTabId = tabId;
    if (!targetTabId) {
      const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      targetTabId = (_a2 = tabs[0]) == null ? void 0 : _a2.id;
    }
    if (!targetTabId) {
      sendUIMessage("updateOutput", {
        type: "system",
        content: "Error: Could not determine which tab to use."
      }, tabId);
      sendUIMessage("processingComplete", null, tabId);
      return;
    }
    logWithTimestamp(`Executing prompt for tab ${targetTabId}: "${prompt}"`);
    const tabState = getTabState(targetTabId);
    const tabWindowId = tabState == null ? void 0 : tabState.windowId;
    const needsInitialization = !(tabState == null ? void 0 : tabState.page) || !tabWindowId || !getAgentForWindow(tabWindowId);
    const connectionBroken = (tabState == null ? void 0 : tabState.page) && !await isConnectionHealthy(tabState.page);
    if (needsInitialization || connectionBroken) {
      if (connectionBroken) {
        logWithTimestamp("Connection health check failed, reattaching...", "warn");
        sendUIMessage("updateOutput", {
          type: "system",
          content: "Debug session was closed, reattaching..."
        }, targetTabId);
      } else {
        sendUIMessage("updateOutput", {
          type: "system",
          content: "Initializing for tab..."
        }, targetTabId);
      }
      const { attachToTab: attachToTab2 } = await __vitePreload(async () => {
        const { attachToTab: attachToTab3 } = await import("./_commonjsHelpers-DP-qmQZY.js").then((n) => n.N);
        return { attachToTab: attachToTab3 };
      }, true ? [] : void 0);
      const attachResult = await attachToTab2(targetTabId);
      if (attachResult !== true && attachResult !== false && typeof attachResult === "object" && "error" in attachResult) {
        if (attachResult.error === "unsupported_tab") {
          sendUIMessage("updateOutput", {
            type: "system",
            content: `Error: ${attachResult.reason} Please try using the extension in a regular web page tab.`
          }, targetTabId);
          sendUIMessage("processingComplete", null, targetTabId);
          return;
        }
      } else if (attachResult === true) {
        try {
          const tab = await chrome.tabs.get(targetTabId);
          if (tab && tab.url && tab.url.includes("google.com")) {
            sendUIMessage("updateOutput", {
              type: "system",
              content: "Note: Navigated to Google to enable extension functionality in this tab."
            }, targetTabId);
          }
        } catch (error) {
        }
      } else if (typeof attachResult === "number") {
        logWithTimestamp(`Tab ${targetTabId} was replaced with new tab ${attachResult}`);
        targetTabId = attachResult;
      }
      await initializeAgent(targetTabId);
    }
    const updatedTabState = getTabState(targetTabId);
    if (!(updatedTabState == null ? void 0 : updatedTabState.page) || !(updatedTabState == null ? void 0 : updatedTabState.windowId)) {
      sendUIMessage("updateOutput", {
        type: "system",
        content: "Error: Failed to initialize Playwright or create agent. This may be because you are using the extension in an unsupported tab type."
      }, targetTabId);
      sendUIMessage("processingComplete", null, targetTabId);
      return;
    }
    try {
      logWithTimestamp(`Updated PageContextManager with tab state ${updatedTabState} in executePrompt start`);
      setCurrentPage(updatedTabState.page);
      logWithTimestamp(`Updated PageContextManager with page for tab ${targetTabId} in executePrompt end`);
    } catch (error) {
      logWithTimestamp(`Error updating PageContextManager in executePrompt: ${error instanceof Error ? error.message : String(error)}`, "warn");
    }
    let currentDomain = "current-site";
    if (updatedTabState.page && contextMode !== "standalone") {
      try {
        const currentUrl = await updatedTabState.page.url();
        const currentTitle = await updatedTabState.page.title();
        try {
          currentDomain = new URL(currentUrl).hostname;
        } catch {
        }
        const pageContextMessage = `Current page: ${currentUrl} (${currentTitle}) - Consider this context when executing commands. If asked to summarize, read content, create tables, or analyze options without specific references, assume the request refers to content on this page.`;
        sendUIMessage("updateOutput", {
          type: "system",
          content: pageContextMessage
        }, targetTabId);
        const updatedWindowId2 = updatedTabState.windowId;
        const agent2 = getAgentForWindow(updatedWindowId2);
        if (agent2) {
          const promptManager = agent2.promptManager;
          if (promptManager && typeof promptManager.setCurrentPageContext === "function") {
            promptManager.setCurrentPageContext(currentUrl, currentTitle);
          }
        }
      } catch (error) {
        logWithTimestamp("Could not get current page info: " + String(error), "warn");
      }
    }
    let enhancedPrompt = prompt;
    const shouldReadPageForExpert = contextMode === "current-tab" || contextMode === void 0 && isExpertPageAnalysisRequest(prompt, role);
    if (shouldReadPageForExpert && EXPERT_ROLE_IDS.includes(role)) {
      const pageText = await readPageForExpert(targetTabId, updatedTabState.page);
      if (pageText) {
        enhancedPrompt = `${prompt}

[User explicitly requested current-page analysis. Use only this captured page content; do not call a browser read tool.]

${pageText}`;
        sendUIMessage("updateOutput", {
          type: "system",
          content: "Captured the current page for expert analysis."
        }, targetTabId);
      } else {
        enhancedPrompt = `${prompt}

[The current page could not be read. Explain what page content is needed instead of calling a browser read tool.]`;
      }
    }
    const isMultiTabAnalysis = selectedTabIds && Array.isArray(selectedTabIds) && selectedTabIds.length > 0;
    if (isMultiTabAnalysis) {
      sendUIMessage("updateOutput", {
        type: "system",
        content: `Gathering content from ${selectedTabIds.length} selected tabs for analysis...`
      }, targetTabId);
      try {
        const tabContents = [];
        for (const tabId2 of selectedTabIds) {
          try {
            const tab = await chrome.tabs.get(tabId2);
            if (tab && tab.url && !tab.url.startsWith("chrome://") && !tab.url.startsWith("chrome-extension://")) {
              logWithTimestamp(`Processing tab ${tabId2}: ${tab.title} (${tab.url})`);
              let tabState2 = getTabState(tabId2);
              let temporarilyAttached = false;
              if (!(tabState2 == null ? void 0 : tabState2.page)) {
                try {
                  logWithTimestamp(`Temporarily attaching to tab ${tabId2} for content extraction`);
                  const { attachToTab: attachToTab2 } = await __vitePreload(async () => {
                    const { attachToTab: attachToTab3 } = await import("./_commonjsHelpers-DP-qmQZY.js").then((n) => n.N);
                    return { attachToTab: attachToTab3 };
                  }, true ? [] : void 0);
                  await attachToTab2(tabId2);
                  tabState2 = getTabState(tabId2);
                  temporarilyAttached = true;
                } catch (attachError) {
                  logWithTimestamp(`Failed to attach to tab ${tabId2}: ${attachError instanceof Error ? attachError.message : String(attachError)}`, "warn");
                }
              }
              let pageContent = null;
              if (tabState2 == null ? void 0 : tabState2.page) {
                try {
                  pageContent = await tabState2.page.evaluate(() => {
                    var _a3;
                    const title = document.title || "";
                    const url = ((_a3 = globalThis.location) == null ? void 0 : _a3.href) || "";
                    const contentSelectors = [
                      "main",
                      "article",
                      '[role="main"]',
                      ".content",
                      ".main-content",
                      "h1, h2, h3, h4, h5, h6",
                      "p",
                      "li",
                      "div"
                    ];
                    let content = "";
                    const processedTexts = /* @__PURE__ */ new Set();
                    for (const selector of contentSelectors) {
                      const elements = document.querySelectorAll(selector);
                      elements.forEach((el) => {
                        var _a4;
                        const style = globalThis.getComputedStyle(el);
                        if (style.display === "none" || style.visibility === "hidden") {
                          return;
                        }
                        const text = (_a4 = el.textContent) == null ? void 0 : _a4.trim();
                        if (text && text.length > 15 && !processedTexts.has(text) && !text.match(/^(skip|menu|navigation|footer|header|cookie|privacy|advertisement)/i)) {
                          processedTexts.add(text);
                          content += text + "\n\n";
                        }
                      });
                      if (content.length > 1e4) break;
                    }
                    return {
                      title,
                      url,
                      content: content.slice(0, 12e3)
                    };
                  });
                  logWithTimestamp(`Successfully extracted ${pageContent.content.length} characters from tab ${tabId2}`);
                } catch (evalError) {
                  logWithTimestamp(`Content extraction failed for tab ${tabId2}: ${evalError instanceof Error ? evalError.message : String(evalError)}`, "warn");
                  pageContent = null;
                }
              }
              if ((tabState2 == null ? void 0 : tabState2.page) && (!pageContent || pageContent.content.length < 100)) {
                try {
                  const basicInfo = await tabState2.page.evaluate(() => {
                    var _a3, _b, _c;
                    return {
                      title: document.title || "",
                      url: ((_a3 = globalThis.location) == null ? void 0 : _a3.href) || "",
                      content: ((_c = (_b = document.body) == null ? void 0 : _b.innerText) == null ? void 0 : _c.slice(0, 5e3)) || "No readable content found"
                    };
                  });
                  if (basicInfo.content.length > 50) {
                    pageContent = basicInfo;
                    logWithTimestamp(`Got basic content from tab ${tabId2}: ${basicInfo.content.length} characters`);
                  }
                } catch (basicError) {
                  logWithTimestamp(`Basic content extraction failed for tab ${tabId2}: ${basicError instanceof Error ? basicError.message : String(basicError)}`, "warn");
                }
              }
              if (pageContent && pageContent.content && pageContent.content.length > 50) {
                tabContents.push(`=== TAB: ${pageContent.title} ===
URL: ${pageContent.url}

CONTENT:
${pageContent.content}

=== END OF TAB ===
`);
                logWithTimestamp(`Added content for tab ${tabId2}: ${pageContent.title} (${pageContent.content.length} chars)`);
              } else {
                tabContents.push(`=== TAB: ${tab.title} ===
URL: ${tab.url}

CONTENT:
Unable to extract detailed content from this tab. The page may require user interaction or may not be fully loaded.
Tab Title: ${tab.title}
Tab URL: ${tab.url}

=== END OF TAB ===
`);
                logWithTimestamp(`Added fallback content for tab ${tabId2}: ${tab.title}`);
              }
              if (temporarilyAttached) {
                logWithTimestamp(`Keeping temporary attachment for tab ${tabId2} - it may be useful for the agent`);
              }
            }
          } catch (error) {
            logWithTimestamp(`Error processing tab ${tabId2}: ${error instanceof Error ? error.message : String(error)}`, "error");
            try {
              const tab = await chrome.tabs.get(tabId2);
              tabContents.push(`=== TAB: ${tab.title || "Unknown"} ===
URL: ${tab.url || "Unknown"}

CONTENT:
Error accessing this tab: ${error instanceof Error ? error.message : String(error)}

=== END OF TAB ===
`);
            } catch {
              tabContents.push(`=== TAB ID: ${tabId2} ===
Error: Unable to access tab information

=== END OF TAB ===
`);
            }
          }
        }
        const combinedContent = tabContents.join("\n");
        const totalContentLength = combinedContent.length;
        const tabsWithContent = tabContents.filter((content) => content.includes("CONTENT:\n") && !content.includes("Unable to extract")).length;
        logWithTimestamp(`Multitab analysis summary: ${tabsWithContent}/${selectedTabIds.length} tabs with content, total ${totalContentLength} characters`);
        enhancedPrompt = `MULTI-TAB RESEARCH ANALYSIS REQUEST

Original Request: ${prompt}

I have gathered content from ${selectedTabIds.length} tabs for your analysis. Successfully extracted meaningful content from ${tabsWithContent} tabs. Please analyze all the provided content comprehensively and answer the original request based on the information from all tabs.

Here is the content from all selected tabs:

${combinedContent}

Please provide a comprehensive analysis based on ALL the tab contents above, addressing the original request: "${prompt}"

Note: Focus on the actual content from the tabs that were successfully analyzed. If some tabs couldn't be accessed, work with the available content.`;
        sendUIMessage("updateOutput", {
          type: "system",
          content: `✅ Successfully gathered content from ${tabsWithContent}/${selectedTabIds.length} tabs (${Math.round(totalContentLength / 1e3)}K characters). Proceeding with analysis...`
        }, targetTabId);
      } catch (error) {
        logWithTimestamp(`Error in multitab analysis: ${error instanceof Error ? error.message : String(error)}`, "error");
        sendUIMessage("updateOutput", {
          type: "system",
          content: `⚠️ Error gathering multitab content: ${error instanceof Error ? error.message : String(error)}. Proceeding with original prompt...`
        }, targetTabId);
        enhancedPrompt = prompt;
      }
    } else {
      logWithTimestamp(`Executing single-tab prompt (no selectedTabIds provided or empty array)`);
    }
    sendUIMessage("updateOutput", {
      type: "system",
      content: isMultiTabAnalysis ? `Executing multitab analysis prompt for ${selectedTabIds.length} tabs` : `Executing prompt: "${prompt}"`
    }, targetTabId);
    if (updatedTabState.windowId) {
      setAgentStatus(updatedTabState.windowId, AgentStatus.RUNNING);
    }
    const useStreaming = true;
    resetStreamingState();
    const history = await getStructuredMessageHistory(targetTabId);
    if (!history.originalRequest) {
      await setOriginalRequest(targetTabId, {
        role: "user",
        content: enhancedPrompt
      });
      await addToConversationHistory(targetTabId, {
        role: "user",
        content: enhancedPrompt
      });
      logWithTimestamp(`Set original request for tab ${targetTabId}: "${selectedTabIds && selectedTabIds.length > 0 ? "multitab analysis" : prompt}"`);
    } else {
      await addToConversationHistory(targetTabId, {
        role: "user",
        content: enhancedPrompt
      });
    }
    const traceRecorder = new TraceRecorder();
    traceRecorder.start();
    const callbacks = {
      onLlmChunk: (chunk) => {
        if (useStreaming) {
          const windowId = getWindowForTab(targetTabId);
          addToStreamingBuffer(chunk, targetTabId, windowId);
        }
      },
      onLlmOutput: async (content) => {
        if (!useStreaming) ;
        else {
          setStreamingBuffer(content);
        }
        if (isReflectionPrompt) {
          try {
            updatedTabState.page.evaluate(() => {
              var _a3;
              return ((_a3 = globalThis.location) == null ? void 0 : _a3.href) || "";
            }).then((url) => {
              const domain = new URL(url).hostname;
              saveReflectionMemory(content, domain, targetTabId);
            }).catch((error) => {
              logWithTimestamp(`Error getting domain for reflection: ${error instanceof Error ? error.message : String(error)}`, "error");
            });
          } catch (error) {
            logWithTimestamp(`Error in domain extraction for reflection: ${error instanceof Error ? error.message : String(error)}`, "error");
          }
        }
        try {
          await addToConversationHistory(targetTabId, { role: "assistant", content });
          const history2 = await getStructuredMessageHistory(targetTabId);
          const conversationTokens = contextTokenCount(history2.conversationHistory);
          if (conversationTokens > MAX_CONVERSATION_TOKENS) {
            logWithTimestamp(`Conversation history exceeds token budget (${conversationTokens}/${MAX_CONVERSATION_TOKENS}), trimming oldest messages`);
            while (contextTokenCount(history2.conversationHistory) > MAX_CONVERSATION_TOKENS && history2.conversationHistory.length > 1) {
              history2.conversationHistory.shift();
            }
            const windowId = getWindowForTab(targetTabId);
            if (windowId) {
              windowMessageHistories.set(windowId, history2);
            }
            logWithTimestamp(`Trimmed conversation history to ${history2.conversationHistory.length} messages (${contextTokenCount(history2.conversationHistory)} tokens)`);
          }
        } catch (error) {
          logWithTimestamp(`Error updating conversation history: ${error instanceof Error ? error.message : String(error)}`, "error");
        }
      },
      onToolOutput: (content) => {
        sendUIMessage("updateOutput", {
          type: "system",
          content
        }, targetTabId);
      },
      onToolEnd: (result) => {
        try {
          const data = JSON.parse(result);
          if (data.type === "screenshotRef" && data.id) {
            const screenshotManager2 = ScreenshotManager.getInstance();
            const screenshotData = screenshotManager2.getScreenshot(data.id);
            if (screenshotData && screenshotData.source && screenshotData.source.data) {
              sendUIMessage("updateScreenshot", {
                type: "screenshot",
                content: data.note || "Screenshot captured",
                imageData: screenshotData.source.data,
                mediaType: screenshotData.source.media_type || "image/jpeg"
              }, targetTabId);
              logWithTimestamp(`Sent screenshot ${data.id} to UI for tab ${targetTabId}`);
            } else {
              logWithTimestamp(`Screenshot data not found for ID ${data.id}`, "warn");
            }
          }
        } catch (error) {
        }
      },
      onError: (error) => {
        var _a3, _b, _c;
        if (((_a3 = error == null ? void 0 : error.error) == null ? void 0 : _a3.type) === "rate_limit_error" || ((_b = error == null ? void 0 : error.error) == null ? void 0 : _b.type) === "overloaded_error") {
          const errorType = ((_c = error == null ? void 0 : error.error) == null ? void 0 : _c.type) === "overloaded_error" ? "Anthropic servers overloaded" : "Rate limit exceeded";
          logWithTimestamp(`${errorType} error detected: ${JSON.stringify(error)}`, "warn");
          sendUIMessage("updateOutput", {
            type: "system",
            content: `⚠️ ${errorType}. Retrying... (${error.error.message})`
          }, targetTabId);
          sendUIMessage("rateLimit", {
            isRetrying: true
          }, targetTabId);
        }
      },
      onFallbackStarted: () => {
        logWithTimestamp("Fallback started, notifying UI to maintain processing state");
        sendUIMessage("fallbackStarted", {
          message: "Switching to fallback mode due to error. Processing continues..."
        }, targetTabId);
        sendUIMessage("rateLimit", {
          isRetrying: true
        }, targetTabId);
      },
      onSegmentComplete: (segment) => {
        if (useStreaming) {
          const windowId = getWindowForTab(targetTabId);
          finalizeStreamingSegment(getCurrentSegmentId(), segment, targetTabId, windowId);
          incrementSegmentId();
        }
      },
      onToolStart: (toolName, toolInput) => {
        if (useStreaming) {
          const windowId = getWindowForTab(targetTabId);
          startNewSegment(getCurrentSegmentId(), targetTabId, windowId);
        }
      },
      onToolEvent: (event) => {
        traceRecorder.record({ ...event, tabId: targetTabId, windowId: updatedTabState.windowId });
      },
      onComplete: () => {
        const windowId = getWindowForTab(targetTabId);
        if (useStreaming && getStreamingBuffer().trim()) {
          const hasToolCall = /<tool>(.*?)<\/tool>\s*<input>([\s\S]*?)<\/input>/.test(getStreamingBuffer());
          if (!hasToolCall) {
            finalizeStreamingSegment(getCurrentSegmentId(), getStreamingBuffer(), targetTabId, windowId);
          }
        }
        clearStreamingBuffer(targetTabId, windowId);
        if (useStreaming) {
          signalStreamingComplete(targetTabId, windowId);
        }
        if (windowId) {
          setAgentStatus(windowId, AgentStatus.IDLE);
        }
        const trace = traceRecorder.finish();
        if (trace.length > 0 && !isReflectionPrompt && !isMultiTabAnalysis) {
          const domain = currentDomain;
          const candidate = compileTrace(trace, domain, prompt.slice(0, 60) || "Recorded workflow");
          void WorkflowStore.getInstance().saveVersion(candidate.version).then(() => WorkflowStore.getInstance().saveWorkflow(candidate.workflow)).then(() => sendUIMessage("updateOutput", { type: "system", content: `Workflow draft created: ${candidate.workflow.name}` }, targetTabId)).catch((error) => logWithTimestamp(`Could not save workflow draft: ${String(error)}`, "warn"));
        }
        sendUIMessage("processingComplete", null, targetTabId, windowId);
      }
    };
    const updatedWindowId = updatedTabState.windowId;
    if (!updatedWindowId) {
      sendUIMessage("updateOutput", {
        type: "system",
        content: `Error: No window ID found for tab ${targetTabId}.`
      }, targetTabId);
      sendUIMessage("processingComplete", null, targetTabId);
      return;
    }
    const agent = getAgentForWindow(updatedWindowId);
    if (!agent) {
      sendUIMessage("updateOutput", {
        type: "system",
        content: `Error: No agent found for window ${updatedWindowId}.`
      }, targetTabId);
      sendUIMessage("processingComplete", null, targetTabId);
      return;
    }
    const messageHistory = await getMessageHistory(targetTabId);
    console.log("role in controller is ", role);
    console.log("executing with enhanced prompt for multitab:", selectedTabIds && selectedTabIds.length > 0);
    await executePromptWithFallback(
      agent,
      enhancedPrompt,
      callbacks,
      messageHistory,
      role
    );
  } catch (error) {
    const errorMessage = handleError(error, "executing prompt");
    sendUIMessage("updateOutput", {
      type: "system",
      content: `Error: ${errorMessage}`
    }, tabId);
    sendUIMessage("processingComplete", null, tabId);
  }
}
const agentController = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  addToConversationHistory,
  cancelExecution,
  clearMessageHistory,
  executePrompt,
  getAgentStatus,
  getMessageHistory,
  getStructuredMessageHistory,
  initializeAgent,
  setAgentStatus,
  setOriginalRequest
}, Symbol.toStringTag, { value: "Module" }));
class SimpleChatAgent {
  /**
   * Create a new SimpleChatAgent
   * @param llmProvider The LLM provider to use
   * @param systemPrompt The system prompt for the agent
   */
  constructor(llmProvider, systemPrompt = "") {
    __publicField(this, "llmProvider");
    __publicField(this, "systemPrompt");
    __publicField(this, "conversationHistory", []);
    __publicField(this, "cancelled", false);
    this.llmProvider = llmProvider;
    this.systemPrompt = systemPrompt;
  }
  /**
   * Update the system prompt
   */
  setSystemPrompt(systemPrompt) {
    this.systemPrompt = systemPrompt;
  }
  /**
   * Get the current system prompt
   */
  getSystemPrompt() {
    return this.systemPrompt;
  }
  /**
   * Cancel the current execution
   */
  cancel() {
    this.cancelled = true;
  }
  /**
   * Reset the cancel flag
   */
  resetCancel() {
    this.cancelled = false;
  }
  /**
   * Clear conversation history
   */
  clearHistory() {
    this.conversationHistory = [];
  }
  /**
   * Get conversation history
   */
  getHistory() {
    return [...this.conversationHistory];
  }
  /**
   * Set conversation history (useful for restoring previous conversations)
   */
  setHistory(history) {
    this.conversationHistory = [...history];
  }
  /**
   * Track token usage from stream chunks
   */
  trackTokenUsage(chunk, inputTokens, outputTokens, tokenTracker) {
    let updatedInputTokens = inputTokens;
    let updatedOutputTokens = outputTokens;
    if (chunk.inputTokens) {
      updatedInputTokens = chunk.inputTokens;
      tokenTracker.trackInputTokens(updatedInputTokens, {
        write: chunk.cacheWriteTokens,
        read: chunk.cacheReadTokens
      });
    }
    if (chunk.outputTokens) {
      const newOutputTokens = chunk.outputTokens;
      if (newOutputTokens > updatedOutputTokens) {
        const delta = newOutputTokens - updatedOutputTokens;
        tokenTracker.trackOutputTokens(delta);
        updatedOutputTokens = newOutputTokens;
      }
    }
    return { updatedInputTokens, updatedOutputTokens };
  }
  /**
   * Send a message and get a response with streaming support
   * @param message The user message
   * @param callbacks Callbacks for handling response
   * @param useHistory Whether to use conversation history (default: true)
   */
  async chat(message, callbacks, useHistory = true) {
    this.resetCancel();
    try {
      const messages = useHistory ? [...this.conversationHistory, { role: "user", content: message }] : [{ role: "user", content: message }];
      let accumulatedText = "";
      let inputTokens = 0;
      let outputTokens = 0;
      const tokenTracker = TokenTrackingService.getInstance();
      const stream = this.llmProvider.createMessage(
        this.systemPrompt,
        messages,
        []
        // No tools
      );
      for await (const chunk of stream) {
        if (this.cancelled) {
          callbacks.onComplete(accumulatedText);
          return;
        }
        if (chunk.type === "usage") {
          const result = this.trackTokenUsage(
            chunk,
            inputTokens,
            outputTokens,
            tokenTracker
          );
          inputTokens = result.updatedInputTokens;
          outputTokens = result.updatedOutputTokens;
        }
        if (chunk.type === "text" && chunk.text) {
          const textChunk = chunk.text;
          accumulatedText += textChunk;
          if (callbacks.onChunk) {
            callbacks.onChunk(textChunk);
          }
        }
      }
      if (useHistory) {
        this.conversationHistory.push({ role: "user", content: message });
        this.conversationHistory.push({
          role: "assistant",
          content: accumulatedText
        });
        this.conversationHistory = trimHistory(this.conversationHistory);
      }
      callbacks.onComplete(accumulatedText);
    } catch (error) {
      console.error("SimpleChatAgent error:", error);
      if (callbacks.onError) {
        callbacks.onError(error);
      } else {
        callbacks.onComplete("");
      }
    }
  }
  /**
   * Send a message and get a response without streaming (waits for full response)
   * @param message The user message
   * @param useHistory Whether to use conversation history (default: true)
   * @returns The full response text
   */
  async chatSync(message, useHistory = true) {
    return new Promise((resolve, reject) => {
      this.chat(
        message,
        {
          onComplete: (fullResponse) => resolve(fullResponse),
          onError: (error) => reject(error)
        },
        useHistory
      );
    });
  }
}
const TRANSLATION_CACHE_VERSION = 1;
function hashText(text) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16);
}
const memory = /* @__PURE__ */ new Map();
const keyOf = (p) => [TRANSLATION_CACHE_VERSION, hashText(p.text), p.sourceLanguage || "auto", p.targetLanguage, p.engine, p.model || "", p.style || "natural", p.contextHash || ""].join(":");
const translationCache = {
  keyOf,
  async get(params) {
    var _a2;
    const key = keyOf(params);
    const m = memory.get(key);
    if (m) return m;
    try {
      const r = await chrome.storage.local.get({ translationCache: {} });
      return (_a2 = r.translationCache) == null ? void 0 : _a2[key];
    } catch {
      return void 0;
    }
  },
  async set(params, value) {
    const key = keyOf(params);
    const entry = { ...value, key, createdAt: Date.now() };
    memory.set(key, entry);
    try {
      const r = await chrome.storage.local.get({ translationCache: {} });
      await chrome.storage.local.set({ translationCache: { ...r.translationCache || {}, [key]: entry } });
    } catch {
    }
  },
  async clear(scope) {
    memory.clear();
    if (scope === "all" || !scope) {
      try {
        await chrome.storage.local.set({ translationCache: {} });
      } catch {
      }
    }
  }
};
function mapProviderTranslations(units, parsed) {
  const translations = /* @__PURE__ */ new Map();
  units.forEach((unit, index) => {
    const transportId = String(index + 1);
    const item = parsed.find((candidate) => String(candidate.sourceId) === transportId);
    if (typeof (item == null ? void 0 : item.translation) === "string" && item.translation.length > 0) {
      translations.set(unit.sourceId, item.translation);
    }
  });
  return translations;
}
async function translateBatch(request, signal) {
  const configManager = ConfigManager.getInstance();
  const primaryConfig = await configManager.getProviderConfig();
  const preferred = request.engine === "auto" ? primaryConfig.translationProvider === "ollama" ? "ollama" : "configured-provider" : request.engine;
  if (preferred === "chrome") throw new Error("Chrome Translator API is not available in background yet");
  const providerName = preferred === "ollama" ? "ollama" : primaryConfig.translationProvider && primaryConfig.translationProvider !== "primary" ? primaryConfig.translationProvider : primaryConfig.provider;
  const config = providerName === primaryConfig.provider ? primaryConfig : await configManager.getProviderConfig(providerName);
  const engine = providerName === "ollama" ? "ollama" : "configured-provider";
  const results = [];
  const misses = [];
  for (const unit of request.units) {
    const cached = await translationCache.get({ text: unit.text, sourceLanguage: request.sourceLanguage, targetLanguage: request.targetLanguage, engine, model: config.apiModelId, style: request.style, contextHash: unit.contextHash });
    if (cached) results.push(cached);
    else misses.push(unit);
  }
  console.info("[translation][service] batch prepared", { pageSessionId: request.pageSessionId, requestId: request.requestId, provider: providerName, model: config.apiModelId, targetLanguage: request.targetLanguage, requested: request.units.length, cacheHits: results.length, misses: misses.length });
  if (!misses.length) return results;
  const provider = await createProvider(providerName, { apiKey: config.apiKey, apiModelId: config.apiModelId, baseUrl: config.baseUrl, thinkingBudgetTokens: 0, dangerouslyAllowBrowser: true });
  const system = `Translate each input into ${request.targetLanguage}. Return ONLY a JSON array of objects [{"sourceId":"1","translation":"..."}] preserving the short numeric sourceId exactly. Style: ${request.style || "natural"}. ${request.context || ""}`;
  if (signal == null ? void 0 : signal.aborted) throw new Error("aborted");
  const input = JSON.stringify(misses.map((unit, index) => ({ sourceId: String(index + 1), text: unit.text })));
  let text = "";
  for await (const chunk of provider.createMessage(system, [{ role: "user", content: input }], [])) {
    if (chunk.type === "text") text += chunk.text || "";
    if (signal == null ? void 0 : signal.aborted) throw new Error("aborted");
  }
  console.info("[translation][service] provider response received", { pageSessionId: request.pageSessionId, requestId: request.requestId, chars: text.length });
  let parsed;
  try {
    parsed = JSON.parse(text.replace(/^```json\s*|```$/g, "").trim());
  } catch {
    console.error("[translation][service] response parse failed", { pageSessionId: request.pageSessionId, requestId: request.requestId, chars: text.length });
    throw new Error("Malformed translation response");
  }
  console.info("[translation][service] response parsed", { pageSessionId: request.pageSessionId, requestId: request.requestId, items: parsed.length });
  const translations = mapProviderTranslations(misses, parsed);
  for (const unit of misses) {
    const translatedText = translations.get(unit.sourceId);
    if (!translatedText) continue;
    const result = { sourceId: unit.sourceId, sourceTextHash: hashText(unit.text), translatedText, state: "translated", sourceLanguage: request.sourceLanguage, targetLanguage: request.targetLanguage, engine, model: config.apiModelId, cacheVersion: 1 };
    results.push(result);
    await translationCache.set({ text: unit.text, sourceLanguage: request.sourceLanguage, targetLanguage: request.targetLanguage, engine, model: config.apiModelId, style: request.style, contextHash: unit.contextHash }, result);
  }
  console.info("[translation][service] batch results built", { pageSessionId: request.pageSessionId, requestId: request.requestId, results: results.length, requested: request.units.length });
  return results;
}
class TranslationQueue {
  constructor(execute, maxChars = 5e3, maxItems = 12, batchDelayMs = 25) {
    __publicField(this, "pending", /* @__PURE__ */ new Map());
    __publicField(this, "ready", []);
    __publicField(this, "active", /* @__PURE__ */ new Set());
    __publicField(this, "cancelled", /* @__PURE__ */ new Set());
    this.execute = execute;
    this.maxChars = maxChars;
    this.maxItems = maxItems;
    this.batchDelayMs = batchDelayMs;
  }
  cancel(scope) {
    this.cancelled.add(scope);
    for (const [key, batch] of this.pending) {
      const cancelledTasks = batch.tasks.filter((task) => task.request.pageSessionId === scope);
      const remainingTasks = batch.tasks.filter((task) => task.request.pageSessionId !== scope);
      cancelledTasks.forEach((task) => task.resolve([]));
      if (!remainingTasks.length) {
        if (batch.timer) clearTimeout(batch.timer);
        this.pending.delete(key);
      } else if (remainingTasks.length !== batch.tasks.length) {
        batch.tasks = remainingTasks;
        batch.chars = remainingTasks.reduce((sum, task) => sum + task.unit.text.length, 0);
      }
    }
    for (const batch of this.active) {
      if (batch.tasks.every((task) => this.cancelled.has(task.request.pageSessionId))) {
        batch.controller.abort();
      }
    }
    this.ready = this.ready.flatMap((batch) => {
      const cancelledTasks = batch.tasks.filter((task) => task.request.pageSessionId === scope);
      const remainingTasks = batch.tasks.filter((task) => task.request.pageSessionId !== scope);
      cancelledTasks.forEach((task) => task.resolve([]));
      return remainingTasks.length ? [{ ...batch, tasks: remainingTasks }] : [];
    });
  }
  isCancelled(scope) {
    return this.cancelled.has(scope);
  }
  enqueue(request) {
    if (this.isCancelled(request.pageSessionId)) return Promise.resolve([]);
    return Promise.all(request.units.map((unit) => this.enqueueUnit(request, unit))).then((groups) => groups.flat());
  }
  enqueueUnit(request, unit) {
    return new Promise((resolve, reject) => {
      const task = { request, unit, resolve, reject };
      const key = this.getBatchKey(request);
      let batch = this.pending.get(key);
      if (batch && (batch.tasks.length >= this.maxItems || batch.chars + unit.text.length > this.maxChars)) {
        this.flush(key);
        batch = void 0;
      }
      if (!batch) {
        batch = { tasks: [], chars: 0 };
        this.pending.set(key, batch);
        batch.timer = setTimeout(() => this.flush(key), this.batchDelayMs);
      }
      batch.tasks.push(task);
      batch.chars += unit.text.length;
      if (batch.tasks.length >= this.maxItems || batch.chars >= this.maxChars) this.flush(key);
    });
  }
  getBatchKey(request) {
    return [request.engine, request.model, request.sourceLanguage, request.targetLanguage, request.style, request.context].join("|");
  }
  flush(key) {
    const pending = this.pending.get(key);
    if (!pending) return;
    this.pending.delete(key);
    if (pending.timer) clearTimeout(pending.timer);
    const tasks = pending.tasks.filter((task) => !this.isCancelled(task.request.pageSessionId));
    pending.tasks.filter((task) => this.isCancelled(task.request.pageSessionId)).forEach((task) => task.resolve([]));
    if (!tasks.length) return;
    const controller = new AbortController();
    this.ready.push({ tasks, controller });
    this.drain();
  }
  drain() {
    while (this.active.size < 2 && this.ready.length) {
      const batch = this.ready.shift();
      this.active.add(batch);
      void this.executeBatch(batch.tasks, batch.controller.signal).finally(() => {
        this.active.delete(batch);
        this.drain();
      });
    }
  }
  async executeBatch(tasks, signal) {
    const first = tasks[0].request;
    let lastError;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const results = await this.execute({ ...first, units: tasks.map((task) => task.unit) }, signal);
        const resultsById = new Map(results.map((result) => [result.sourceId, result]));
        const missing = tasks.filter((task) => !resultsById.has(task.unit.sourceId));
        if (missing.length) {
          lastError = new Error("Translation result count mismatch");
          if (attempt < 2) continue;
          for (const task of tasks) {
            const result = resultsById.get(task.unit.sourceId);
            if (result) task.resolve([result]);
          }
          await this.executeIndividually(missing, signal);
          return;
        }
        for (const task of tasks) {
          if (this.isCancelled(task.request.pageSessionId)) task.resolve([]);
          else {
            const result = resultsById.get(task.unit.sourceId);
            if (result) task.resolve([result]);
            else task.reject(lastError || new Error(`Missing translation result for ${task.unit.sourceId}`));
          }
        }
        return;
      } catch (error) {
        lastError = error;
        if (signal.aborted || attempt === 2) break;
      }
    }
    for (const task of tasks) {
      if (this.isCancelled(task.request.pageSessionId)) task.resolve([]);
      else task.reject(lastError);
    }
  }
  async executeIndividually(tasks, signal) {
    await Promise.allSettled(tasks.map(async (task) => {
      if (this.isCancelled(task.request.pageSessionId)) {
        task.resolve([]);
        return;
      }
      try {
        const results = await this.execute({ ...task.request, units: [task.unit] }, signal);
        const result = results.find((item) => item.sourceId === task.unit.sourceId);
        if (!result) throw new Error(`Missing translation result for ${task.unit.sourceId}`);
        task.resolve([result]);
      } catch (error) {
        if (this.isCancelled(task.request.pageSessionId)) task.resolve([]);
        else task.reject(error);
      }
    }));
  }
}
function createPageTranslationStartMessage(message, settings, pageSessionId) {
  return {
    ...message,
    action: "startPageTranslation",
    targetLanguage: message.targetLanguage || settings.targetLanguage,
    translateTitle: message.translateTitle ?? settings.translateTitle,
    pageSessionId
  };
}
async function sendToTranslationContentScript(tabId, message) {
  try {
    await chrome.tabs.sendMessage(tabId, message);
  } catch (firstError) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["pageTranslation.js"]
      });
      await chrome.tabs.sendMessage(tabId, message);
    } catch (injectionError) {
      throw new Error(`Unable to start translation on this page: ${String(injectionError || firstError)}`);
    }
  }
}
async function deliverTranslationBatchResult(tabId, message, results) {
  await chrome.tabs.sendMessage(tabId, {
    action: "translationBatchResult",
    pageSessionId: message.pageSessionId,
    requestId: message.requestId,
    results
  });
}
const translationQueue = new TranslationQueue((request, signal) => translateBatch(request, signal));
const activeTranslationSessions = /* @__PURE__ */ new Map();
const workflowRunners = /* @__PURE__ */ new Map();
const workflowRunByExecutionTab = /* @__PURE__ */ new Map();
function handleMessage(message, sender, sendResponse) {
  var _a2;
  try {
    if (!isBackgroundMessage(message)) {
      logWithTimestamp(`Ignoring unknown message type: ${JSON.stringify(message)}`, "warn");
      sendResponse({ success: false, error: "Unknown message type" });
      return false;
    }
    switch (message.action) {
      case "executePrompt":
        handleExecutePrompt(message, sendResponse);
        return true;
      // Keep the message channel open for async response
      case "runWorkflow":
        handleRunWorkflow(message, sendResponse).catch((error) => sendResponse({ success: false, error: String(error) }));
        return true;
      case "cancelExecution":
        handleCancelExecution(message, sendResponse);
        return true;
      case "cancelWorkflow":
        (_a2 = workflowRunners.get(message.runId)) == null ? void 0 : _a2.runner.cancel();
        sendResponse({ success: true });
        return true;
      case "clearHistory":
        handleClearHistory(message, sendResponse).catch((error) => {
          const errorMessage = handleError(error, "clearing history");
          logWithTimestamp(`Error in async handleClearHistory: ${errorMessage}`, "error");
          sendResponse({ success: false, error: errorMessage });
        });
        return true;
      // Keep the message channel open for async response
      case "initializeTab":
        handleInitializeTab(message, sendResponse);
        return true;
      // Keep the message channel open for async response
      case "switchToTab":
        handleSwitchToTab(message, sendResponse).catch((error) => {
          sendResponse({ success: false, error: String(error) });
        });
        return true;
      case "refreshTab":
        handleRefreshTab(message, sendResponse).catch((error) => {
          sendResponse({ success: false, error: String(error) });
        });
        return true;
      case "getTokenUsage":
        handleGetTokenUsage(message, sendResponse);
        return true;
      case "approvalResponse":
        handleApprovalResponse(message.requestId, message.approved, message.runId);
        sendResponse({ success: true });
        return true;
      case "reflectAndLearn":
        handleReflectAndLearn(message, sendResponse);
        return true;
      case "tokenUsageUpdated":
        sendResponse({ success: true });
        return true;
      case "updateOutput":
        sendResponse({ success: true });
        return true;
      case "providerConfigChanged":
        sendResponse({ success: true });
        return true;
      case "forceResetPlaywright":
        handleForceResetPlaywright(message, sendResponse).catch((error) => {
          const errorMessage = handleError(error, "force resetting Playwright");
          logWithTimestamp(`Error in async handleForceResetPlaywright: ${errorMessage}`, "error");
          sendResponse({ success: false, error: errorMessage });
        });
        return true;
      // Keep the message channel open for async response
      case "requestApproval":
        sendResponse({ success: true });
        return true;
      case "checkAgentStatus":
        handleCheckAgentStatus(message, sendResponse).catch((error) => {
          const errorMessage = handleError(error, "checking agent status");
          logWithTimestamp(`Error in async handleCheckAgentStatus: ${errorMessage}`, "error");
          sendResponse({ success: false, error: errorMessage });
        });
        return true;
      // Keep the message channel open for async response
      case "download-markdown":
        console.log("download message is", message.filename);
        handleDownloadMarkdown(message);
        sendResponse({ success: true });
        return false;
      case "togglePdfInterception":
        handleTogglePdfInterception(message, sendResponse);
        return true;
      case "checkPdfUrl":
        handleCheckPdfUrl(message, sendResponse);
        return true;
      case "fetchPdfAsBlob":
        handleFetchPdfAsBlob(message, sendResponse);
        return true;
      case "pdfAiChat":
        handlePdfAiChat(message, sendResponse).catch((error) => {
          const errorMessage = handleError(error, "handling PDF AI chat");
          logWithTimestamp(`Error in async handlePdfAiChat: ${errorMessage}`, "error");
          sendResponse({ success: false, error: errorMessage });
        });
        return true;
      // Keep the message channel open for async response
      case "translatePage":
        handlePageTranslation(message, sendResponse);
        return true;
      case "stopPageTranslation":
        if (typeof message.tabId === "number") {
          const pageSessionId = message.pageSessionId || activeTranslationSessions.get(message.tabId);
          if (pageSessionId) translationQueue.cancel(pageSessionId);
          activeTranslationSessions.delete(message.tabId);
          Promise.resolve(chrome.tabs.sendMessage(message.tabId, { action: "stopPageTranslation", pageSessionId, requestId: message.requestId })).catch(() => {
          });
        }
        sendResponse({ success: true });
        return true;
      case "setTranslationMode":
        if (typeof message.tabId === "number") Promise.resolve(chrome.tabs.sendMessage(message.tabId, message)).catch(() => {
        });
        sendResponse({ success: true });
        return true;
      case "translationBatch":
        handleTranslationBatch(message, sender, sendResponse);
        return true;
      case "translateSelection":
        handleSelectionTranslation(message, sender, sendResponse);
        return true;
      case "translationCapability":
        sendResponse({ success: true, chromeTranslator: typeof globalThis.Translator !== "undefined", ollama: true, configuredProvider: true });
        return true;
      default:
        logWithTimestamp(`Unhandled message action: ${message.action}`, "warn");
        sendResponse({ success: false, error: "Unhandled message action" });
        return false;
    }
  } catch (error) {
    const errorMessage = handleError(error, "handling message");
    logWithTimestamp(`Error handling message: ${errorMessage}`, "error");
    sendResponse({ success: false, error: errorMessage });
    return false;
  }
}
function handleDownloadMarkdown(message) {
  try {
    const blob = new Blob([message.content], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({
      url,
      filename: message.filename,
      saveAs: true
    });
  } catch (error) {
    const errorMessage = handleError(error, "handleDownloadMarkdown message");
    logWithTimestamp(`Error handleDownloadMarkdown message: ${errorMessage}`, "error");
  }
}
function isBackgroundMessage(message) {
  return message && typeof message === "object" && "action" in message && (message.action === "executePrompt" || message.action === "runWorkflow" || message.action === "cancelExecution" || message.action === "cancelWorkflow" || message.action === "clearHistory" || message.action === "initializeTab" || message.action === "switchToTab" || message.action === "getTokenUsage" || message.action === "approvalResponse" || message.action === "reflectAndLearn" || message.action === "tokenUsageUpdated" || // Add support for token usage updates
  message.action === "updateOutput" || // Add support for output updates
  message.action === "providerConfigChanged" || // Add support for provider config changes
  message.action === "tabStatusChanged" || message.action === "targetCreated" || message.action === "targetDestroyed" || message.action === "targetChanged" || message.action === "tabTitleChanged" || message.action === "pageDialog" || message.action === "pageConsole" || message.action === "pageError" || message.action === "forceResetPlaywright" || message.action === "requestApproval" || // Add support for request approval messages
  message.action === "checkAgentStatus" || // Add support for agent status check
  message.action === "download-markdown" || message.action === "togglePdfInterception" || message.action === "checkPdfUrl" || message.action === "fetchPdfAsBlob" || message.action === "pdfAiChat" || message.action === "translatePage" || message.action === "stopPageTranslation" || message.action === "setTranslationMode" || message.action === "translateSelection" || message.action === "translationBatch" || message.action === "translationBatchResult" || message.action === "translationStatus" || message.action === "translationCapability");
}
async function handlePageTranslation(message, sendResponse) {
  const tabId = message.tabId;
  if (typeof tabId !== "number") {
    sendResponse({ success: false, error: "tabId required" });
    return;
  }
  const pageSessionId = message.pageSessionId || `${tabId}-${Date.now()}`;
  const previousSessionId = activeTranslationSessions.get(tabId);
  if (previousSessionId && previousSessionId !== pageSessionId) translationQueue.cancel(previousSessionId);
  console.info("[translation][background] translatePage received", { tabId, pageSessionId, mode: message.mode });
  try {
    const settings = await ConfigManager.getInstance().getTranslationSettings();
    console.info("[translation][background] settings loaded", { targetLanguage: message.targetLanguage || settings.targetLanguage, translateTitle: message.translateTitle ?? settings.translateTitle });
    await sendToTranslationContentScript(tabId, createPageTranslationStartMessage(message, settings, pageSessionId));
    activeTranslationSessions.set(tabId, pageSessionId);
    console.info("[translation][background] start sent to content script", { tabId, pageSessionId });
    sendResponse({ success: true, pageSessionId });
  } catch (error) {
    sendResponse({ success: false, error: String(error) });
  }
}
async function handleTranslationBatch(message, sender, sendResponse) {
  var _a2, _b;
  const tabId = message.tabId ?? ((_a2 = sender.tab) == null ? void 0 : _a2.id);
  if (typeof tabId !== "number") return;
  console.info("[translation][background] batch received", { tabId, pageSessionId: message.pageSessionId, requestId: message.requestId, units: (_b = message.units) == null ? void 0 : _b.length, targetLanguage: message.targetLanguage });
  try {
    const results = await translationQueue.enqueue({ ...message, tabId });
    console.info("[translation][background] batch completed", { tabId, pageSessionId: message.pageSessionId, requestId: message.requestId, results: results.length });
    await deliverTranslationBatchResult(tabId, message, results);
    console.info("[translation][background] batch delivered", { tabId, pageSessionId: message.pageSessionId, requestId: message.requestId, results: results.length });
    sendResponse({ success: true, pageSessionId: message.pageSessionId, requestId: message.requestId, results });
  } catch (error) {
    console.error("[translation][background] batch failed", { tabId, pageSessionId: message.pageSessionId, requestId: message.requestId, error: String(error) });
    sendResponse({ success: false, pageSessionId: message.pageSessionId, requestId: message.requestId, error: String(error) });
  }
}
async function translateSelectionForTab(tabId, message) {
  var _a2;
  try {
    const result = await translateBatch({ ...message, tabId, pageSessionId: message.pageSessionId || `selection-${tabId}`, units: [{ sourceId: message.sourceId || "selection", text: message.text, kind: "selection" }] });
    await sendToTranslationContentScript(tabId, { action: "translationSelectionResult", requestId: message.requestId, translatedText: ((_a2 = result[0]) == null ? void 0 : _a2.translatedText) || "" });
  } catch (error) {
    await sendToTranslationContentScript(tabId, { action: "translationSelectionResult", requestId: message.requestId, error: String(error) }).catch(() => {
    });
  }
}
async function handleSelectionTranslation(message, sender, sendResponse) {
  var _a2;
  const tabId = message.tabId ?? ((_a2 = sender.tab) == null ? void 0 : _a2.id);
  if (typeof tabId !== "number") {
    sendResponse({ success: false, error: "tabId required" });
    return;
  }
  try {
    const settings = await ConfigManager.getInstance().getTranslationSettings();
    await translateSelectionForTab(tabId, { ...message, targetLanguage: message.targetLanguage || settings.targetLanguage });
    sendResponse({ success: true });
  } catch (error) {
    sendResponse({ success: false, error: String(error) });
  }
}
async function handleRunWorkflow(message, sendResponse) {
  var _a2;
  let tabId = message.ownerTabId ?? message.tabId;
  let executionTabId;
  try {
    tabId ?? (tabId = (_a2 = (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0]) == null ? void 0 : _a2.id);
    if (!tabId) throw new Error("No active tab");
    const workflow = await WorkflowStore.getInstance().getWorkflow(message.workflowId);
    if (!workflow) throw new Error("Workflow not found");
    const version = await WorkflowStore.getInstance().getVersion(message.versionId || workflow.activeVersionId);
    if (!version) throw new Error("Workflow version not found");
    if (workflow.status === "archived") throw new Error("Archived workflows cannot be run");
    const ownerTab = await chrome.tabs.get(tabId);
    const ownerWindowId = message.ownerWindowId ?? ownerTab.windowId ?? getWindowForTab(tabId);
    if (ownerWindowId === void 0) throw new Error("Workflow owner window is unavailable");
    const executionMode = message.executionMode ?? workflow.executionMode ?? "current_tab";
    const startUrl = resolveWorkflowStartUrl(workflow.startUrl, version.steps);
    let executionPage;
    let executionWindowId = ownerWindowId;
    if (executionMode === "new_tab") {
      if (!startUrl) throw new Error("INVALID_START_URL: Workflow requires an HTTP(S) start URL for new-tab execution");
      const created = await createWorkflowExecutionTab(ownerWindowId, startUrl);
      executionTabId = created.tabId;
      executionWindowId = created.windowId;
      executionPage = created.page;
    } else {
      executionTabId = tabId;
      let tabState = getTabState(tabId);
      if (!(tabState == null ? void 0 : tabState.page)) {
        await attachToTab(tabId, ownerWindowId);
        tabState = getTabState(tabId);
      }
      executionPage = tabState == null ? void 0 : tabState.page;
    }
    if (!executionPage || executionTabId === void 0) throw new Error("TAB_ATTACH_FAILED: Workflow could not connect to its execution tab.");
    sendUIMessage("updateOutput", { type: "system", content: `▶ Running automation: ${workflow.name}` }, tabId, executionWindowId);
    let lastStepResult = "";
    const runner = new WorkflowRunner();
    const runContext = { tabId: executionTabId, windowId: executionWindowId, ownerTabId: tabId };
    const pageRef = { current: executionPage };
    workflowRunners.set(`pending:${executionTabId}`, { runner, executionTabId, ownerTabId: tabId });
    workflowRunByExecutionTab.set(executionTabId, runner);
    const runPromise = new WorkflowService().run(workflow.id, version, executionPage, {
      variables: message.variables,
      context: runContext,
      pageRef,
      runner,
      callbacks: {
        onStepEnd: (_step, result) => {
          if (result.trim()) lastStepResult = result;
        }
      }
    });
    if (runner.currentRunId) workflowRunners.set(runner.currentRunId, { runner, executionTabId, ownerTabId: tabId, context: runContext });
    const run = await runPromise;
    if (runner.currentRunId) workflowRunners.set(runner.currentRunId, { runner, executionTabId, ownerTabId: tabId, context: runContext });
    workflowRunners.delete(`pending:${executionTabId}`);
    workflowRunners.delete(run.id);
    if (run.executionTabId !== void 0) workflowRunByExecutionTab.delete(run.executionTabId);
    if (lastStepResult) {
      sendUIMessage("updateOutput", { type: "llm", content: lastStepResult }, tabId, executionWindowId, { runId: run.id, workflowId: workflow.id, executionTabId: run.executionTabId });
    }
    sendUIMessage("updateOutput", { type: "system", content: `Automation ${run.status}: ${workflow.name}${run.failureMessage ? `
${run.failureMessage}` : ""}` }, tabId, executionWindowId, { runId: run.id, workflowId: workflow.id, executionTabId: run.executionTabId });
    sendUIMessage("processingComplete", null, tabId, executionWindowId, { runId: run.id, workflowId: workflow.id, executionTabId: run.executionTabId });
    sendResponse({ success: run.status === "succeeded", run });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error("[runWorkflow] failed", {
      workflowId: message.workflowId,
      versionId: message.versionId,
      tabId,
      message: errorMessage,
      stack: error instanceof Error ? error.stack : void 0
    });
    if (tabId) {
      sendUIMessage("updateOutput", { type: "system", content: `Automation failed: ${errorMessage}` }, tabId);
      sendUIMessage("processingComplete", null, tabId);
    }
    sendResponse({ success: false, error: errorMessage });
  }
}
if (typeof chrome !== "undefined" && ((_a = chrome.tabs) == null ? void 0 : _a.onRemoved)) {
  chrome.tabs.onRemoved.addListener((removedTabId) => {
    const runner = workflowRunByExecutionTab.get(removedTabId);
    if (runner) runner.cancel();
  });
}
function resolveWorkflowStartUrl(explicitUrl, steps) {
  var _a2;
  const candidate = explicitUrl ?? ((_a2 = steps.find((step) => step.type === "navigate" && typeof step.input === "string")) == null ? void 0 : _a2.input);
  if (!candidate) return void 0;
  try {
    const parsed = new URL(candidate);
    return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.toString() : void 0;
  } catch {
    return void 0;
  }
}
function handleExecutePrompt(message, sendResponse) {
  if (message.tabId) {
    if (message.multiTabAnalysis && message.selectedTabIds) {
      executePrompt(message.prompt, message.tabId, false, message.role, message.selectedTabIds, message.contextMode);
    } else {
      executePrompt(message.prompt, message.tabId, false, message.role, void 0, message.contextMode);
    }
  } else {
    executePrompt(message.prompt);
  }
  sendResponse({ success: true });
}
function handleCancelExecution(message, sendResponse) {
  cancelExecution(message.tabId);
  sendResponse({ success: true });
}
async function handleClearHistory(message, sendResponse) {
  await clearMessageHistory(message.tabId, message.windowId);
  try {
    const tokenTracker = TokenTrackingService.getInstance();
    tokenTracker.reset(message.windowId);
    chrome.runtime.sendMessage({
      action: "tokenUsageUpdated",
      content: tokenTracker.getUsage(),
      tabId: message.tabId,
      windowId: message.windowId
    });
  } catch (error) {
    logWithTimestamp(`Error resetting token tracking: ${String(error)}`, "warn");
  }
  sendResponse({ success: true });
}
function handleInitializeTab(message, sendResponse) {
  if (message.tabId) {
    setTimeout(async () => {
      try {
        let tabTitle = "Unknown Tab";
        try {
          const tab = await chrome.tabs.get(message.tabId);
          if (tab && tab.title) {
            tabTitle = tab.title;
          }
        } catch (titleError) {
          handleError(titleError, "getting tab title");
        }
        await attachToTab(message.tabId, message.windowId);
        await initializeAgent(message.tabId);
        const tabState = getTabState(message.tabId);
        if (tabState) {
          chrome.runtime.sendMessage({
            action: "updateOutput",
            content: {
              type: "system",
              content: `Connected to tab: ${tabState.title || tabTitle}`
            },
            tabId: message.tabId,
            windowId: tabState.windowId
          });
        }
        logWithTimestamp(`Tab ${message.tabId} in window ${message.windowId || "unknown"} initialized from side panel`);
      } catch (error) {
        handleError(error, "initializing tab from side panel");
      }
    }, 0);
  }
  sendResponse({ success: true });
}
async function handleSwitchToTab(message, sendResponse) {
  if (message.tabId) {
    const windowId = getWindowForTab(message.tabId);
    try {
      if (windowId) await chrome.windows.update(windowId, { focused: true });
      await activateTabSafely(message.tabId);
      logWithTimestamp(`Switched to tab ${message.tabId} in window ${windowId || "unknown"}`);
    } catch (error) {
      logWithTimestamp(`Could not switch to tab ${message.tabId}: ${error instanceof Error ? error.message : String(error)}`, "warn");
      sendResponse({ success: false, error: error instanceof Error ? error.message : String(error) });
      return;
    }
  }
  sendResponse({ success: true });
}
async function handleRefreshTab(message, sendResponse) {
  if (message.tabId) {
    const windowId = getWindowForTab(message.tabId);
    try {
      if (windowId) await chrome.windows.update(windowId, { focused: true });
      await activateTabSafely(message.tabId);
      logWithTimestamp(`Refreshed focus on tab ${message.tabId} in window ${windowId || "unknown"}`);
    } catch (error) {
      logWithTimestamp(`Could not refresh tab ${message.tabId}: ${error instanceof Error ? error.message : String(error)}`, "warn");
      sendResponse({ success: false, error: error instanceof Error ? error.message : String(error) });
      return;
    }
  }
  sendResponse({ success: true });
}
async function activateTabSafely(tabId) {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      await chrome.tabs.update(tabId, { active: true });
      return;
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (!/cannot be edited right now|dragging a tab/i.test(message) || attempt === 2) throw error;
      await new Promise((resolve) => setTimeout(resolve, 150 * (attempt + 1)));
    }
  }
}
function handleGetTokenUsage(message, sendResponse) {
  try {
    const tokenTracker = TokenTrackingService.getInstance();
    const usage = tokenTracker.getUsage();
    const windowId = message.windowId;
    const tabId = message.tabId;
    sendResponse({
      success: true,
      usage
    });
    chrome.runtime.sendMessage({
      action: "tokenUsageUpdated",
      content: usage,
      tabId,
      windowId
    });
  } catch (error) {
    const errorMessage = handleError(error, "getting token usage");
    logWithTimestamp(`Error getting token usage: ${errorMessage}`, "error");
    sendResponse({ success: false, error: errorMessage });
  }
}
function handleReflectAndLearn(message, sendResponse) {
  try {
    console.log("MEMORY DEBUG: handleReflectAndLearn called", { tabId: message.tabId });
    triggerReflection(message.tabId);
    console.log("MEMORY DEBUG: triggerReflection called successfully");
    sendResponse({ success: true });
  } catch (error) {
    console.error("MEMORY DEBUG: Error in handleReflectAndLearn", error);
    const errorMessage = handleError(error, "triggering reflection");
    logWithTimestamp(`Error triggering reflection: ${errorMessage}`, "error");
    sendResponse({ success: false, error: errorMessage });
  }
}
async function handleForceResetPlaywright(message, sendResponse) {
  var _a2, _b;
  try {
    logWithTimestamp("Force resetting Playwright instance");
    const result = await forceResetPlaywright();
    const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    const tabId = (_a2 = tabs[0]) == null ? void 0 : _a2.id;
    const windowId = (_b = tabs[0]) == null ? void 0 : _b.windowId;
    chrome.runtime.sendMessage({
      action: "updateOutput",
      content: {
        type: "system",
        content: `Playwright instance has been force reset. ${result ? "Success" : "Failed"}`
      },
      tabId,
      windowId
    });
    sendResponse({ success: result });
  } catch (error) {
    const errorMessage = handleError(error, "force resetting Playwright instance");
    logWithTimestamp(`Error force resetting Playwright instance: ${errorMessage}`, "error");
    sendResponse({ success: false, error: errorMessage });
  }
}
async function handleCheckAgentStatus(message, sendResponse) {
  try {
    const windowId = message.windowId || (message.tabId ? getWindowForTab(message.tabId) : null);
    if (!windowId) {
      logWithTimestamp(`Cannot check agent status: No window ID found for tab ${message.tabId}`, "warn");
      sendResponse({ success: false, error: "No window ID found" });
      return;
    }
    const { getAgentStatus: getAgentStatus2 } = await __vitePreload(async () => {
      const { getAgentStatus: getAgentStatus3 } = await Promise.resolve().then(() => agentController);
      return { getAgentStatus: getAgentStatus3 };
    }, true ? void 0 : void 0);
    const status = getAgentStatus2(windowId);
    chrome.runtime.sendMessage({
      action: "agentStatusUpdate",
      status: status.status,
      timestamp: status.timestamp,
      lastHeartbeat: status.lastHeartbeat,
      tabId: message.tabId,
      windowId
    });
    sendResponse({ success: true });
  } catch (error) {
    const errorMessage = handleError(error, "checking agent status");
    logWithTimestamp(`Error checking agent status: ${errorMessage}`, "error");
    sendResponse({ success: false, error: errorMessage });
  }
}
function handleTogglePdfInterception(message, sendResponse) {
  try {
    chrome.storage.sync.set({
      "pdf-interceptor-enabled": message.enabled
    }, () => {
      if (chrome.runtime.lastError) {
        logWithTimestamp(`Error storing PDF interception setting: ${chrome.runtime.lastError.message}`, "error");
        sendResponse({ success: false, error: chrome.runtime.lastError.message });
        return;
      }
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach((tab) => {
          if (tab.id) {
            chrome.tabs.sendMessage(tab.id, {
              action: "togglePdfInterception",
              enabled: message.enabled
            }).catch(() => {
            });
          }
        });
      });
      logWithTimestamp(`PDF interception ${message.enabled ? "enabled" : "disabled"}`);
      sendResponse({ success: true });
    });
  } catch (error) {
    const errorMessage = handleError(error, "toggling PDF interception");
    logWithTimestamp(`Error toggling PDF interception: ${errorMessage}`, "error");
    sendResponse({ success: false, error: errorMessage });
  }
}
function handleCheckPdfUrl(message, sendResponse) {
  try {
    if (!message.tabId) {
      sendResponse({ success: false, error: "No tab ID provided" });
      return;
    }
    chrome.tabs.sendMessage(message.tabId, {
      action: "checkPdfUrl"
    }).then((response) => {
      sendResponse({ success: true, ...response });
    }).catch((error) => {
      logWithTimestamp(`Error checking PDF URL in tab ${message.tabId}: ${error}`, "error");
      sendResponse({ success: false, error: "Failed to check PDF URL" });
    });
  } catch (error) {
    const errorMessage = handleError(error, "checking PDF URL");
    logWithTimestamp(`Error checking PDF URL: ${errorMessage}`, "error");
    sendResponse({ success: false, error: errorMessage });
  }
}
async function handleFetchPdfAsBlob(message, sendResponse) {
  try {
    const response = await fetch(message.url);
    if (!response.ok) {
      throw new Error(`Failed to fetch PDF: ${response.statusText}`);
    }
    const blob = await response.blob();
    const arrayBuffer = await blob.arrayBuffer();
    const base64 = btoa(
      Array.from(new Uint8Array(arrayBuffer)).map((byte) => String.fromCharCode(byte)).join("")
    );
    sendResponse({
      success: true,
      data: base64,
      type: blob.type
    });
  } catch (error) {
    const errorMessage = handleError(error, "fetching PDF as blob");
    logWithTimestamp(`Error fetching PDF as blob: ${errorMessage}`, "error");
    sendResponse({ success: false, error: errorMessage });
  }
}
async function handlePdfAiChat(message, sendResponse) {
  var _a2, _b, _c;
  console.log("[PDF AI Chat] Received request:", {
    hasMessage: !!message.message,
    messageLength: (_a2 = message.message) == null ? void 0 : _a2.length,
    hasSystemPrompt: !!message.systemPrompt,
    systemPromptLength: (_b = message.systemPrompt) == null ? void 0 : _b.length,
    hasChatHistory: !!message.chatHistory,
    historyLength: (_c = message.chatHistory) == null ? void 0 : _c.length
  });
  try {
    const { message: userMessage, systemPrompt, chatHistory } = message;
    if (!userMessage) {
      console.log("[PDF AI Chat] Error: No message provided");
      sendResponse({ success: false, error: "No message provided" });
      return;
    }
    console.log("[PDF AI Chat] User message:", userMessage.substring(0, 100) + "...");
    const configManager = ConfigManager.getInstance();
    const providerConfig = await configManager.getProviderConfig();
    console.log("[PDF AI Chat] Provider config:", {
      provider: providerConfig.provider,
      hasApiKey: !!providerConfig.apiKey,
      modelId: providerConfig.apiModelId,
      hasBaseUrl: !!providerConfig.baseUrl
    });
    if (!providerConfig.apiKey && providerConfig.provider !== "ollama") {
      console.log("[PDF AI Chat] Error: No API key configured for provider:", providerConfig.provider);
      sendResponse({
        success: false,
        error: "No LLM provider configured. Please configure an API key in the settings."
      });
      return;
    }
    console.log("[PDF AI Chat] Creating LLM provider...");
    const llmProvider = await createProvider(providerConfig.provider, {
      apiKey: providerConfig.apiKey || "",
      apiModelId: providerConfig.apiModelId,
      baseUrl: providerConfig.baseUrl,
      thinkingBudgetTokens: providerConfig.thinkingBudgetTokens,
      openaiCompatibleModels: providerConfig.openaiCompatibleModels
    });
    console.log("[PDF AI Chat] LLM provider created successfully");
    console.log("[PDF AI Chat] Creating SimpleChatAgent...");
    const chatAgent = new SimpleChatAgent(llmProvider, systemPrompt || "");
    console.log("[PDF AI Chat] SimpleChatAgent created with system prompt length:", (systemPrompt || "").length);
    if (chatHistory && Array.isArray(chatHistory) && chatHistory.length > 0) {
      console.log("[PDF AI Chat] Loading chat history with", chatHistory.length, "messages");
      chatAgent.setHistory(chatHistory);
    }
    console.log("[PDF AI Chat] Sending message to LLM...");
    const startTime = Date.now();
    const response = await chatAgent.chatSync(userMessage, false);
    const duration = Date.now() - startTime;
    console.log("[PDF AI Chat] Received response from LLM:", {
      responseLength: response.length,
      duration: `${duration}ms`,
      preview: response.substring(0, 100) + "..."
    });
    sendResponse({
      success: true,
      response
    });
    console.log("[PDF AI Chat] Request completed successfully");
  } catch (error) {
    console.error("[PDF AI Chat] Error occurred:", error);
    console.error("[PDF AI Chat] Error stack:", error instanceof Error ? error.stack : "No stack trace");
    const errorMessage = handleError(error, "processing PDF AI chat");
    logWithTimestamp(`Error processing PDF AI chat: ${errorMessage}`, "error");
    console.log("[PDF AI Chat] Sending error response:", errorMessage);
    sendResponse({ success: false, error: errorMessage });
  }
}
function setupMessageListeners() {
  chrome.runtime.onMessage.addListener(handleMessage);
}
export {
  handleMessage,
  setupMessageListeners,
  translateSelectionForTab
};
//# sourceMappingURL=messageHandler-kXoTEvuu.js.map
