var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var src = {};
var Client = {};
var logging = {};
var utils = {};
var hasRequiredUtils;
function requireUtils() {
  if (hasRequiredUtils) return utils;
  hasRequiredUtils = 1;
  Object.defineProperty(utils, "__esModule", { value: true });
  utils.isObject = utils.pick = utils.assertNever = void 0;
  function assertNever(value) {
    throw new Error(`Unexpected value should never occur: ${value}`);
  }
  utils.assertNever = assertNever;
  function pick(base, keys) {
    const entries = keys.map((key) => [key, base === null || base === void 0 ? void 0 : base[key]]);
    return Object.fromEntries(entries);
  }
  utils.pick = pick;
  function isObject(o) {
    return typeof o === "object" && o !== null;
  }
  utils.isObject = isObject;
  return utils;
}
var hasRequiredLogging;
function requireLogging() {
  if (hasRequiredLogging) return logging;
  hasRequiredLogging = 1;
  (function(exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.logLevelSeverity = exports.makeConsoleLogger = exports.LogLevel = void 0;
    const utils_1 = requireUtils();
    var LogLevel;
    (function(LogLevel2) {
      LogLevel2["DEBUG"] = "debug";
      LogLevel2["INFO"] = "info";
      LogLevel2["WARN"] = "warn";
      LogLevel2["ERROR"] = "error";
    })(LogLevel = exports.LogLevel || (exports.LogLevel = {}));
    function makeConsoleLogger(name2) {
      return (level, message, extraInfo) => {
        console[level](`${name2} ${level}:`, message, extraInfo);
      };
    }
    exports.makeConsoleLogger = makeConsoleLogger;
    function logLevelSeverity(level) {
      switch (level) {
        case LogLevel.DEBUG:
          return 20;
        case LogLevel.INFO:
          return 40;
        case LogLevel.WARN:
          return 60;
        case LogLevel.ERROR:
          return 80;
        default:
          return (0, utils_1.assertNever)(level);
      }
    }
    exports.logLevelSeverity = logLevelSeverity;
  })(logging);
  return logging;
}
var errors = {};
var hasRequiredErrors;
function requireErrors() {
  if (hasRequiredErrors) return errors;
  hasRequiredErrors = 1;
  (function(exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.buildRequestError = exports.APIResponseError = exports.UnknownHTTPResponseError = exports.isHTTPResponseError = exports.RequestTimeoutError = exports.isNotionClientError = exports.ClientErrorCode = exports.APIErrorCode = void 0;
    const utils_1 = requireUtils();
    var APIErrorCode;
    (function(APIErrorCode2) {
      APIErrorCode2["Unauthorized"] = "unauthorized";
      APIErrorCode2["RestrictedResource"] = "restricted_resource";
      APIErrorCode2["ObjectNotFound"] = "object_not_found";
      APIErrorCode2["RateLimited"] = "rate_limited";
      APIErrorCode2["InvalidJSON"] = "invalid_json";
      APIErrorCode2["InvalidRequestURL"] = "invalid_request_url";
      APIErrorCode2["InvalidRequest"] = "invalid_request";
      APIErrorCode2["ValidationError"] = "validation_error";
      APIErrorCode2["ConflictError"] = "conflict_error";
      APIErrorCode2["InternalServerError"] = "internal_server_error";
      APIErrorCode2["ServiceUnavailable"] = "service_unavailable";
    })(APIErrorCode = exports.APIErrorCode || (exports.APIErrorCode = {}));
    var ClientErrorCode;
    (function(ClientErrorCode2) {
      ClientErrorCode2["RequestTimeout"] = "notionhq_client_request_timeout";
      ClientErrorCode2["ResponseError"] = "notionhq_client_response_error";
    })(ClientErrorCode = exports.ClientErrorCode || (exports.ClientErrorCode = {}));
    class NotionClientErrorBase extends Error {
    }
    function isNotionClientError(error) {
      return (0, utils_1.isObject)(error) && error instanceof NotionClientErrorBase;
    }
    exports.isNotionClientError = isNotionClientError;
    function isNotionClientErrorWithCode(error, codes) {
      return isNotionClientError(error) && error.code in codes;
    }
    class RequestTimeoutError extends NotionClientErrorBase {
      constructor(message = "Request to Notion API has timed out") {
        super(message);
        this.code = ClientErrorCode.RequestTimeout;
        this.name = "RequestTimeoutError";
      }
      static isRequestTimeoutError(error) {
        return isNotionClientErrorWithCode(error, {
          [ClientErrorCode.RequestTimeout]: true
        });
      }
      static rejectAfterTimeout(promise, timeoutMS) {
        return new Promise((resolve, reject) => {
          const timeoutId = setTimeout(() => {
            reject(new RequestTimeoutError());
          }, timeoutMS);
          promise.then(resolve).catch(reject).then(() => clearTimeout(timeoutId));
        });
      }
    }
    exports.RequestTimeoutError = RequestTimeoutError;
    class HTTPResponseError extends NotionClientErrorBase {
      constructor(args) {
        super(args.message);
        this.name = "HTTPResponseError";
        const { code, status, headers, rawBodyText } = args;
        this.code = code;
        this.status = status;
        this.headers = headers;
        this.body = rawBodyText;
      }
    }
    const httpResponseErrorCodes = {
      [ClientErrorCode.ResponseError]: true,
      [APIErrorCode.Unauthorized]: true,
      [APIErrorCode.RestrictedResource]: true,
      [APIErrorCode.ObjectNotFound]: true,
      [APIErrorCode.RateLimited]: true,
      [APIErrorCode.InvalidJSON]: true,
      [APIErrorCode.InvalidRequestURL]: true,
      [APIErrorCode.InvalidRequest]: true,
      [APIErrorCode.ValidationError]: true,
      [APIErrorCode.ConflictError]: true,
      [APIErrorCode.InternalServerError]: true,
      [APIErrorCode.ServiceUnavailable]: true
    };
    function isHTTPResponseError(error) {
      if (!isNotionClientErrorWithCode(error, httpResponseErrorCodes)) {
        return false;
      }
      return true;
    }
    exports.isHTTPResponseError = isHTTPResponseError;
    class UnknownHTTPResponseError extends HTTPResponseError {
      constructor(args) {
        var _a;
        super({
          ...args,
          code: ClientErrorCode.ResponseError,
          message: (_a = args.message) !== null && _a !== void 0 ? _a : `Request to Notion API failed with status: ${args.status}`
        });
        this.name = "UnknownHTTPResponseError";
      }
      static isUnknownHTTPResponseError(error) {
        return isNotionClientErrorWithCode(error, {
          [ClientErrorCode.ResponseError]: true
        });
      }
    }
    exports.UnknownHTTPResponseError = UnknownHTTPResponseError;
    const apiErrorCodes = {
      [APIErrorCode.Unauthorized]: true,
      [APIErrorCode.RestrictedResource]: true,
      [APIErrorCode.ObjectNotFound]: true,
      [APIErrorCode.RateLimited]: true,
      [APIErrorCode.InvalidJSON]: true,
      [APIErrorCode.InvalidRequestURL]: true,
      [APIErrorCode.InvalidRequest]: true,
      [APIErrorCode.ValidationError]: true,
      [APIErrorCode.ConflictError]: true,
      [APIErrorCode.InternalServerError]: true,
      [APIErrorCode.ServiceUnavailable]: true
    };
    class APIResponseError extends HTTPResponseError {
      constructor() {
        super(...arguments);
        this.name = "APIResponseError";
      }
      static isAPIResponseError(error) {
        return isNotionClientErrorWithCode(error, apiErrorCodes);
      }
    }
    exports.APIResponseError = APIResponseError;
    function buildRequestError(response, bodyText) {
      const apiErrorResponseBody = parseAPIErrorResponseBody(bodyText);
      if (apiErrorResponseBody !== void 0) {
        return new APIResponseError({
          code: apiErrorResponseBody.code,
          message: apiErrorResponseBody.message,
          headers: response.headers,
          status: response.status,
          rawBodyText: bodyText
        });
      }
      return new UnknownHTTPResponseError({
        message: void 0,
        headers: response.headers,
        status: response.status,
        rawBodyText: bodyText
      });
    }
    exports.buildRequestError = buildRequestError;
    function parseAPIErrorResponseBody(body) {
      if (typeof body !== "string") {
        return;
      }
      let parsed;
      try {
        parsed = JSON.parse(body);
      } catch (parseError) {
        return;
      }
      if (!(0, utils_1.isObject)(parsed) || typeof parsed["message"] !== "string" || !isAPIErrorCode(parsed["code"])) {
        return;
      }
      return {
        ...parsed,
        code: parsed["code"],
        message: parsed["message"]
      };
    }
    function isAPIErrorCode(code) {
      return typeof code === "string" && code in apiErrorCodes;
    }
  })(errors);
  return errors;
}
var apiEndpoints = {};
var hasRequiredApiEndpoints;
function requireApiEndpoints() {
  if (hasRequiredApiEndpoints) return apiEndpoints;
  hasRequiredApiEndpoints = 1;
  Object.defineProperty(apiEndpoints, "__esModule", { value: true });
  apiEndpoints.oauthIntrospect = apiEndpoints.oauthRevoke = apiEndpoints.oauthToken = apiEndpoints.getFileUpload = apiEndpoints.completeFileUpload = apiEndpoints.sendFileUpload = apiEndpoints.listFileUploads = apiEndpoints.createFileUpload = apiEndpoints.listComments = apiEndpoints.createComment = apiEndpoints.search = apiEndpoints.createDatabase = apiEndpoints.listDatabases = apiEndpoints.queryDatabase = apiEndpoints.updateDatabase = apiEndpoints.getDatabase = apiEndpoints.appendBlockChildren = apiEndpoints.listBlockChildren = apiEndpoints.deleteBlock = apiEndpoints.updateBlock = apiEndpoints.getBlock = apiEndpoints.getPageProperty = apiEndpoints.updatePage = apiEndpoints.getPage = apiEndpoints.createPage = apiEndpoints.listUsers = apiEndpoints.getUser = apiEndpoints.getSelf = void 0;
  apiEndpoints.getSelf = {
    method: "get",
    pathParams: [],
    queryParams: [],
    bodyParams: [],
    path: () => `users/me`
  };
  apiEndpoints.getUser = {
    method: "get",
    pathParams: ["user_id"],
    queryParams: [],
    bodyParams: [],
    path: (p) => `users/${p.user_id}`
  };
  apiEndpoints.listUsers = {
    method: "get",
    pathParams: [],
    queryParams: ["start_cursor", "page_size"],
    bodyParams: [],
    path: () => `users`
  };
  apiEndpoints.createPage = {
    method: "post",
    pathParams: [],
    queryParams: [],
    bodyParams: ["parent", "properties", "icon", "cover", "content", "children"],
    path: () => `pages`
  };
  apiEndpoints.getPage = {
    method: "get",
    pathParams: ["page_id"],
    queryParams: ["filter_properties"],
    bodyParams: [],
    path: (p) => `pages/${p.page_id}`
  };
  apiEndpoints.updatePage = {
    method: "patch",
    pathParams: ["page_id"],
    queryParams: [],
    bodyParams: ["properties", "icon", "cover", "archived", "in_trash"],
    path: (p) => `pages/${p.page_id}`
  };
  apiEndpoints.getPageProperty = {
    method: "get",
    pathParams: ["page_id", "property_id"],
    queryParams: ["start_cursor", "page_size"],
    bodyParams: [],
    path: (p) => `pages/${p.page_id}/properties/${p.property_id}`
  };
  apiEndpoints.getBlock = {
    method: "get",
    pathParams: ["block_id"],
    queryParams: [],
    bodyParams: [],
    path: (p) => `blocks/${p.block_id}`
  };
  apiEndpoints.updateBlock = {
    method: "patch",
    pathParams: ["block_id"],
    queryParams: [],
    bodyParams: [
      "embed",
      "type",
      "archived",
      "in_trash",
      "bookmark",
      "image",
      "video",
      "pdf",
      "file",
      "audio",
      "code",
      "equation",
      "divider",
      "breadcrumb",
      "table_of_contents",
      "link_to_page",
      "table_row",
      "heading_1",
      "heading_2",
      "heading_3",
      "paragraph",
      "bulleted_list_item",
      "numbered_list_item",
      "quote",
      "to_do",
      "toggle",
      "template",
      "callout",
      "synced_block",
      "table",
      "column"
    ],
    path: (p) => `blocks/${p.block_id}`
  };
  apiEndpoints.deleteBlock = {
    method: "delete",
    pathParams: ["block_id"],
    queryParams: [],
    bodyParams: [],
    path: (p) => `blocks/${p.block_id}`
  };
  apiEndpoints.listBlockChildren = {
    method: "get",
    pathParams: ["block_id"],
    queryParams: ["start_cursor", "page_size"],
    bodyParams: [],
    path: (p) => `blocks/${p.block_id}/children`
  };
  apiEndpoints.appendBlockChildren = {
    method: "patch",
    pathParams: ["block_id"],
    queryParams: [],
    bodyParams: ["children", "after"],
    path: (p) => `blocks/${p.block_id}/children`
  };
  apiEndpoints.getDatabase = {
    method: "get",
    pathParams: ["database_id"],
    queryParams: [],
    bodyParams: [],
    path: (p) => `databases/${p.database_id}`
  };
  apiEndpoints.updateDatabase = {
    method: "patch",
    pathParams: ["database_id"],
    queryParams: [],
    bodyParams: [
      "title",
      "description",
      "icon",
      "cover",
      "properties",
      "is_inline",
      "archived",
      "in_trash"
    ],
    path: (p) => `databases/${p.database_id}`
  };
  apiEndpoints.queryDatabase = {
    method: "post",
    pathParams: ["database_id"],
    queryParams: ["filter_properties"],
    bodyParams: [
      "sorts",
      "filter",
      "start_cursor",
      "page_size",
      "archived",
      "in_trash"
    ],
    path: (p) => `databases/${p.database_id}/query`
  };
  apiEndpoints.listDatabases = {
    method: "get",
    pathParams: [],
    queryParams: ["start_cursor", "page_size"],
    bodyParams: [],
    path: () => `databases`
  };
  apiEndpoints.createDatabase = {
    method: "post",
    pathParams: [],
    queryParams: [],
    bodyParams: [
      "parent",
      "properties",
      "icon",
      "cover",
      "title",
      "description",
      "is_inline"
    ],
    path: () => `databases`
  };
  apiEndpoints.search = {
    method: "post",
    pathParams: [],
    queryParams: [],
    bodyParams: ["sort", "query", "start_cursor", "page_size", "filter"],
    path: () => `search`
  };
  apiEndpoints.createComment = {
    method: "post",
    pathParams: [],
    queryParams: [],
    bodyParams: ["parent", "rich_text", "discussion_id"],
    path: () => `comments`
  };
  apiEndpoints.listComments = {
    method: "get",
    pathParams: [],
    queryParams: ["block_id", "start_cursor", "page_size"],
    bodyParams: [],
    path: () => `comments`
  };
  apiEndpoints.createFileUpload = {
    method: "post",
    pathParams: [],
    queryParams: [],
    bodyParams: [
      "mode",
      "filename",
      "content_type",
      "number_of_parts",
      "external_url"
    ],
    path: () => `file_uploads`
  };
  apiEndpoints.listFileUploads = {
    method: "get",
    pathParams: [],
    queryParams: ["status", "start_cursor", "page_size"],
    bodyParams: [],
    path: () => `file_uploads`
  };
  apiEndpoints.sendFileUpload = {
    method: "post",
    pathParams: ["file_upload_id"],
    queryParams: [],
    bodyParams: [],
    formDataParams: ["file", "part_number"],
    path: (p) => `file_uploads/${p.file_upload_id}/send`
  };
  apiEndpoints.completeFileUpload = {
    method: "post",
    pathParams: ["file_upload_id"],
    queryParams: [],
    bodyParams: [],
    path: (p) => `file_uploads/${p.file_upload_id}/complete`
  };
  apiEndpoints.getFileUpload = {
    method: "get",
    pathParams: ["file_upload_id"],
    queryParams: [],
    bodyParams: [],
    path: (p) => `file_uploads/${p.file_upload_id}`
  };
  apiEndpoints.oauthToken = {
    method: "post",
    pathParams: [],
    queryParams: [],
    bodyParams: ["grant_type", "code", "redirect_uri", "external_account"],
    path: () => `oauth/token`
  };
  apiEndpoints.oauthRevoke = {
    method: "post",
    pathParams: [],
    queryParams: [],
    bodyParams: ["token"],
    path: () => `oauth/revoke`
  };
  apiEndpoints.oauthIntrospect = {
    method: "post",
    pathParams: [],
    queryParams: [],
    bodyParams: ["token"],
    path: () => `oauth/introspect`
  };
  return apiEndpoints;
}
const name = "@notionhq/client";
const version = "3.1.3";
const require$$4 = {
  name,
  version
};
var hasRequiredClient;
function requireClient() {
  if (hasRequiredClient) return Client;
  hasRequiredClient = 1;
  var __classPrivateFieldSet = Client && Client.__classPrivateFieldSet || function(receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
  };
  var __classPrivateFieldGet = Client && Client.__classPrivateFieldGet || function(receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
  };
  var _Client_auth, _Client_logLevel, _Client_logger, _Client_prefixUrl, _Client_timeoutMs, _Client_notionVersion, _Client_fetch, _Client_agent, _Client_userAgent;
  Object.defineProperty(Client, "__esModule", { value: true });
  const logging_1 = requireLogging();
  const errors_1 = requireErrors();
  const utils_1 = requireUtils();
  const api_endpoints_1 = requireApiEndpoints();
  const package_json_1 = require$$4;
  let Client$1 = class Client2 {
    constructor(options) {
      var _a, _b, _c, _d, _e, _f;
      _Client_auth.set(this, void 0);
      _Client_logLevel.set(this, void 0);
      _Client_logger.set(this, void 0);
      _Client_prefixUrl.set(this, void 0);
      _Client_timeoutMs.set(this, void 0);
      _Client_notionVersion.set(this, void 0);
      _Client_fetch.set(this, void 0);
      _Client_agent.set(this, void 0);
      _Client_userAgent.set(this, void 0);
      this.blocks = {
        /**
         * Retrieve block
         */
        retrieve: (args) => {
          return this.request({
            path: api_endpoints_1.getBlock.path(args),
            method: api_endpoints_1.getBlock.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.getBlock.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.getBlock.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * Update block
         */
        update: (args) => {
          return this.request({
            path: api_endpoints_1.updateBlock.path(args),
            method: api_endpoints_1.updateBlock.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.updateBlock.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.updateBlock.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * Delete block
         */
        delete: (args) => {
          return this.request({
            path: api_endpoints_1.deleteBlock.path(args),
            method: api_endpoints_1.deleteBlock.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.deleteBlock.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.deleteBlock.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        children: {
          /**
           * Append block children
           */
          append: (args) => {
            return this.request({
              path: api_endpoints_1.appendBlockChildren.path(args),
              method: api_endpoints_1.appendBlockChildren.method,
              query: (0, utils_1.pick)(args, api_endpoints_1.appendBlockChildren.queryParams),
              body: (0, utils_1.pick)(args, api_endpoints_1.appendBlockChildren.bodyParams),
              auth: args === null || args === void 0 ? void 0 : args.auth
            });
          },
          /**
           * Retrieve block children
           */
          list: (args) => {
            return this.request({
              path: api_endpoints_1.listBlockChildren.path(args),
              method: api_endpoints_1.listBlockChildren.method,
              query: (0, utils_1.pick)(args, api_endpoints_1.listBlockChildren.queryParams),
              body: (0, utils_1.pick)(args, api_endpoints_1.listBlockChildren.bodyParams),
              auth: args === null || args === void 0 ? void 0 : args.auth
            });
          }
        }
      };
      this.databases = {
        /**
         * List databases
         *
         * @deprecated Please use `search`
         */
        list: (args) => {
          return this.request({
            path: api_endpoints_1.listDatabases.path(),
            method: api_endpoints_1.listDatabases.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.listDatabases.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.listDatabases.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * Retrieve a database
         */
        retrieve: (args) => {
          return this.request({
            path: api_endpoints_1.getDatabase.path(args),
            method: api_endpoints_1.getDatabase.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.getDatabase.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.getDatabase.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * Query a database
         */
        query: (args) => {
          return this.request({
            path: api_endpoints_1.queryDatabase.path(args),
            method: api_endpoints_1.queryDatabase.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.queryDatabase.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.queryDatabase.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * Create a database
         */
        create: (args) => {
          return this.request({
            path: api_endpoints_1.createDatabase.path(),
            method: api_endpoints_1.createDatabase.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.createDatabase.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.createDatabase.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * Update a database
         */
        update: (args) => {
          return this.request({
            path: api_endpoints_1.updateDatabase.path(args),
            method: api_endpoints_1.updateDatabase.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.updateDatabase.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.updateDatabase.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        }
      };
      this.pages = {
        /**
         * Create a page
         */
        create: (args) => {
          return this.request({
            path: api_endpoints_1.createPage.path(),
            method: api_endpoints_1.createPage.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.createPage.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.createPage.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * Retrieve a page
         */
        retrieve: (args) => {
          return this.request({
            path: api_endpoints_1.getPage.path(args),
            method: api_endpoints_1.getPage.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.getPage.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.getPage.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * Update page properties
         */
        update: (args) => {
          return this.request({
            path: api_endpoints_1.updatePage.path(args),
            method: api_endpoints_1.updatePage.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.updatePage.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.updatePage.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        properties: {
          /**
           * Retrieve page property
           */
          retrieve: (args) => {
            return this.request({
              path: api_endpoints_1.getPageProperty.path(args),
              method: api_endpoints_1.getPageProperty.method,
              query: (0, utils_1.pick)(args, api_endpoints_1.getPageProperty.queryParams),
              body: (0, utils_1.pick)(args, api_endpoints_1.getPageProperty.bodyParams),
              auth: args === null || args === void 0 ? void 0 : args.auth
            });
          }
        }
      };
      this.users = {
        /**
         * Retrieve a user
         */
        retrieve: (args) => {
          return this.request({
            path: api_endpoints_1.getUser.path(args),
            method: api_endpoints_1.getUser.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.getUser.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.getUser.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * List all users
         */
        list: (args) => {
          return this.request({
            path: api_endpoints_1.listUsers.path(),
            method: api_endpoints_1.listUsers.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.listUsers.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.listUsers.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * Get details about bot
         */
        me: (args) => {
          return this.request({
            path: api_endpoints_1.getSelf.path(),
            method: api_endpoints_1.getSelf.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.getSelf.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.getSelf.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        }
      };
      this.comments = {
        /**
         * Create a comment
         */
        create: (args) => {
          return this.request({
            path: api_endpoints_1.createComment.path(),
            method: api_endpoints_1.createComment.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.createComment.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.createComment.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * List comments
         */
        list: (args) => {
          return this.request({
            path: api_endpoints_1.listComments.path(),
            method: api_endpoints_1.listComments.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.listComments.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.listComments.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        }
      };
      this.fileUploads = {
        /**
         * Create a file upload
         */
        create: (args) => {
          return this.request({
            path: api_endpoints_1.createFileUpload.path(),
            method: api_endpoints_1.createFileUpload.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.createFileUpload.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.createFileUpload.bodyParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * Retrieve a file upload
         */
        retrieve: (args) => {
          return this.request({
            path: api_endpoints_1.getFileUpload.path(args),
            method: api_endpoints_1.getFileUpload.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.getFileUpload.queryParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * List file uploads
         */
        list: (args) => {
          return this.request({
            path: api_endpoints_1.listFileUploads.path(),
            method: api_endpoints_1.listFileUploads.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.listFileUploads.queryParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * Send a file upload
         *
         * Requires a `file_upload_id`, obtained from the `id` of the Create File
         * Upload API response.
         *
         * The `file` parameter contains the raw file contents or Blob/File object
         * under `file.data`, and an optional `file.filename` string.
         *
         * Supply a stringified `part_number` parameter when using file uploads
         * in multi-part mode.
         *
         * This endpoint sends HTTP multipart/form-data instead of JSON parameters.
         */
        send: (args) => {
          return this.request({
            path: api_endpoints_1.sendFileUpload.path(args),
            method: api_endpoints_1.sendFileUpload.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.sendFileUpload.queryParams),
            formDataParams: (0, utils_1.pick)(args, api_endpoints_1.sendFileUpload.formDataParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        },
        /**
         * Complete a file upload
         */
        complete: (args) => {
          return this.request({
            path: api_endpoints_1.completeFileUpload.path(args),
            method: api_endpoints_1.completeFileUpload.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.completeFileUpload.queryParams),
            auth: args === null || args === void 0 ? void 0 : args.auth
          });
        }
      };
      this.search = (args) => {
        return this.request({
          path: api_endpoints_1.search.path(),
          method: api_endpoints_1.search.method,
          query: (0, utils_1.pick)(args, api_endpoints_1.search.queryParams),
          body: (0, utils_1.pick)(args, api_endpoints_1.search.bodyParams),
          auth: args === null || args === void 0 ? void 0 : args.auth
        });
      };
      this.oauth = {
        /**
         * Get token
         */
        token: (args) => {
          return this.request({
            path: api_endpoints_1.oauthToken.path(),
            method: api_endpoints_1.oauthToken.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.oauthToken.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.oauthToken.bodyParams),
            auth: {
              client_id: args.client_id,
              client_secret: args.client_secret
            }
          });
        },
        /**
         * Introspect token
         */
        introspect: (args) => {
          return this.request({
            path: api_endpoints_1.oauthIntrospect.path(),
            method: api_endpoints_1.oauthIntrospect.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.oauthIntrospect.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.oauthIntrospect.bodyParams),
            auth: {
              client_id: args.client_id,
              client_secret: args.client_secret
            }
          });
        },
        /**
         * Revoke token
         */
        revoke: (args) => {
          return this.request({
            path: api_endpoints_1.oauthRevoke.path(),
            method: api_endpoints_1.oauthRevoke.method,
            query: (0, utils_1.pick)(args, api_endpoints_1.oauthRevoke.queryParams),
            body: (0, utils_1.pick)(args, api_endpoints_1.oauthRevoke.bodyParams),
            auth: {
              client_id: args.client_id,
              client_secret: args.client_secret
            }
          });
        }
      };
      __classPrivateFieldSet(this, _Client_auth, options === null || options === void 0 ? void 0 : options.auth, "f");
      __classPrivateFieldSet(this, _Client_logLevel, (_a = options === null || options === void 0 ? void 0 : options.logLevel) !== null && _a !== void 0 ? _a : logging_1.LogLevel.WARN, "f");
      __classPrivateFieldSet(this, _Client_logger, (_b = options === null || options === void 0 ? void 0 : options.logger) !== null && _b !== void 0 ? _b : (0, logging_1.makeConsoleLogger)(package_json_1.name), "f");
      __classPrivateFieldSet(this, _Client_prefixUrl, `${(_c = options === null || options === void 0 ? void 0 : options.baseUrl) !== null && _c !== void 0 ? _c : "https://api.notion.com"}/v1/`, "f");
      __classPrivateFieldSet(this, _Client_timeoutMs, (_d = options === null || options === void 0 ? void 0 : options.timeoutMs) !== null && _d !== void 0 ? _d : 6e4, "f");
      __classPrivateFieldSet(this, _Client_notionVersion, (_e = options === null || options === void 0 ? void 0 : options.notionVersion) !== null && _e !== void 0 ? _e : Client2.defaultNotionVersion, "f");
      __classPrivateFieldSet(this, _Client_fetch, (_f = options === null || options === void 0 ? void 0 : options.fetch) !== null && _f !== void 0 ? _f : fetch, "f");
      __classPrivateFieldSet(this, _Client_agent, options === null || options === void 0 ? void 0 : options.agent, "f");
      __classPrivateFieldSet(this, _Client_userAgent, `notionhq-client/${package_json_1.version}`, "f");
    }
    /**
     * Sends a request.
     */
    async request(args) {
      const { path, method, query, body, formDataParams, auth } = args;
      this.log(logging_1.LogLevel.INFO, "request start", { method, path });
      const bodyAsJsonString = !body || Object.entries(body).length === 0 ? void 0 : JSON.stringify(body);
      const url = new URL(`${__classPrivateFieldGet(this, _Client_prefixUrl, "f")}${path}`);
      if (query) {
        for (const [key, value] of Object.entries(query)) {
          if (value !== void 0) {
            if (Array.isArray(value)) {
              for (const val of value) {
                url.searchParams.append(key, decodeURIComponent(val));
              }
            } else {
              url.searchParams.append(key, String(value));
            }
          }
        }
      }
      let authorizationHeader;
      if (typeof auth === "object") {
        const unencodedCredential = `${auth.client_id}:${auth.client_secret}`;
        const encodedCredential = Buffer.from(unencodedCredential).toString("base64");
        authorizationHeader = { authorization: `Basic ${encodedCredential}` };
      } else {
        authorizationHeader = this.authAsHeaders(auth);
      }
      const headers = {
        ...authorizationHeader,
        "Notion-Version": __classPrivateFieldGet(this, _Client_notionVersion, "f"),
        "user-agent": __classPrivateFieldGet(this, _Client_userAgent, "f")
      };
      if (bodyAsJsonString !== void 0) {
        headers["content-type"] = "application/json";
      }
      let formData;
      if (formDataParams) {
        delete headers["content-type"];
        formData = new FormData();
        for (const [key, value] of Object.entries(formDataParams)) {
          if (typeof value === "string") {
            formData.append(key, value);
          } else if (typeof value === "object") {
            formData.append(key, typeof value.data === "object" ? value.data : new Blob([value.data]), value.filename);
          }
        }
      }
      try {
        const response = await errors_1.RequestTimeoutError.rejectAfterTimeout(__classPrivateFieldGet(this, _Client_fetch, "f").call(this, url.toString(), {
          method: method.toUpperCase(),
          headers,
          body: bodyAsJsonString !== null && bodyAsJsonString !== void 0 ? bodyAsJsonString : formData,
          agent: __classPrivateFieldGet(this, _Client_agent, "f")
        }), __classPrivateFieldGet(this, _Client_timeoutMs, "f"));
        const responseText = await response.text();
        if (!response.ok) {
          throw (0, errors_1.buildRequestError)(response, responseText);
        }
        const responseJson = JSON.parse(responseText);
        this.log(logging_1.LogLevel.INFO, "request success", { method, path });
        return responseJson;
      } catch (error) {
        if (!(0, errors_1.isNotionClientError)(error)) {
          throw error;
        }
        this.log(logging_1.LogLevel.WARN, "request fail", {
          code: error.code,
          message: error.message
        });
        if ((0, errors_1.isHTTPResponseError)(error)) {
          this.log(logging_1.LogLevel.DEBUG, "failed response body", {
            body: error.body
          });
        }
        throw error;
      }
    }
    /**
     * Emits a log message to the console.
     *
     * @param level The level for this message
     * @param args Arguments to send to the console
     */
    log(level, message, extraInfo) {
      if ((0, logging_1.logLevelSeverity)(level) >= (0, logging_1.logLevelSeverity)(__classPrivateFieldGet(this, _Client_logLevel, "f"))) {
        __classPrivateFieldGet(this, _Client_logger, "f").call(this, level, message, extraInfo);
      }
    }
    /**
     * Transforms an API key or access token into a headers object suitable for an HTTP request.
     *
     * This method uses the instance's value as the default when the input is undefined. If neither are defined, it returns
     * an empty object
     *
     * @param auth API key or access token
     * @returns headers key-value object
     */
    authAsHeaders(auth) {
      const headers = {};
      const authHeaderValue = auth !== null && auth !== void 0 ? auth : __classPrivateFieldGet(this, _Client_auth, "f");
      if (authHeaderValue !== void 0) {
        headers["authorization"] = `Bearer ${authHeaderValue}`;
      }
      return headers;
    }
  };
  Client.default = Client$1;
  _Client_auth = /* @__PURE__ */ new WeakMap(), _Client_logLevel = /* @__PURE__ */ new WeakMap(), _Client_logger = /* @__PURE__ */ new WeakMap(), _Client_prefixUrl = /* @__PURE__ */ new WeakMap(), _Client_timeoutMs = /* @__PURE__ */ new WeakMap(), _Client_notionVersion = /* @__PURE__ */ new WeakMap(), _Client_fetch = /* @__PURE__ */ new WeakMap(), _Client_agent = /* @__PURE__ */ new WeakMap(), _Client_userAgent = /* @__PURE__ */ new WeakMap();
  Client$1.defaultNotionVersion = "2022-06-28";
  return Client;
}
var helpers = {};
var hasRequiredHelpers;
function requireHelpers() {
  if (hasRequiredHelpers) return helpers;
  hasRequiredHelpers = 1;
  Object.defineProperty(helpers, "__esModule", { value: true });
  helpers.isMentionRichTextItemResponse = helpers.isEquationRichTextItemResponse = helpers.isTextRichTextItemResponse = helpers.isFullComment = helpers.isFullUser = helpers.isFullPageOrDatabase = helpers.isFullDatabase = helpers.isFullPage = helpers.isFullBlock = helpers.collectPaginatedAPI = helpers.iteratePaginatedAPI = void 0;
  async function* iteratePaginatedAPI(listFn, firstPageArgs) {
    let nextCursor = firstPageArgs.start_cursor;
    do {
      const response = await listFn({
        ...firstPageArgs,
        start_cursor: nextCursor
      });
      yield* response.results;
      nextCursor = response.next_cursor;
    } while (nextCursor);
  }
  helpers.iteratePaginatedAPI = iteratePaginatedAPI;
  async function collectPaginatedAPI(listFn, firstPageArgs) {
    const results = [];
    for await (const item of iteratePaginatedAPI(listFn, firstPageArgs)) {
      results.push(item);
    }
    return results;
  }
  helpers.collectPaginatedAPI = collectPaginatedAPI;
  function isFullBlock(response) {
    return response.object === "block" && "type" in response;
  }
  helpers.isFullBlock = isFullBlock;
  function isFullPage(response) {
    return response.object === "page" && "url" in response;
  }
  helpers.isFullPage = isFullPage;
  function isFullDatabase(response) {
    return response.object === "database" && "title" in response;
  }
  helpers.isFullDatabase = isFullDatabase;
  function isFullPageOrDatabase(response) {
    if (response.object === "database") {
      return isFullDatabase(response);
    } else {
      return isFullPage(response);
    }
  }
  helpers.isFullPageOrDatabase = isFullPageOrDatabase;
  function isFullUser(response) {
    return "type" in response;
  }
  helpers.isFullUser = isFullUser;
  function isFullComment(response) {
    return "created_by" in response;
  }
  helpers.isFullComment = isFullComment;
  function isTextRichTextItemResponse(richText) {
    return richText.type === "text";
  }
  helpers.isTextRichTextItemResponse = isTextRichTextItemResponse;
  function isEquationRichTextItemResponse(richText) {
    return richText.type === "equation";
  }
  helpers.isEquationRichTextItemResponse = isEquationRichTextItemResponse;
  function isMentionRichTextItemResponse(richText) {
    return richText.type === "mention";
  }
  helpers.isMentionRichTextItemResponse = isMentionRichTextItemResponse;
  return helpers;
}
var hasRequiredSrc;
function requireSrc() {
  if (hasRequiredSrc) return src;
  hasRequiredSrc = 1;
  (function(exports) {
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.isFullPageOrDatabase = exports.isFullComment = exports.isFullUser = exports.isFullPage = exports.isFullDatabase = exports.isFullBlock = exports.iteratePaginatedAPI = exports.collectPaginatedAPI = exports.isNotionClientError = exports.RequestTimeoutError = exports.UnknownHTTPResponseError = exports.APIResponseError = exports.ClientErrorCode = exports.APIErrorCode = exports.LogLevel = exports.Client = void 0;
    var Client_1 = requireClient();
    Object.defineProperty(exports, "Client", { enumerable: true, get: function() {
      return Client_1.default;
    } });
    var logging_1 = requireLogging();
    Object.defineProperty(exports, "LogLevel", { enumerable: true, get: function() {
      return logging_1.LogLevel;
    } });
    var errors_1 = requireErrors();
    Object.defineProperty(exports, "APIErrorCode", { enumerable: true, get: function() {
      return errors_1.APIErrorCode;
    } });
    Object.defineProperty(exports, "ClientErrorCode", { enumerable: true, get: function() {
      return errors_1.ClientErrorCode;
    } });
    Object.defineProperty(exports, "APIResponseError", { enumerable: true, get: function() {
      return errors_1.APIResponseError;
    } });
    Object.defineProperty(exports, "UnknownHTTPResponseError", { enumerable: true, get: function() {
      return errors_1.UnknownHTTPResponseError;
    } });
    Object.defineProperty(exports, "RequestTimeoutError", { enumerable: true, get: function() {
      return errors_1.RequestTimeoutError;
    } });
    Object.defineProperty(exports, "isNotionClientError", { enumerable: true, get: function() {
      return errors_1.isNotionClientError;
    } });
    var helpers_1 = requireHelpers();
    Object.defineProperty(exports, "collectPaginatedAPI", { enumerable: true, get: function() {
      return helpers_1.collectPaginatedAPI;
    } });
    Object.defineProperty(exports, "iteratePaginatedAPI", { enumerable: true, get: function() {
      return helpers_1.iteratePaginatedAPI;
    } });
    Object.defineProperty(exports, "isFullBlock", { enumerable: true, get: function() {
      return helpers_1.isFullBlock;
    } });
    Object.defineProperty(exports, "isFullDatabase", { enumerable: true, get: function() {
      return helpers_1.isFullDatabase;
    } });
    Object.defineProperty(exports, "isFullPage", { enumerable: true, get: function() {
      return helpers_1.isFullPage;
    } });
    Object.defineProperty(exports, "isFullUser", { enumerable: true, get: function() {
      return helpers_1.isFullUser;
    } });
    Object.defineProperty(exports, "isFullComment", { enumerable: true, get: function() {
      return helpers_1.isFullComment;
    } });
    Object.defineProperty(exports, "isFullPageOrDatabase", { enumerable: true, get: function() {
      return helpers_1.isFullPageOrDatabase;
    } });
  })(src);
  return src;
}
var srcExports = requireSrc();
function createBoundFetch() {
  if (typeof window !== "undefined" && window.fetch) {
    return window.fetch.bind(window);
  } else if (typeof globalThis !== "undefined" && globalThis.fetch) {
    return globalThis.fetch.bind(globalThis);
  } else {
    throw new Error("No fetch implementation available. Please install node-fetch or use a modern browser.");
  }
}
class NotionSDKClient {
  constructor(options) {
    __publicField(this, "client");
    __publicField(this, "connected", false);
    const boundFetch = options.fetch || createBoundFetch();
    this.client = new srcExports.Client({
      auth: options.auth,
      notionVersion: options.notionVersion || "2022-06-28",
      fetch: boundFetch
    });
    this.connected = true;
  }
  // 健康检查 - 获取用户信息
  async testConnection() {
    try {
      const response = await this.client.users.me({});
      console.log("Connected as:", response.name || response.id);
      return true;
    } catch (error) {
      console.error("Connection test failed:", error);
      return false;
    }
  }
  // 页面相关操作
  async createPage(parameters) {
    try {
      const response = await this.client.pages.create(parameters);
      return response;
    } catch (error) {
      console.error("Failed to create page:", error);
      throw error;
    }
  }
  async getPage(pageId) {
    try {
      const response = await this.client.pages.retrieve({ page_id: pageId });
      return response;
    } catch (error) {
      console.error(`Failed to get page ${pageId}:`, error);
      throw error;
    }
  }
  async updatePage(pageId, parameters) {
    try {
      const response = await this.client.pages.update({
        page_id: pageId,
        ...parameters
      });
      return response;
    } catch (error) {
      console.error(`Failed to update page ${pageId}:`, error);
      throw error;
    }
  }
  async deletePage(pageId) {
    try {
      const response = await this.client.pages.update({
        page_id: pageId,
        archived: true
      });
      return response;
    } catch (error) {
      console.error(`Failed to delete page ${pageId}:`, error);
      throw error;
    }
  }
  // 数据库相关操作
  async createDatabase(parameters) {
    try {
      const response = await this.client.databases.create(parameters);
      return response;
    } catch (error) {
      console.error("Failed to create database:", error);
      throw error;
    }
  }
  async getDatabase(databaseId) {
    try {
      const response = await this.client.databases.retrieve({ database_id: databaseId });
      return response;
    } catch (error) {
      console.error(`Failed to get database ${databaseId}:`, error);
      throw error;
    }
  }
  async updateDatabase(databaseId, parameters) {
    try {
      const response = await this.client.databases.update({
        database_id: databaseId,
        ...parameters
      });
      return response;
    } catch (error) {
      console.error(`Failed to update database ${databaseId}:`, error);
      throw error;
    }
  }
  async queryDatabase(databaseId, parameters) {
    try {
      const response = await this.client.databases.query({
        database_id: databaseId,
        ...parameters
      });
      return response;
    } catch (error) {
      console.error(`Failed to query database ${databaseId}:`, error);
      throw error;
    }
  }
  // 查询所有数据库页面（自动分页）
  async queryDatabaseAll(databaseId, parameters) {
    const allResults = [];
    let hasMore = true;
    let nextCursor = void 0;
    try {
      while (hasMore) {
        const response = await this.client.databases.query({
          database_id: databaseId,
          start_cursor: nextCursor,
          ...parameters
        });
        allResults.push(...response.results);
        hasMore = response.has_more;
        nextCursor = response.next_cursor || void 0;
      }
      return allResults;
    } catch (error) {
      console.error(`Failed to query all pages from database ${databaseId}:`, error);
      throw error;
    }
  }
  // 搜索功能
  async search(parameters = {}) {
    try {
      const response = await this.client.search(parameters);
      return response;
    } catch (error) {
      console.error("Search failed:", error);
      throw error;
    }
  }
  // 搜索所有结果（自动分页）
  async searchAll(parameters = {}) {
    const allResults = [];
    let hasMore = true;
    let nextCursor = void 0;
    try {
      while (hasMore) {
        const response = await this.client.search({
          start_cursor: nextCursor,
          ...parameters
        });
        allResults.push(...response.results);
        hasMore = response.has_more;
        nextCursor = response.next_cursor || void 0;
      }
      return allResults;
    } catch (error) {
      console.error("Search all failed:", error);
      throw error;
    }
  }
  // 块（Block）相关操作
  async getBlocks(blockId, parameters) {
    try {
      const response = await this.client.blocks.children.list({
        block_id: blockId,
        ...parameters
      });
      return response;
    } catch (error) {
      console.error(`Failed to get blocks for ${blockId}:`, error);
      throw error;
    }
  }
  async getBlocksAll(blockId) {
    const allBlocks = [];
    let hasMore = true;
    let nextCursor = void 0;
    try {
      while (hasMore) {
        const response = await this.client.blocks.children.list({
          block_id: blockId,
          start_cursor: nextCursor
        });
        allBlocks.push(...response.results);
        hasMore = response.has_more;
        nextCursor = response.next_cursor || void 0;
      }
      return allBlocks;
    } catch (error) {
      console.error(`Failed to get all blocks for ${blockId}:`, error);
      throw error;
    }
  }
  async appendBlocks(blockId, children) {
    try {
      const response = await this.client.blocks.children.append({
        block_id: blockId,
        children
      });
      return response;
    } catch (error) {
      console.error(`Failed to append blocks to ${blockId}:`, error);
      throw error;
    }
  }
  async updateBlock(blockId, parameters) {
    try {
      const response = await this.client.blocks.update({
        block_id: blockId,
        ...parameters
      });
      return response;
    } catch (error) {
      console.error(`Failed to update block ${blockId}:`, error);
      throw error;
    }
  }
  async deleteBlock(blockId) {
    try {
      const response = await this.client.blocks.delete({
        block_id: blockId
      });
      return response;
    } catch (error) {
      console.error(`Failed to delete block ${blockId}:`, error);
      throw error;
    }
  }
  // 用户相关操作
  async getUsers() {
    try {
      const response = await this.client.users.list({});
      return response;
    } catch (error) {
      console.error("Failed to get users:", error);
      throw error;
    }
  }
  async getUser(userId) {
    try {
      const response = await this.client.users.retrieve({ user_id: userId });
      return response;
    } catch (error) {
      console.error(`Failed to get user ${userId}:`, error);
      throw error;
    }
  }
  async getCurrentUser() {
    try {
      const response = await this.client.users.me({});
      return response;
    } catch (error) {
      console.error("Failed to get current user:", error);
      throw error;
    }
  }
  // 实用工具方法
  async findDatabaseByTitle(title) {
    try {
      const response = await this.search({
        query: title,
        filter: { property: "object", value: "database" }
      });
      const database = response.results.find(
        (result) => {
          var _a, _b;
          return ((_b = (_a = result.title) == null ? void 0 : _a[0]) == null ? void 0 : _b.plain_text) === title;
        }
      );
      return database || null;
    } catch (error) {
      console.error(`Failed to find database with title "${title}":`, error);
      throw error;
    }
  }
  async findPageByTitle(title, parentId) {
    var _a, _b;
    try {
      const searchParams = {
        query: title,
        filter: { property: "object", value: "page" }
      };
      const response = await this.search(searchParams);
      let page = response.results.find((result) => {
        var _a2, _b2, _c, _d, _e, _f, _g, _h;
        const pageTitle = ((_d = (_c = (_b2 = (_a2 = result.properties) == null ? void 0 : _a2.title) == null ? void 0 : _b2.title) == null ? void 0 : _c[0]) == null ? void 0 : _d.plain_text) || ((_h = (_g = (_f = (_e = result.properties) == null ? void 0 : _e.Name) == null ? void 0 : _f.title) == null ? void 0 : _g[0]) == null ? void 0 : _h.plain_text);
        return pageTitle === title;
      });
      if (page && parentId) {
        const pageDetail = await this.getPage(page.id);
        if (((_a = pageDetail.parent) == null ? void 0 : _a.database_id) !== parentId && ((_b = pageDetail.parent) == null ? void 0 : _b.page_id) !== parentId) {
          page = null;
        }
      }
      return page || null;
    } catch (error) {
      console.error(`Failed to find page with title "${title}":`, error);
      throw error;
    }
  }
  // 便捷的页面创建方法
  async createSimplePage(title, parentId, content) {
    const pageData = {
      parent: parentId.length === 32 ? { database_id: parentId } : { page_id: parentId },
      properties: {
        title: {
          title: [{ text: { content: title } }]
        }
      }
    };
    if (content && content.length > 0) {
      pageData.children = content;
    }
    return await this.createPage(pageData);
  }
  // 健康检查和连接状态
  get isConnected() {
    return this.connected;
  }
  getClientInfo() {
    return {
      name: "notion-ts-sdk-client",
      version: "1.0.0",
      connected: this.connected,
      notionSdkVersion: "2.2.3"
      // 或实际版本号
    };
  }
}
export {
  NotionSDKClient
};
//# sourceMappingURL=notionClient-B6Inoxhc.js.map
