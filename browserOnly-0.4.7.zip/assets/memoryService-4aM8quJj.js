var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import { l as logWithTimestamp } from "./_commonjsHelpers-DP-qmQZY.js";
const defaultMemoriesData = /* @__PURE__ */ JSON.parse(`[{"domain":"google.com","taskDescription":"Perform a search on Google","toolSequence":["browser_click | textarea[name=\\"q\\"]","browser_keyboard_type | [search term]","browser_press_key | Enter","browser_wait_for_navigation | "],"createdAt":1746877036489,"id":7},{"domain":"linkedin.com","taskDescription":"Check LinkedIn notifications","toolSequence":["browser_navigate | https://www.linkedin.com/","browser_click | nav.global-nav__nav li:nth-child(5) a","browser_screenshot | "],"createdAt":1746978399259,"id":8},{"domain":"amazon.co.uk","taskDescription":"Search for products on Amazon UK","toolSequence":["browser_click | input[name=\\"field-keywords\\"]","browser_keyboard_type | [search term]","browser_press_key | Enter"],"createdAt":1747146976188,"id":9},{"domain":"amazon.co.uk","taskDescription":"Add a product to the Amazon basket","toolSequence":["browser_click | [product name or link]","browser_read_text | ","browser_click | input#add-to-cart-button"],"createdAt":1747147112199,"id":10},{"domain":"amazon.co.uk","taskDescription":"Navigate to Amazon UK shopping basket","toolSequence":["browser_click | a#nav-cart"],"createdAt":1747147372200,"id":11},{"domain":"linkedin.com","taskDescription":"Navigate to LinkedIn messages","toolSequence":["browser_click | a[href='https://www.linkedin.com/messaging/?']"],"createdAt":1747147711992,"id":13},{"domain":"linkedin.com","taskDescription":"Open a specific conversation in LinkedIn messages","toolSequence":["browser_navigate | https://www.linkedin.com/messaging/","browser_click | span.truncate:has-text(\\"[CONTACT_NAME]\\")"],"createdAt":1747147891842,"id":14},{"domain":"linkedin.com","taskDescription":"Reply to a LinkedIn message","toolSequence":["browser_click | div[role=\\"textbox\\"]","browser_keyboard_type | [message content]","browser_click | button.msg-form__send-button"],"createdAt":1747147960060,"id":15},{"domain":"linkedin.com","taskDescription":"Search for a specific contact in LinkedIn messages","toolSequence":["browser_click | input#search-conversations","browser_keyboard_type | [contact name]","browser_press_key | Enter","browser_click | span.truncate:has-text(\\"[contact name]\\")"],"createdAt":1747148187441,"id":16},{"domain":"google.com","taskDescription":"Click on a specific search result by position","toolSequence":["browser_click | h3.LC20lb:nth-of-type(n)"],"createdAt":1747148383137,"id":18},{"domain":"instagram.com","taskDescription":"List all Instagram stories at the top of the feed","toolSequence":["browser_navigate | https://www.instagram.com","browser_query | ul._acay li"],"createdAt":1747150642221,"id":19},{"domain":"instagram.com","taskDescription":"View a specific user's Instagram story","toolSequence":["browser_navigate | https://www.instagram.com","browser_query | ul._acay li","browser_click | div[aria-label=\\"Story by USERNAME, not seen\\"]"],"createdAt":1747150678129,"id":20},{"domain":"instagram.com","taskDescription":"Send an emoji reaction to someone's Instagram story","toolSequence":["browser_navigate | https://www.instagram.com","browser_click | div[aria-label=\\"Story by USERNAME, not seen\\"]","browser_click | textarea[placeholder=\\"Reply to USERNAME...\\"]","browser_keyboard_type | 😂","browser_press_key | Enter"],"createdAt":1747150845788,"id":21},{"domain":"instagram.com","taskDescription":"Navigate to Instagram direct messages/inbox","toolSequence":["browser_navigate | https://www.instagram.com","browser_query | a[href=\\"/direct/inbox/\\"]","browser_click | a[aria-label*=\\"Direct messaging\\"]"],"createdAt":1747151121948,"id":22},{"domain":"instagram.com","taskDescription":"Open a specific conversation in Instagram direct messages","toolSequence":["browser_navigate | https://www.instagram.com/direct/inbox/","browser_click | div[role=\\"button\\"] >> text=USERNAME"],"createdAt":1747151234794,"id":23},{"domain":"instagram.com","taskDescription":"Send a direct message reply on Instagram","toolSequence":["browser_navigate | https://www.instagram.com/direct/inbox/","browser_click | div[role=\\"button\\"] >> text=USERNAME","browser_click | div[contenteditable=\\"true\\"]","browser_keyboard_type | Your message here","browser_click | svg[aria-label=\\"Send\\"]"],"createdAt":1747151367662,"id":24},{"domain":"instagram.com","taskDescription":"Scroll through Instagram feed and summarize posts","toolSequence":["browser_read_text | ","browser_screenshot | full","browser_press_key | End","browser_read_text | ","browser_press_key | End","browser_read_text | "],"createdAt":1747151535427,"id":25},{"domain":"amazon.com","taskDescription":"Search for products on Amazon with specific criteria","toolSequence":["browser_navigate | https://www.amazon.com","browser_click | input[id=\\"twotabsearchtextbox\\"]","browser_keyboard_type | [search query with specific criteria]","browser_press_key | Enter","browser_read_text | ","browser_click | [product name]","browser_read_text | "],"createdAt":1747244182761,"id":26},{"domain":"youtube.com","taskDescription":"Search for content on YouTube","toolSequence":["browser_click | input[name=\\"search_query\\"]","browser_keyboard_type | [search term]","browser_press_key | Enter","browser_wait_for_navigation | "],"createdAt":1747247353373,"id":27},{"domain":"youtube.com","taskDescription":"Click on a specific video from search results","toolSequence":["browser_screenshot | full","browser_read_text | ","browser_click | [video title]","browser_wait_for_navigation | "],"createdAt":1747247353375,"id":28},{"domain":"web.whatsapp.com","taskDescription":"View and list recent chat conversations","toolSequence":["browser_read_text | "],"createdAt":1747247643609,"id":29},{"domain":"web.whatsapp.com","taskDescription":"Open a specific chat with a contact","toolSequence":["browser_click | [contact name]"],"createdAt":1747247673805,"id":30},{"domain":"web.whatsapp.com","taskDescription":"Read unread messages from a specific contact","toolSequence":["browser_click | [contact name]","browser_read_text | "],"createdAt":1747247712520,"id":31},{"domain":"web.whatsapp.com","taskDescription":"Send a message to a contact","toolSequence":["browser_click | div[aria-label=\\"Type a message\\"]","browser_keyboard_type | [message text]","browser_click | button[aria-label=\\"Send\\"]"],"createdAt":1747247751573,"id":32},{"domain":"web.whatsapp.com","taskDescription":"Search for specific text across all WhatsApp conversations","toolSequence":["browser_click | button[aria-label=\\"Search…\\"]","browser_click | div[aria-label=\\"Search input textbox\\"]","browser_keyboard_type | [search term]","browser_read_text | "],"createdAt":1747247892500,"id":33},{"domain":"linkedin.com","taskDescription":"Start a new post on LinkedIn","toolSequence":["browser_click | #ember36","browser_click | div[role='textbox']","browser_keyboard_type | [post content]"],"createdAt":1747416856460,"id":36},{"domain":"mail.google.com","taskDescription":"Open and read the first email in Gmail inbox","toolSequence":["browser_click | .zA:first-of-type","browser_read_text | "],"createdAt":1747496124865,"id":37},{"domain":"mail.google.com","taskDescription":"Open a specific email by sender name in Gmail inbox","toolSequence":["browser_click | .zA:has([email=\\"sender@domain.com\\"])","browser_read_text | "],"createdAt":1747496192997,"id":38},{"domain":"mail.google.com","taskDescription":"Search Gmail inbox for emails from a specific sender","toolSequence":["browser_click | input[aria-label=\\"Search mail\\"]","browser_type | input[aria-label=\\"Search mail\\"]|from:sender","browser_press_key | Enter"],"createdAt":1747496235578,"id":39},{"domain":"mail.google.com","taskDescription":"Compose a new email in Gmail","toolSequence":["browser_click | Compose","browser_click | [aria-label=\\"To\\"]","browser_keyboard_type | recipient@email.com","browser_click | [aria-label=\\"Subject\\"]","browser_keyboard_type | Email Subject","browser_click | div[role=\\"textbox\\"]","browser_keyboard_type | Email body content"],"createdAt":1747496427408,"id":40},{"domain":"libgen.li","taskDescription":"search books base on user request ","toolSequence":["browser_navigate | https://libgen.is/","browser_click | input[name=\\"req\\"]","browser_keyboard_type | [search term]","browser_press_key | Enter","browser_wait_for_navigation | ","browser_click | a[href=\\"]","browser_wait_for_navigation | ","browser_query | table table-striped "],"createdAt":1747496235578,"id":42},{"domain":"1lou.pro","taskDescription":"search movies seed base on user request","toolSequence":["browser_navigate | https://1lou.pro/","browser_click | input[name=\\"keyword\\"]","browser_keyboard_type | [search term]","browser_press_key | Enter","browser_wait_for_navigation | ","browser_query | ul[class=\\"list-unstyled threadlist mb-0\\"]"],"createdAt":1747496235578,"id":43},{"domain":"iyf.tv","taskDescription":"search online movies base on user request","toolSequence":["browser_navigate | https://iyf.tv/","browser_click | input[id=\\"search-input\\"]","browser_keyboard_type | [search term]","browser_press_key | Enter","browser_wait_for_navigation | ","browser_click | a[class=\\"result-nav-link\\"]","browser_wait_for_navigation | ","browser_click | a[class=\\"episode-ctn\\"]","browser_wait_for_navigation | "],"createdAt":1747496235578,"id":44},{"domain":"88zhibo.tv","taskDescription":"search sports live stream and videos base on user request","toolSequence":["browser_navigate | http://88zhibo.tv","browser_query | div[class=\\"col-md-3 pay-btn text-right\\"]"],"createdAt":1747496235578,"id":45},{"domain":"arxiv.org","taskDescription":"search paper on Arxiv.org, base on the user request ","toolSequence":["browser_navigate | https://arxiv.org/","browser_click | input[name=\\"query\\"]","browser_keyboard_type | [search term]","browser_press_key | Enter","browser_wait_for_navigation | ","browser_select | select[id=\\"order\\"]","browser_press_key | Enter","browser_wait_for_navigation | ","browser_query | ol[class=\\"breathe-horizontal\\"]"],"createdAt":1747496235578,"id":46},{"domain":"missav.ai","taskDescription":"search av stream and videos base on user request","toolSequence":["browser_navigate | https://missav.ai/","browser_click | input[x-ref=\\"homeSearch\\"]","browser_keyboard_type | [search term]","browser_press_key | Enter","browser_wait_for_navigation | ","browser_query | div[class=\\"relative aspect-w-16 aspect-h-9 rounded overflow-hidden shadow-lg\\"]"],"createdAt":1747496235578,"id":47},{"domain":"jd.com","taskDescription":"search product on jd.com ,and you also can put these products to the cart ","toolSequence":["browser_navigate | https://jd.com/","browser_click | input[aria-label=\\"搜索\\"]","browser_keyboard_type | [search term]","browser_press_key | Enter","browser_wait_for_navigation | ","browser_click | \\"京东物流\\"","browser_query | div[id=\\"J_goodsList\\"]","browser_click | a[class=\\"p-o-btn addcart\\"]"],"createdAt":1747496235578,"id":48},{"domain":"search.jd.com","taskDescription":"add product to the JD cart ","toolSequence":["browser_click | \\"京东物流\\"","browser_query | div[id=\\"J_goodsList\\"]","browser_click | a[class=\\"p-o-btn addcart\\"]"],"createdAt":1747496235578,"id":49},{"domain":"order.jd.com","taskDescription":"search products on order.jd.com ","toolSequence":["browser_navigate | https://order.jd.com/center/list.action","browser_query | div[class=\\"td-void order-tb\\"]"],"createdAt":1747496235578,"id":50},{"domain":"dianping.com","taskDescription":"Find restaurants and other entertainment options on dingping.com ","toolSequence":["browser_navigate | https://www.dianping.com/citylist","browser_wait_for_navigation | ","browser_click | [select city]","browser_wait_for_navigation | ","browser_click | input[class=\\"J-search-input\\"]","browser_keyboard_type | [search term]","browser_press_key | Enter","browser_wait_for_navigation | ","browser_query | div[class=\\"shop-list J_shop-list shop-all-list\\"]"],"createdAt":1747496235578,"id":51},{"domain":"notion.so","taskDescription":"Save the summarized information or webpage content to Notion.so base on user request. The general steps are: open Notion.so, create a new page, and input the title and main content.","toolSequence":["browser_navigate | https://notion.so","browser_click | div[aria-label=\\"New page\\"]","browser_keyboard_type | [input title]","browser_press_key | Enter","browser_keyboard_type_and_press | [input content]","browser_press_key | Enter"],"createdAt":1747496235578,"id":52}]`);
function normalizeDomain(domain) {
  if (!domain) return "";
  let normalized = domain.toLowerCase();
  if (normalized.includes("://")) {
    try {
      normalized = new URL(normalized).hostname;
    } catch (e) {
      console.error("Error parsing URL:", e);
    }
  }
  if (normalized.startsWith("www.")) {
    normalized = normalized.substring(4);
  }
  normalized = normalized.split("/")[0];
  return normalized;
}
const _MemoryService = class _MemoryService {
  constructor() {
    __publicField(this, "db", null);
    __publicField(this, "DB_NAME", "BrowserOnly-memories");
    __publicField(this, "STORE_NAME", "memories");
    __publicField(this, "DB_VERSION", 1);
    // Not readonly so we can increment it if needed
    __publicField(this, "isInitialized", false);
    __publicField(this, "hasImportedDefaultMemories", false);
  }
  // Singleton pattern
  static getInstance() {
    if (!_MemoryService.instance) {
      _MemoryService.instance = new _MemoryService();
    }
    return _MemoryService.instance;
  }
  /**
   * Check if the object store exists and create it if it doesn't
   */
  async ensureObjectStoreExists() {
    if (!this.db) {
      throw new Error("Database not initialized");
    }
    if (!Array.from(this.db.objectStoreNames).includes(this.STORE_NAME)) {
      logWithTimestamp(`Object store ${this.STORE_NAME} does not exist, recreating database`, "warn");
      this.db.close();
      this.db = null;
      this.isInitialized = false;
      return new Promise((resolve, reject) => {
        const deleteRequest = indexedDB.deleteDatabase(this.DB_NAME);
        deleteRequest.onsuccess = () => {
          logWithTimestamp(`Database ${this.DB_NAME} deleted successfully, recreating`);
          this.init().then(resolve).catch(reject);
        };
        deleteRequest.onerror = (event) => {
          const error = event.target.error;
          logWithTimestamp(`Error deleting database: ${(error == null ? void 0 : error.message) || "Unknown error"}`, "error");
          reject(error);
        };
      });
    }
    return Promise.resolve();
  }
  // Initialize the database
  async init() {
    if (this.isInitialized) {
      logWithTimestamp(`MemoryService already initialized, skipping initialization`);
      return;
    }
    logWithTimestamp(`Initializing MemoryService with database ${this.DB_NAME}`);
    if (typeof indexedDB === "undefined") {
      logWithTimestamp(`IndexedDB is not available in this environment`, "error");
      throw new Error("IndexedDB is not available in this environment");
    }
    return new Promise((resolve, reject) => {
      try {
        logWithTimestamp(`Opening IndexedDB database ${this.DB_NAME} (version ${this.DB_VERSION})`);
        const request = indexedDB.open(this.DB_NAME, this.DB_VERSION);
        request.onupgradeneeded = (event) => {
          logWithTimestamp(`Database upgrade needed for ${this.DB_NAME}`);
          const db = event.target.result;
          if (!db.objectStoreNames.contains(this.STORE_NAME)) {
            logWithTimestamp(`Creating object store ${this.STORE_NAME}`);
            const store = db.createObjectStore(this.STORE_NAME, {
              keyPath: "id",
              autoIncrement: true
            });
            store.createIndex("domain", "domain", { unique: false });
            store.createIndex("createdAt", "createdAt", { unique: false });
            logWithTimestamp(`Created ${this.STORE_NAME} object store in ${this.DB_NAME} database`);
          } else {
            logWithTimestamp(`Object store ${this.STORE_NAME} already exists`);
          }
        };
        request.onsuccess = (event) => {
          this.db = event.target.result;
          this.isInitialized = true;
          logWithTimestamp(`Successfully opened ${this.DB_NAME} database`);
          const storeNames = Array.from(this.db.objectStoreNames);
          logWithTimestamp(`Database contains object stores: ${storeNames.join(", ") || "none"}`);
          if (!storeNames.includes(this.STORE_NAME)) {
            logWithTimestamp(`Object store ${this.STORE_NAME} not found, will recreate database`, "warn");
            this.db.close();
            this.db = null;
            this.isInitialized = false;
            const deleteRequest = indexedDB.deleteDatabase(this.DB_NAME);
            deleteRequest.onsuccess = () => {
              logWithTimestamp(`Database ${this.DB_NAME} deleted successfully, recreating`);
              this.init().then(resolve).catch(reject);
            };
            deleteRequest.onerror = (event2) => {
              const error = event2.target.error;
              logWithTimestamp(`Error deleting database: ${(error == null ? void 0 : error.message) || "Unknown error"}`, "error");
              reject(error);
            };
            return;
          }
          resolve();
        };
        request.onerror = (event) => {
          const error = event.target.error;
          logWithTimestamp(`Error opening ${this.DB_NAME} database: ${(error == null ? void 0 : error.message) || "Unknown error"}`, "error");
          reject(error);
        };
        request.onblocked = () => {
          logWithTimestamp(`Database request blocked for ${this.DB_NAME}`, "warn");
        };
      } catch (error) {
        logWithTimestamp(`Exception opening ${this.DB_NAME} database: ${error instanceof Error ? error.message : String(error)}`, "error");
        reject(error);
      }
    });
  }
  // Ensure the database is initialized before any operation
  async ensureInitialized() {
    if (!this.isInitialized) {
      await this.init();
    }
    await this.ensureObjectStoreExists();
  }
  /**
   * Check if a similar memory already exists
   * @param memory The memory to check for duplicates
   * @returns The ID of the existing memory if found, null otherwise
   */
  async findSimilarMemory(memory) {
    await this.ensureInitialized();
    if (!this.db) {
      throw new Error("Database not initialized");
    }
    const normalizedDomain = normalizeDomain(memory.domain);
    return new Promise((resolve, reject) => {
      try {
        const transaction = this.db.transaction([this.STORE_NAME], "readonly");
        const store = transaction.objectStore(this.STORE_NAME);
        const index = store.index("domain");
        const request = index.getAll(normalizedDomain);
        request.onsuccess = (event) => {
          const memories = event.target.result;
          const similarMemory = memories.find(
            (m) => m.taskDescription.toLowerCase() === memory.taskDescription.toLowerCase()
          );
          if (similarMemory && similarMemory.id) {
            logWithTimestamp(`Found similar memory with ID ${similarMemory.id} for task "${memory.taskDescription}"`);
            resolve(similarMemory.id);
          } else {
            resolve(null);
          }
        };
        request.onerror = (event) => {
          const error = event.target.error;
          logWithTimestamp(`Error checking for similar memories: ${(error == null ? void 0 : error.message) || "Unknown error"}`, "error");
          reject(error);
        };
      } catch (error) {
        logWithTimestamp(`Exception checking for similar memories: ${error instanceof Error ? error.message : String(error)}`, "error");
        reject(error);
      }
    });
  }
  /**
   * Update an existing memory
   * @param id The ID of the memory to update
   * @param memory The updated memory data
   * @returns Promise resolving to the ID of the updated memory
   */
  async updateMemory(id, memory) {
    await this.ensureInitialized();
    if (!this.db) {
      throw new Error("Database not initialized");
    }
    return new Promise((resolve, reject) => {
      try {
        const transaction = this.db.transaction([this.STORE_NAME], "readwrite");
        const store = transaction.objectStore(this.STORE_NAME);
        const getRequest = store.get(id);
        getRequest.onsuccess = (event) => {
          const existingMemory = event.target.result;
          if (!existingMemory) {
            reject(new Error(`Memory with ID ${id} not found`));
            return;
          }
          const updatedMemory = {
            ...existingMemory,
            ...memory,
            // Always update the timestamp
            createdAt: Date.now()
          };
          const putRequest = store.put(updatedMemory);
          putRequest.onsuccess = () => {
            logWithTimestamp(`Successfully updated memory with ID ${id}`);
            resolve(id);
          };
          putRequest.onerror = (event2) => {
            const error = event2.target.error;
            logWithTimestamp(`Error updating memory: ${(error == null ? void 0 : error.message) || "Unknown error"}`, "error");
            reject(error);
          };
        };
        getRequest.onerror = (event) => {
          const error = event.target.error;
          logWithTimestamp(`Error getting memory for update: ${(error == null ? void 0 : error.message) || "Unknown error"}`, "error");
          reject(error);
        };
      } catch (error) {
        logWithTimestamp(`Exception updating memory: ${error instanceof Error ? error.message : String(error)}`, "error");
        reject(error);
      }
    });
  }
  // Store a new memory
  async storeMemory(memory) {
    await this.ensureInitialized();
    if (!this.db) {
      logWithTimestamp(`Cannot store memory: Database not initialized`, "error");
      throw new Error("Database not initialized");
    }
    memory.domain = normalizeDomain(memory.domain);
    const existingId = await this.findSimilarMemory(memory);
    if (existingId !== null) {
      logWithTimestamp(`Similar memory found with ID ${existingId}, updating instead of creating duplicate`);
      return this.updateMemory(existingId, memory);
    }
    logWithTimestamp(`No similar memory found, storing new memory for domain ${memory.domain}`);
    return new Promise((resolve, reject) => {
      try {
        logWithTimestamp(`Creating transaction for ${this.STORE_NAME}`);
        const transaction = this.db.transaction([this.STORE_NAME], "readwrite");
        transaction.onerror = (event) => {
          const error = event.target.error;
          logWithTimestamp(`Transaction error: ${(error == null ? void 0 : error.message) || "Unknown error"}`, "error");
        };
        transaction.onabort = () => {
          logWithTimestamp(`Transaction aborted`, "warn");
        };
        const store = transaction.objectStore(this.STORE_NAME);
        if (!memory.createdAt) {
          memory.createdAt = Date.now();
        }
        logWithTimestamp(`Adding memory to store: ${JSON.stringify(memory).substring(0, 100)}...`);
        const request = store.add(memory);
        request.onsuccess = (event) => {
          const id = event.target.result;
          logWithTimestamp(`Successfully stored memory with ID ${id} for domain ${memory.domain}`);
          resolve(id);
        };
        request.onerror = (event) => {
          const error = event.target.error;
          logWithTimestamp(`Error storing memory: ${(error == null ? void 0 : error.message) || "Unknown error"}`, "error");
          reject(error);
        };
      } catch (error) {
        logWithTimestamp(`Exception storing memory: ${error instanceof Error ? error.message : String(error)}`, "error");
        reject(error);
      }
    });
  }
  // Retrieve memories by domain
  async getMemoriesByDomain(domain) {
    await this.ensureInitialized();
    if (!this.db) {
      throw new Error("Database not initialized");
    }
    const normalizedDomain = normalizeDomain(domain);
    return new Promise((resolve, reject) => {
      try {
        const transaction = this.db.transaction([this.STORE_NAME], "readonly");
        const store = transaction.objectStore(this.STORE_NAME);
        const index = store.index("domain");
        const request = index.getAll(normalizedDomain);
        request.onsuccess = (event) => {
          const memories = event.target.result;
          logWithTimestamp(`Retrieved ${memories.length} memories for domain ${domain}`);
          resolve(memories);
        };
        request.onerror = (event) => {
          const error = event.target.error;
          logWithTimestamp(`Error retrieving memories: ${(error == null ? void 0 : error.message) || "Unknown error"}`, "error");
          reject(error);
        };
      } catch (error) {
        logWithTimestamp(`Exception retrieving memories: ${error instanceof Error ? error.message : String(error)}`, "error");
        reject(error);
      }
    });
  }
  // Get all memories
  async getAllMemories() {
    await this.ensureInitialized();
    if (!this.db) {
      throw new Error("Database not initialized");
    }
    return new Promise((resolve, reject) => {
      try {
        const transaction = this.db.transaction([this.STORE_NAME], "readonly");
        const store = transaction.objectStore(this.STORE_NAME);
        const request = store.getAll();
        request.onsuccess = (event) => {
          const memories = event.target.result;
          logWithTimestamp(`Retrieved ${memories.length} total memories`);
          resolve(memories);
        };
        request.onerror = (event) => {
          const error = event.target.error;
          logWithTimestamp(`Error retrieving all memories: ${(error == null ? void 0 : error.message) || "Unknown error"}`, "error");
          reject(error);
        };
      } catch (error) {
        logWithTimestamp(`Exception retrieving all memories: ${error instanceof Error ? error.message : String(error)}`, "error");
        reject(error);
      }
    });
  }
  // Delete a memory by ID
  async deleteMemory(id) {
    await this.ensureInitialized();
    if (!this.db) {
      throw new Error("Database not initialized");
    }
    return new Promise((resolve, reject) => {
      try {
        const transaction = this.db.transaction([this.STORE_NAME], "readwrite");
        const store = transaction.objectStore(this.STORE_NAME);
        const request = store.delete(id);
        request.onsuccess = () => {
          logWithTimestamp(`Successfully deleted memory with ID ${id}`);
          resolve();
        };
        request.onerror = (event) => {
          const error = event.target.error;
          logWithTimestamp(`Error deleting memory: ${(error == null ? void 0 : error.message) || "Unknown error"}`, "error");
          reject(error);
        };
      } catch (error) {
        logWithTimestamp(`Exception deleting memory: ${error instanceof Error ? error.message : String(error)}`, "error");
        reject(error);
      }
    });
  }
  // Clear all memories
  async clearMemories() {
    await this.ensureInitialized();
    if (!this.db) {
      throw new Error("Database not initialized");
    }
    return new Promise((resolve, reject) => {
      try {
        const transaction = this.db.transaction([this.STORE_NAME], "readwrite");
        const store = transaction.objectStore(this.STORE_NAME);
        const request = store.clear();
        request.onsuccess = () => {
          logWithTimestamp(`Successfully cleared all memories`);
          resolve();
        };
        request.onerror = (event) => {
          const error = event.target.error;
          logWithTimestamp(`Error clearing memories: ${(error == null ? void 0 : error.message) || "Unknown error"}`, "error");
          reject(error);
        };
      } catch (error) {
        logWithTimestamp(`Exception clearing memories: ${error instanceof Error ? error.message : String(error)}`, "error");
        reject(error);
      }
    });
  }
  /**
   * Import default memories from the bundled JSON file
   * This should only be called once during initial database setup
   * @returns Promise resolving to the number of imported memories
   */
  async importDefaultMemories() {
    if (this.hasImportedDefaultMemories) {
      logWithTimestamp("Default memories already imported, skipping");
      return 0;
    }
    await this.ensureInitialized();
    if (!this.db) {
      throw new Error("Database not initialized");
    }
    try {
      const existingMemories = await this.getAllMemories();
      if (existingMemories.length > 0) {
        logWithTimestamp("Database already contains memories, skipping default import");
        this.hasImportedDefaultMemories = true;
        return 0;
      }
      logWithTimestamp("Importing default memories...");
      const defaultMemories = defaultMemoriesData;
      if (!Array.isArray(defaultMemories) || defaultMemories.length === 0) {
        logWithTimestamp("No default memories found or invalid format", "warn");
        this.hasImportedDefaultMemories = true;
        return 0;
      }
      logWithTimestamp(`Found ${defaultMemories.length} default memories to import`);
      let importedCount = 0;
      for (const memory of defaultMemories) {
        try {
          delete memory.id;
          await this.storeMemory(memory);
          importedCount++;
        } catch (error) {
          logWithTimestamp(`Error importing memory: ${error instanceof Error ? error.message : String(error)}`, "warn");
        }
      }
      logWithTimestamp(`Successfully imported ${importedCount} default memories`);
      this.hasImportedDefaultMemories = true;
      return importedCount;
    } catch (error) {
      logWithTimestamp(`Error importing default memories: ${error instanceof Error ? error.message : String(error)}`, "error");
      return 0;
    }
  }
};
__publicField(_MemoryService, "instance");
let MemoryService = _MemoryService;
export {
  MemoryService as M,
  normalizeDomain as n
};
//# sourceMappingURL=memoryService-4aM8quJj.js.map
