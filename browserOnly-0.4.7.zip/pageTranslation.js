const RETRY_DELAYS_MS = [500, 1500];
function getTranslationRetryDelay(retryCount) {
  return RETRY_DELAYS_MS[retryCount];
}
function resetStateForNewTranslationSession(state) {
  return state === "queued" || state === "error" ? "idle" : state;
}
const TOOLBAR_HOST_ID = "browseronly-selection-toolbar-host";
const RESULT_HOST_ID = "browseronly-selection-result-host";
const VIEWPORT_GAP = 8;
let session = "";
let mode = "bilingual";
let targetLanguage = navigator.language || "zh-CN";
const units = /* @__PURE__ */ new Map();
let observer;
let viewportObserver;
let titleOriginal = "";
let selectionAnchor;
const PAGE_TRANSLATION_INJECTED_KEY = "__BROWSERONLY_PAGE_TRANSLATION_INJECTED__";
const shouldInitialize = !globalThis[PAGE_TRANSLATION_INJECTED_KEY];
if (shouldInitialize) globalThis[PAGE_TRANSLATION_INJECTED_KEY] = true;
const id = () => `${Date.now()}-${Math.random().toString(36).slice(2)}`;
function root() {
  for (const selector of ["main", "article", '[role="main"]', "#content", "#main", ".content", ".main-content"]) {
    const element = document.querySelector(selector);
    if (element) return element;
  }
  return document.body;
}
function collect() {
  const elements = Array.from(root().querySelectorAll("h1,h2,h3,h4,h5,h6,p,li,blockquote,td"));
  return elements.filter((element) => {
    var _a;
    if (element.closest(".browseronly-translation,[data-browseronly-skip]")) return false;
    if (!((_a = element.textContent) == null ? void 0 : _a.trim())) return false;
    if (element.closest('pre,code,script,style,textarea,input,select,button,form,[contenteditable="true"]')) return false;
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  });
}
function viewportPriority(unit) {
  const rect = unit.element.getBoundingClientRect();
  if (rect.bottom >= -600 && rect.top <= window.innerHeight + 600) return 0;
  return rect.top > window.innerHeight ? rect.top - window.innerHeight : -rect.bottom;
}
function sendUnit(unit) {
  const requestSession = session;
  const requestId = id();
  unit.state = "queued";
  chrome.runtime.sendMessage({
    action: "translationBatch",
    tabId: void 0,
    pageSessionId: requestSession,
    requestId,
    targetLanguage,
    engine: "auto",
    style: "natural",
    units: [{ sourceId: unit.sourceId, text: unit.text }]
  }).then((response) => {
    if (requestSession !== session) return;
    if (!(response == null ? void 0 : response.success)) {
      console.error("[translation][content] unit failed", { session, requestId, sourceId: unit.sourceId, error: response == null ? void 0 : response.error });
      retryUnit(unit, requestSession);
      return;
    }
  }).catch((error) => {
    if (requestSession !== session) return;
    console.error("[translation][content] unit message failed", { session, requestId, sourceId: unit.sourceId, error: String(error) });
    retryUnit(unit, requestSession);
  });
}
function retryUnit(unit, requestSession) {
  const delay = getTranslationRetryDelay(unit.retryCount);
  if (delay === void 0) {
    unit.state = "error";
    return;
  }
  unit.retryCount += 1;
  unit.retryTimer = setTimeout(() => {
    unit.retryTimer = void 0;
    if (session !== requestSession || unit.state !== "queued") return;
    sendUnit(unit);
  }, delay);
}
function sendBatch() {
  const pending = Array.from(units.values()).filter((unit) => unit.state === "idle").filter((unit) => viewportPriority(unit) === 0).sort((left, right) => viewportPriority(left) - viewportPriority(right));
  if (!pending.length) {
    console.info("[translation][content] no pending units", { session });
    return;
  }
  const requestId = id();
  console.info("[translation][content] batch sending", {
    session,
    requestId,
    units: pending.length,
    chars: pending.reduce((sum, unit) => sum + unit.text.length, 0),
    targetLanguage
  });
  pending.forEach(sendUnit);
}
function scan() {
  const elements = collect();
  console.info("[translation][content] scan completed", { session, elements: elements.length });
  for (const element of elements) {
    const source = element.textContent.trim();
    const sourceId = element.dataset.browseronlySourceId || id();
    element.dataset.browseronlySourceId = sourceId;
    if (!units.has(sourceId)) {
      const unit = {
        sourceId,
        element,
        text: source,
        state: "idle",
        retryCount: 0,
        originalDisplay: element.style.display
      };
      units.set(sourceId, unit);
      viewportObserver == null ? void 0 : viewportObserver.observe(element);
    }
  }
  sendBatch();
}
function render(results) {
  for (const result of results) {
    if (result.sourceId === "__title__" && result.translatedText) {
      document.title = mode === "translation-only" ? result.translatedText : `${titleOriginal} — ${result.translatedText}`;
      continue;
    }
    const unit = units.get(result.sourceId);
    if (!unit || !result.translatedText) continue;
    unit.translation = String(result.translatedText);
    unit.state = "translated";
    let translatedElement = unit.element.nextElementSibling;
    if (!(translatedElement == null ? void 0 : translatedElement.classList.contains("browseronly-translation"))) {
      translatedElement = document.createElement("div");
      translatedElement.className = "browseronly-translation";
      translatedElement.dataset.sourceId = unit.sourceId;
      translatedElement.style.cssText = "white-space:pre-wrap;color:inherit;opacity:.86;margin:.2em 0;";
      unit.element.insertAdjacentElement("afterend", translatedElement);
    }
    translatedElement.textContent = unit.translation;
    unit.element.style.display = mode === "translation-only" ? "none" : unit.originalDisplay;
  }
}
function restore() {
  for (const unit of units.values()) {
    unit.element.style.display = unit.originalDisplay;
    const next = unit.element.nextElementSibling;
    if (next == null ? void 0 : next.classList.contains("browseronly-translation")) next.remove();
  }
  if (titleOriginal) document.title = titleOriginal;
}
function createOverlayHost(hostId) {
  var _a;
  (_a = document.getElementById(hostId)) == null ? void 0 : _a.remove();
  const host = document.createElement("div");
  host.id = hostId;
  host.dataset.browseronlySkip = "true";
  host.style.cssText = "all:initial;position:fixed;z-index:2147483647;display:block;";
  document.documentElement.appendChild(host);
  return host;
}
function positionNearSelection(host, anchor = selectionAnchor) {
  const rect = host.getBoundingClientRect();
  const anchorLeft = (anchor == null ? void 0 : anchor.left) ?? VIEWPORT_GAP;
  const anchorBottom = (anchor == null ? void 0 : anchor.bottom) ?? window.innerHeight - VIEWPORT_GAP;
  const anchorTop = (anchor == null ? void 0 : anchor.top) ?? anchorBottom;
  const maxLeft = Math.max(VIEWPORT_GAP, window.innerWidth - rect.width - VIEWPORT_GAP);
  const left = Math.min(Math.max(VIEWPORT_GAP, anchorLeft), maxLeft);
  const below = anchorBottom + VIEWPORT_GAP;
  const top = below + rect.height <= window.innerHeight - VIEWPORT_GAP ? below : Math.max(VIEWPORT_GAP, anchorTop - rect.height - VIEWPORT_GAP);
  host.style.left = `${left}px`;
  host.style.top = `${top}px`;
}
function showToolbar() {
  const selection = window.getSelection();
  const text = selection == null ? void 0 : selection.toString().trim();
  if (!text || !(selection == null ? void 0 : selection.rangeCount)) return;
  selectionAnchor = selection.getRangeAt(0).getBoundingClientRect();
  const host = createOverlayHost(TOOLBAR_HOST_ID);
  const shadow = host.attachShadow({ mode: "closed" });
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = "Translate";
  button.setAttribute("aria-label", "Translate selected text");
  button.style.cssText = [
    "all:initial",
    "box-sizing:border-box",
    "display:inline-flex",
    "align-items:center",
    "min-height:32px",
    "padding:6px 10px",
    "border:1px solid rgba(255,255,255,.18)",
    "border-radius:7px",
    "background:#202428",
    "box-shadow:0 4px 14px rgba(0,0,0,.22)",
    "color:#fff",
    'font:600 13px/1.2 ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif',
    "cursor:pointer"
  ].join(";");
  button.addEventListener("mousedown", (event) => event.preventDefault());
  button.addEventListener("click", () => {
    chrome.runtime.sendMessage({
      action: "translateSelection",
      text,
      sourceId: "selection",
      requestId: id(),
      targetLanguage,
      engine: "auto",
      style: "natural"
    }).catch((error) => console.error("[translation][content] selection message failed", { error: String(error) }));
    host.remove();
  });
  shadow.appendChild(button);
  positionNearSelection(host);
}
function hideToolbar() {
  var _a;
  (_a = document.getElementById(TOOLBAR_HOST_ID)) == null ? void 0 : _a.remove();
}
function showSelectionResult(text) {
  const host = createOverlayHost(RESULT_HOST_ID);
  const shadow = host.attachShadow({ mode: "closed" });
  const result = document.createElement("div");
  result.setAttribute("role", "status");
  result.style.cssText = [
    "all:initial",
    "box-sizing:border-box",
    "display:block",
    "width:max-content",
    "max-width:min(360px,calc(100vw - 16px))",
    "padding:10px 12px",
    "border:1px solid #cbd2d8",
    "border-radius:8px",
    "background:#fff",
    "box-shadow:0 8px 24px rgba(20,29,36,.18)",
    "color:#20272c",
    'font:400 14px/1.55 ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Noto Sans SC",sans-serif',
    "white-space:pre-wrap",
    "overflow-wrap:anywhere",
    "word-break:break-word"
  ].join(";");
  result.textContent = text;
  shadow.appendChild(result);
  positionNearSelection(host);
  window.setTimeout(() => host.remove(), 1e4);
}
if (shouldInitialize) chrome.runtime.onMessage.addListener((message) => {
  var _a;
  if (message.action === "startPageTranslation") {
    for (const unit of units.values()) {
      if (unit.retryTimer) clearTimeout(unit.retryTimer);
      unit.retryTimer = void 0;
      unit.retryCount = 0;
      unit.state = resetStateForNewTranslationSession(unit.state);
    }
    session = message.pageSessionId || id();
    mode = message.mode || "bilingual";
    targetLanguage = message.targetLanguage || targetLanguage;
    console.info("[translation][content] start received", {
      session,
      mode,
      targetLanguage,
      translateTitle: message.translateTitle
    });
    if (!titleOriginal) titleOriginal = document.title;
    viewportObserver == null ? void 0 : viewportObserver.disconnect();
    viewportObserver = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        viewportObserver == null ? void 0 : viewportObserver.unobserve(entry.target);
        const sourceId = entry.target.dataset.browseronlySourceId;
        const unit = sourceId ? units.get(sourceId) : void 0;
        if ((unit == null ? void 0 : unit.state) === "idle") sendUnit(unit);
      }
    }, { root: null, rootMargin: "600px", threshold: 0.1 });
    if (message.translateTitle !== false) {
      const requestId = id();
      console.info("[translation][content] title batch sending", { session, requestId });
      const requestSession = session;
      chrome.runtime.sendMessage({
        action: "translationBatch",
        pageSessionId: requestSession,
        requestId,
        targetLanguage,
        engine: "auto",
        units: [{ sourceId: "__title__", text: document.title, kind: "title" }]
      }).then((response) => {
        if (requestSession === session && (response == null ? void 0 : response.success)) render(response.results || []);
      }).catch((error) => console.error("[translation][content] title message failed", { session, requestId, error: String(error) }));
    }
    scan();
    observer == null ? void 0 : observer.disconnect();
    observer = new MutationObserver(() => scan());
    observer.observe(root(), { childList: true, subtree: true });
  }
  if (message.action === "translationBatchResult" && message.pageSessionId === session) {
    console.info("[translation][content] batch result received", {
      session,
      requestId: message.requestId,
      results: (_a = message.results) == null ? void 0 : _a.length
    });
    render(message.results || []);
  }
  if (message.action === "translationStatus" && message.pageSessionId === session) {
    console.error("[translation][content] translation failed", {
      session,
      requestId: message.requestId,
      error: message.error
    });
  }
  if (message.action === "translationSelectionResult") {
    showSelectionResult(message.error || message.translatedText || "");
  }
  if (message.action === "stopPageTranslation") {
    observer == null ? void 0 : observer.disconnect();
    viewportObserver == null ? void 0 : viewportObserver.disconnect();
    restore();
    session = "";
    for (const unit of units.values()) if (unit.retryTimer) clearTimeout(unit.retryTimer);
    units.clear();
  }
  if (message.action === "setTranslationMode") {
    mode = message.mode || mode;
    if (mode === "original") restore();
    else render(Array.from(units.values()).filter((unit) => unit.translation).map((unit) => ({ sourceId: unit.sourceId, translatedText: unit.translation })));
  }
});
if (shouldInitialize) document.addEventListener("mouseup", () => window.setTimeout(showToolbar, 0));
if (shouldInitialize) document.addEventListener("mousedown", (event) => {
  var _a;
  const target = event.target;
  if (!((_a = target == null ? void 0 : target.closest) == null ? void 0 : _a.call(target, `#${TOOLBAR_HOST_ID}`))) hideToolbar();
});
window.addEventListener("resize", () => {
  const toolbar = document.getElementById(TOOLBAR_HOST_ID);
  if (toolbar) positionNearSelection(toolbar);
  const result = document.getElementById(RESULT_HOST_ID);
  if (result) positionNearSelection(result);
});
//# sourceMappingURL=pageTranslation.js.map
