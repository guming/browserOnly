import { j as jsxRuntimeExports, R as React, r as reactExports, c as clientExports } from "./assets/index-DYXYk3NX.js";
import { a as getOllamaExtensionOrigin, D as DEFAULT_OLLAMA_BASE_URL, b as getOllamaConnectionError, C as ConfigManager, _ as __vitePreload, d as anthropicDefaultModelId, o as openaiDefaultModelId, e as geminiDefaultModelId, f as ollamaDefaultModelId, h as deepseekDefaultModelId } from "./assets/_commonjsHelpers-DP-qmQZY.js";
import { M as MemoryService } from "./assets/memoryService-4aM8quJj.js";
const providers = ["Anthropic", "OpenAI", "Google Gemini", "DeepSeek", "Ollama"];
function AboutSection() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "about-section", "aria-labelledby": "about-title", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-kicker", children: "Overview" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "about-heading-row", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { id: "about-title", children: "About BrowserOnly" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "about-lede", children: "Browser automation controlled by plain language." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "version-chip", children: "v0.4.6" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "about-copy", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "BrowserOnly lets you operate Chrome from the side panel. Describe the task, and the extension turns it into browser actions through your chosen model." }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "about-meta", "aria-label": "BrowserOnly capabilities", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "meta-label", children: "Works with" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "provider-list", children: providers.map((provider) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: provider }, provider)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "meta-label", children: "Execution" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "meta-value", children: "Playwright" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "meta-label", children: "License" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "meta-value", children: "Open source" })
      ] })
    ] })
  ] });
}
function ArrowIcon() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow-icon", "aria-hidden": "true", children: "→" });
}
function GeneralTab({ onOpenConfiguration }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "general-page", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(AboutSection, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "guide-section", "aria-labelledby": "start-title", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-kicker", children: "Quick start" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "guide-heading-row", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { id: "start-title", children: "Get your first task running" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Three steps are all you need to connect a model and start browsing." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "text-link", type: "button", onClick: onOpenConfiguration, children: [
          "Open configuration ",
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowIcon, {})
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "steps-grid", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("article", { className: "step-item", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "step-number", children: "01" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { children: "Choose a provider" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Pick Anthropic, OpenAI, DeepSeek, Gemini, or a local Ollama model." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("article", { className: "step-item", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "step-number", children: "02" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { children: "Add your credentials" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Enter an API key in LLM Configuration, then save your settings." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("article", { className: "step-item", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "step-number", children: "03" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { children: "Describe the task" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Open the side panel and try: “Search for the weather in Paris.”" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "notes-section", "aria-labelledby": "notes-title", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-kicker", children: "Good to know" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { id: "notes-title", children: "A few operating notes" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "notes-list", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Keep BrowserOnly attached to the active tab while a task is running." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "One BrowserOnly instance can run in each Chrome window." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Chrome system pages and newly opened tabs cannot be attached." })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("footer", { className: "help-footer", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "section-kicker", children: "Need a hand?" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { children: "Join the BrowserOnly community" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Share workflows, report issues, and get help from other users." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { className: "outline-button", href: "https://discord.gg/P3fu9Rhb", target: "_blank", rel: "noopener noreferrer", children: [
        "Open Discord ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowIcon, {})
      ] })
    ] })
  ] });
}
function ProviderSelector({ provider, setProvider }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6 border-b border-stone-200 pb-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "default-provider", className: "mb-1 block text-sm font-semibold text-stone-800", children: "Default Provider" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-3 text-xs leading-5 text-stone-500", children: "Used for general LLM tasks. Translation can follow this provider or use another configured provider." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "select",
      {
        id: "default-provider",
        className: "select select-bordered w-full max-w-md",
        value: provider,
        onChange: (e) => setProvider(e.target.value),
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "deepseek", children: "DeepSeek" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "openai", children: "OpenAI" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "anthropic", children: "Anthropic" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "gemini", children: "Google Gemini" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "ollama", children: "Ollama" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "openai-compatible", children: "OpenAI Compatible" })
        ]
      }
    )
  ] });
}
function AnthropicSettings({
  anthropicApiKey,
  setAnthropicApiKey,
  anthropicBaseUrl,
  setAnthropicBaseUrl,
  thinkingBudgetTokens,
  setThinkingBudgetTokens
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border rounded-lg p-4 mb-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold mb-2", children: "Anthropic Settings" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "anthropic-api-key", className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "API Key:" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "password",
          id: "anthropic-api-key",
          value: anthropicApiKey,
          onChange: (e) => setAnthropicApiKey(e.target.value),
          placeholder: "Enter your Anthropic API key",
          className: "input input-bordered w-full"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "anthropic-base-url", className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "Base URL (optional):" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "text",
          id: "anthropic-base-url",
          value: anthropicBaseUrl,
          onChange: (e) => setAnthropicBaseUrl(e.target.value),
          placeholder: "Custom base URL (leave empty for default)",
          className: "input input-bordered w-full"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "thinking-budget", className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "Thinking Budget (tokens):" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "number",
          id: "thinking-budget",
          value: thinkingBudgetTokens,
          onChange: (e) => setThinkingBudgetTokens(parseInt(e.target.value) || 0),
          placeholder: "0 to disable thinking",
          className: "input input-bordered w-full",
          min: "0"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text-alt", children: "Set to 0 to disable Claude's thinking feature" }) })
    ] })
  ] });
}
function GeminiSettings({
  geminiApiKey,
  setGeminiApiKey,
  geminiBaseUrl,
  setGeminiBaseUrl
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border rounded-lg p-4 mb-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold mb-2", children: "Google Gemini Settings" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "gemini-api-key", className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "API Key:" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "password",
          id: "gemini-api-key",
          value: geminiApiKey,
          onChange: (e) => setGeminiApiKey(e.target.value),
          placeholder: "Enter your Google AI API key",
          className: "input input-bordered w-full"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "gemini-base-url", className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "Base URL (optional):" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "text",
          id: "gemini-base-url",
          value: geminiBaseUrl,
          onChange: (e) => setGeminiBaseUrl(e.target.value),
          placeholder: "Custom base URL (leave empty for default)",
          className: "input input-bordered w-full"
        }
      )
    ] })
  ] });
}
function OllamaModelList({
  models,
  setModels,
  newModel,
  setNewModel,
  handleAddModel,
  handleRemoveModel,
  handleEditModel
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "Custom Ollama Models:" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-2 text-sm", children: "Add your custom Ollama models here. Increasing the context window can help with rate limit errors but requires more VRAM." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "table table-zebra w-full mb-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "ID" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "Name" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "Context Window" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "Action" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { children: [
        models.map((model, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: "input input-bordered input-sm w-full",
              value: model.id,
              onChange: (e) => handleEditModel(idx, "id", e.target.value)
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: "input input-bordered input-sm w-full",
              value: model.name,
              onChange: (e) => handleEditModel(idx, "name", e.target.value)
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: "input input-bordered input-sm w-full",
              type: "number",
              value: model.contextWindow,
              onChange: (e) => handleEditModel(idx, "contextWindow", parseInt(e.target.value) || 32768),
              min: "1000",
              step: "1000"
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-sm btn-error", onClick: () => handleRemoveModel(model.id), children: "Delete" }) })
        ] }, model.id)),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: "input input-bordered input-sm w-full",
              value: newModel.id,
              onChange: (e) => setNewModel({ ...newModel, id: e.target.value }),
              placeholder: "Model ID"
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: "input input-bordered input-sm w-full",
              value: newModel.name,
              onChange: (e) => setNewModel({ ...newModel, name: e.target.value }),
              placeholder: "Model Name"
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: "input input-bordered input-sm w-full",
              type: "number",
              value: newModel.contextWindow,
              onChange: (e) => setNewModel({ ...newModel, contextWindow: parseInt(e.target.value) || 32768 }),
              placeholder: "32768",
              min: "1000",
              step: "1000"
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-sm btn-primary", onClick: handleAddModel, children: "Add" }) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-gray-500 mt-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Default context window: 32768. Adjust based on your hardware capabilities." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "If you're experiencing rate limit errors, try increasing the context window." })
    ] })
  ] });
}
function OllamaSettings({
  ollamaApiKey,
  setOllamaApiKey,
  ollamaBaseUrl,
  setOllamaBaseUrl,
  ollamaModelId,
  setOllamaModelId,
  ollamaCustomModels,
  setOllamaCustomModels,
  newOllamaModel,
  setNewOllamaModel,
  handleAddOllamaModel,
  handleRemoveOllamaModel,
  handleEditOllamaModel
}) {
  const [isDiscovering, setIsDiscovering] = React.useState(false);
  const [connectionStatus, setConnectionStatus] = React.useState(null);
  const extensionOrigin = getOllamaExtensionOrigin();
  const discoverModels = async () => {
    setIsDiscovering(true);
    setConnectionStatus(null);
    try {
      const response = await fetch(`${(ollamaBaseUrl || DEFAULT_OLLAMA_BASE_URL).replace(/\/$/, "")}/api/tags`);
      if (!response.ok) {
        setConnectionStatus({
          kind: "error",
          message: getOllamaConnectionError(response.status, extensionOrigin)
        });
        return;
      }
      const data = await response.json();
      const discovered = (data.models || []).map((model) => ({
        id: model.name,
        name: model.name,
        contextWindow: 32768
      }));
      const merged = [...ollamaCustomModels];
      discovered.forEach((model) => {
        if (!merged.some((existing) => existing.id === model.id)) merged.push(model);
      });
      setOllamaCustomModels(merged);
      if (!ollamaModelId && merged[0]) setOllamaModelId(merged[0].id);
      await chrome.storage.sync.set({ ollamaCustomModels: merged });
      if (!ollamaModelId && merged[0]) await chrome.storage.sync.set({ ollamaModelId: merged[0].id });
      await chrome.runtime.sendMessage({ action: "providerConfigChanged" }).catch(() => void 0);
      if (discovered.length === 0) {
        setConnectionStatus({ kind: "warning", message: "Connected, but no local models were found." });
      } else {
        setConnectionStatus({
          kind: "success",
          message: `Connected. Found ${discovered.length} local model${discovered.length === 1 ? "" : "s"}.`
        });
      }
    } catch {
      setConnectionStatus({
        kind: "error",
        message: getOllamaConnectionError(null, extensionOrigin)
      });
    } finally {
      setIsDiscovering(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border rounded-lg p-4 mb-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold mb-2", children: "Ollama Settings" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "ollama-api-key", className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "API Key (optional):" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "password",
          id: "ollama-api-key",
          value: ollamaApiKey,
          onChange: (e) => setOllamaApiKey(e.target.value),
          placeholder: "Enter your Ollama API key if required",
          className: "input input-bordered w-full"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text-alt", children: "Ollama typically doesn't require an API key" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "ollama-base-url", className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "Base URL:" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "text",
          id: "ollama-base-url",
          value: ollamaBaseUrl,
          onChange: (e) => {
            const newValue = e.target.value;
            setOllamaBaseUrl(newValue);
            chrome.storage.sync.set({ ollamaBaseUrl: newValue });
          },
          placeholder: DEFAULT_OLLAMA_BASE_URL,
          className: "input input-bordered w-full"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "label-text-alt", children: [
        "Local default: ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: DEFAULT_OLLAMA_BASE_URL }),
        ". Extension origin: ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: extensionOrigin })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex flex-wrap items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", className: "btn btn-outline btn-sm", onClick: discoverModels, disabled: isDiscovering, children: [
        isDiscovering ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "loading loading-spinner loading-xs" }) : null,
        isDiscovering ? "Checking Ollama..." : "Detect Local Models"
      ] }),
      connectionStatus && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "span",
        {
          role: "status",
          className: `text-xs ${connectionStatus.kind === "error" ? "text-error" : connectionStatus.kind === "warning" ? "text-warning" : "text-success"}`,
          children: connectionStatus.message
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "alert alert-info mb-4 text-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
      "Ollama must allow this extension origin. For a terminal-launched server, use",
      " ",
      /* @__PURE__ */ jsxRuntimeExports.jsxs("code", { children: [
        "OLLAMA_ORIGINS=",
        extensionOrigin,
        " ollama serve"
      ] }),
      ". If the Ollama desktop app is already running, configure the same environment variable and fully restart the app."
    ] }) }) }),
    ollamaCustomModels.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "alert alert-info mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", className: "stroke-current shrink-0 w-6 h-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "You need to add at least one Ollama model below before you can use Ollama as a provider." })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      OllamaModelList,
      {
        models: ollamaCustomModels,
        setModels: setOllamaCustomModels,
        newModel: newOllamaModel,
        setNewModel: setNewOllamaModel,
        handleAddModel: handleAddOllamaModel,
        handleRemoveModel: handleRemoveOllamaModel,
        handleEditModel: handleEditOllamaModel
      }
    )
  ] });
}
function ModelList({
  models,
  setModels,
  newModel,
  setNewModel,
  handleAddModel,
  handleRemoveModel,
  handleEditModel
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "Model List:" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "table table-zebra w-full mb-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "ID" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "Name" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "Reasoning Model?" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "Action" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { children: [
        models.map((model, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: "input input-bordered input-sm w-full",
              value: model.id,
              onChange: (e) => handleEditModel(idx, "id", e.target.value)
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: "input input-bordered input-sm w-full",
              value: model.name,
              onChange: (e) => handleEditModel(idx, "name", e.target.value)
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              checked: !!model.isReasoningModel,
              onChange: (e) => handleEditModel(idx, "isReasoningModel", e.target.checked)
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-sm btn-error", onClick: () => handleRemoveModel(model.id), children: "Delete" }) })
        ] }, model.id)),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: "input input-bordered input-sm w-full",
              value: newModel.id,
              onChange: (e) => setNewModel({ ...newModel, id: e.target.value }),
              placeholder: "Model ID"
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: "input input-bordered input-sm w-full",
              value: newModel.name,
              onChange: (e) => setNewModel({ ...newModel, name: e.target.value }),
              placeholder: "Model Name"
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              checked: !!newModel.isReasoningModel,
              onChange: (e) => setNewModel({ ...newModel, isReasoningModel: e.target.checked })
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-sm btn-primary", onClick: handleAddModel, children: "Add" }) })
        ] })
      ] })
    ] })
  ] });
}
function OpenAICompatibleSettings({
  openaiCompatibleApiKey,
  setOpenaiCompatibleApiKey,
  openaiCompatibleBaseUrl,
  setOpenaiCompatibleBaseUrl,
  openaiCompatibleModelId,
  setOpenaiCompatibleModelId,
  openaiCompatibleModels,
  setOpenaiCompatibleModels,
  newModel,
  setNewModel,
  handleAddModel,
  handleRemoveModel,
  handleEditModel
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border rounded-lg p-4 mb-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold mb-2", children: "OpenAI Compatible Settings" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "openai-compatible-api-key", className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "API Key:" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "password",
          id: "openai-compatible-api-key",
          value: openaiCompatibleApiKey,
          onChange: (e) => setOpenaiCompatibleApiKey(e.target.value),
          placeholder: "Enter your OpenAI-Compatible API key",
          className: "input input-bordered w-full"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "openai-compatible-base-url", className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "Base URL:" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "text",
          id: "openai-compatible-base-url",
          value: openaiCompatibleBaseUrl,
          onChange: (e) => setOpenaiCompatibleBaseUrl(e.target.value),
          placeholder: "Custom base URL (leave empty for default)",
          className: "input input-bordered w-full"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      ModelList,
      {
        models: openaiCompatibleModels,
        setModels: setOpenaiCompatibleModels,
        newModel,
        setNewModel,
        handleAddModel,
        handleRemoveModel,
        handleEditModel
      }
    ),
    openaiCompatibleModels.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "Current Model:" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "select",
        {
          className: "select select-bordered w-full",
          value: openaiCompatibleModelId,
          onChange: (e) => setOpenaiCompatibleModelId(e.target.value),
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "Select a model" }),
            openaiCompatibleModels.map((m) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: m.id, children: [
              m.name,
              " (",
              m.id,
              ")"
            ] }, m.id))
          ]
        }
      )
    ] })
  ] });
}
function OpenAISettings({
  openaiApiKey,
  setOpenaiApiKey,
  openaiBaseUrl,
  setOpenaiBaseUrl
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border rounded-lg p-4 mb-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold mb-2", children: "OpenAI Settings" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "openai-api-key", className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "API Key:" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "password",
          id: "openai-api-key",
          value: openaiApiKey,
          onChange: (e) => setOpenaiApiKey(e.target.value),
          placeholder: "Enter your OpenAI API key",
          className: "input input-bordered w-full"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "openai-base-url", className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "Base URL (optional):" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "text",
          id: "openai-base-url",
          value: openaiBaseUrl,
          onChange: (e) => setOpenaiBaseUrl(e.target.value),
          placeholder: "Custom base URL (leave empty for default)",
          className: "input input-bordered w-full"
        }
      )
    ] })
  ] });
}
function DeepSeekSettings({
  deepseekApiKey,
  setDeepseekApiKey,
  deepseekBaseUrl,
  setDeepseekBaseUrl
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border rounded-lg p-4 mb-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold mb-2", children: "DeepSeek Settings" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "deepseek-api-key", className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "API Key:" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "password",
          id: "deepseek-api-key",
          value: deepseekApiKey,
          onChange: (e) => setDeepseekApiKey(e.target.value),
          placeholder: "Enter your DeepSeek API key",
          className: "input input-bordered w-full"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "deepseek-base-url", className: "label", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text", children: "Base URL (optional):" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "text",
          id: "deepseek-base-url",
          value: deepseekBaseUrl,
          onChange: (e) => setDeepseekBaseUrl(e.target.value),
          placeholder: "Custom base URL (leave empty for default)",
          className: "input input-bordered w-full"
        }
      )
    ] })
  ] });
}
function ProviderSettings({
  provider,
  // Anthropic
  anthropicApiKey,
  setAnthropicApiKey,
  anthropicBaseUrl,
  setAnthropicBaseUrl,
  thinkingBudgetTokens,
  setThinkingBudgetTokens,
  // OpenAI
  openaiApiKey,
  setOpenaiApiKey,
  openaiBaseUrl,
  setOpenaiBaseUrl,
  // DeepSeek
  deepseekApiKey,
  setDeepseekApiKey,
  deepseekBaseUrl,
  setDeepseekBaseUrl,
  // Gemini
  geminiApiKey,
  setGeminiApiKey,
  geminiBaseUrl,
  setGeminiBaseUrl,
  // Ollama
  ollamaApiKey,
  setOllamaApiKey,
  ollamaBaseUrl,
  setOllamaBaseUrl,
  ollamaModelId,
  setOllamaModelId,
  ollamaCustomModels,
  setOllamaCustomModels,
  newOllamaModel,
  setNewOllamaModel,
  handleAddOllamaModel,
  handleRemoveOllamaModel,
  handleEditOllamaModel,
  // OpenAI-compatible
  openaiCompatibleApiKey,
  setOpenaiCompatibleApiKey,
  openaiCompatibleBaseUrl,
  setOpenaiCompatibleBaseUrl,
  openaiCompatibleModelId,
  setOpenaiCompatibleModelId,
  openaiCompatibleModels,
  setOpenaiCompatibleModels,
  newModel,
  setNewModel,
  handleAddModel,
  handleRemoveModel,
  handleEditModel
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    provider === "anthropic" && /* @__PURE__ */ jsxRuntimeExports.jsx(
      AnthropicSettings,
      {
        anthropicApiKey,
        setAnthropicApiKey,
        anthropicBaseUrl,
        setAnthropicBaseUrl,
        thinkingBudgetTokens,
        setThinkingBudgetTokens
      }
    ),
    provider === "openai" && /* @__PURE__ */ jsxRuntimeExports.jsx(
      OpenAISettings,
      {
        openaiApiKey,
        setOpenaiApiKey,
        openaiBaseUrl,
        setOpenaiBaseUrl
      }
    ),
    provider === "deepseek" && /* @__PURE__ */ jsxRuntimeExports.jsx(
      DeepSeekSettings,
      {
        deepseekApiKey,
        setDeepseekApiKey,
        deepseekBaseUrl,
        setDeepseekBaseUrl
      }
    ),
    provider === "gemini" && /* @__PURE__ */ jsxRuntimeExports.jsx(
      GeminiSettings,
      {
        geminiApiKey,
        setGeminiApiKey,
        geminiBaseUrl,
        setGeminiBaseUrl
      }
    ),
    provider === "ollama" && /* @__PURE__ */ jsxRuntimeExports.jsx(
      OllamaSettings,
      {
        ollamaApiKey,
        setOllamaApiKey,
        ollamaBaseUrl,
        setOllamaBaseUrl,
        ollamaModelId,
        setOllamaModelId,
        ollamaCustomModels,
        setOllamaCustomModels,
        newOllamaModel,
        setNewOllamaModel,
        handleAddOllamaModel,
        handleRemoveOllamaModel,
        handleEditOllamaModel
      }
    ),
    provider === "openai-compatible" && /* @__PURE__ */ jsxRuntimeExports.jsx(
      OpenAICompatibleSettings,
      {
        openaiCompatibleApiKey,
        setOpenaiCompatibleApiKey,
        openaiCompatibleBaseUrl,
        setOpenaiCompatibleBaseUrl,
        openaiCompatibleModelId,
        setOpenaiCompatibleModelId,
        openaiCompatibleModels,
        setOpenaiCompatibleModels,
        newModel,
        setNewModel,
        handleAddModel,
        handleRemoveModel,
        handleEditModel
      }
    )
  ] });
}
function SaveButton({ isSaving, saveStatus, handleSave, isDisabled }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: handleSave,
        disabled: isSaving || isDisabled,
        className: "btn btn-primary",
        children: isSaving ? "Saving..." : "Save Settings"
      }
    ),
    saveStatus && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "alert alert-success mt-4", children: saveStatus })
  ] });
}
function ProvidersTab({
  // Provider selection
  provider,
  setProvider,
  // Anthropic settings
  anthropicApiKey,
  setAnthropicApiKey,
  anthropicBaseUrl,
  setAnthropicBaseUrl,
  thinkingBudgetTokens,
  setThinkingBudgetTokens,
  // OpenAI settings
  openaiApiKey,
  setOpenaiApiKey,
  openaiBaseUrl,
  setOpenaiBaseUrl,
  // DeepSeek settings
  deepseekApiKey,
  setDeepseekApiKey,
  deepseekBaseUrl,
  setDeepseekBaseUrl,
  // Gemini settings
  geminiApiKey,
  setGeminiApiKey,
  geminiBaseUrl,
  setGeminiBaseUrl,
  // Ollama settings
  ollamaApiKey,
  setOllamaApiKey,
  ollamaBaseUrl,
  setOllamaBaseUrl,
  ollamaModelId,
  setOllamaModelId,
  ollamaCustomModels,
  setOllamaCustomModels,
  newOllamaModel,
  setNewOllamaModel,
  handleAddOllamaModel,
  handleRemoveOllamaModel,
  handleEditOllamaModel,
  // OpenAI-compatible settings
  openaiCompatibleApiKey,
  setOpenaiCompatibleApiKey,
  openaiCompatibleBaseUrl,
  setOpenaiCompatibleBaseUrl,
  openaiCompatibleModelId,
  setOpenaiCompatibleModelId,
  openaiCompatibleModels,
  setOpenaiCompatibleModels,
  newModel,
  setNewModel,
  // Save functionality
  isSaving,
  saveStatus,
  handleSave,
  // Model operations
  handleAddModel,
  handleRemoveModel,
  handleEditModel
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "card bg-base-100 shadow-md", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "card-body", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "card-title text-xl", children: "LLM Provider Configuration" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-4", children: "Choose the default provider for LLM tasks, then configure its connection settings. Your API keys are stored securely in your browser's storage." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(ProviderSelector, { provider, setProvider }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      ProviderSettings,
      {
        provider,
        anthropicApiKey,
        setAnthropicApiKey,
        anthropicBaseUrl,
        setAnthropicBaseUrl,
        thinkingBudgetTokens,
        setThinkingBudgetTokens,
        openaiApiKey,
        setOpenaiApiKey,
        openaiBaseUrl,
        setOpenaiBaseUrl,
        deepseekApiKey,
        setDeepseekApiKey,
        deepseekBaseUrl,
        setDeepseekBaseUrl,
        geminiApiKey,
        setGeminiApiKey,
        geminiBaseUrl,
        setGeminiBaseUrl,
        ollamaApiKey,
        setOllamaApiKey,
        ollamaBaseUrl,
        setOllamaBaseUrl,
        ollamaModelId,
        setOllamaModelId,
        ollamaCustomModels,
        setOllamaCustomModels,
        newOllamaModel,
        setNewOllamaModel,
        handleAddOllamaModel,
        handleRemoveOllamaModel,
        handleEditOllamaModel,
        openaiCompatibleApiKey,
        setOpenaiCompatibleApiKey,
        openaiCompatibleBaseUrl,
        setOpenaiCompatibleBaseUrl,
        openaiCompatibleModelId,
        setOpenaiCompatibleModelId,
        openaiCompatibleModels,
        setOpenaiCompatibleModels,
        newModel,
        setNewModel,
        handleAddModel,
        handleRemoveModel,
        handleEditModel
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      SaveButton,
      {
        isSaving,
        saveStatus,
        handleSave,
        isDisabled: provider === "anthropic" && !anthropicApiKey.trim() || provider === "openai" && !openaiApiKey.trim() || provider === "gemini" && !geminiApiKey.trim()
      }
    )
  ] }) }) });
}
function MemoryManagement() {
  const [memoryCount, setMemoryCount] = reactExports.useState(0);
  const [exportStatus, setExportStatus] = reactExports.useState("");
  const [importStatus, setImportStatus] = reactExports.useState("");
  const fileInputRef = reactExports.useRef(null);
  const loadMemoryCount = async () => {
    try {
      const memoryService = MemoryService.getInstance();
      await memoryService.init();
      const memories = await memoryService.getAllMemories();
      setMemoryCount(memories.length);
    } catch (error) {
      console.error("Error loading memory count:", error);
    }
  };
  const handleExportMemories = async () => {
    try {
      setExportStatus("Exporting...");
      const memoryService = MemoryService.getInstance();
      await memoryService.init();
      const memories = await memoryService.getAllMemories();
      const jsonData = JSON.stringify(memories, null, 2);
      const blob = new Blob([jsonData], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const date = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
      const filename = `BrowserOnly-memories-${date}.json`;
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setExportStatus(`Successfully exported ${memories.length} memories!`);
      setTimeout(() => setExportStatus(""), 3e3);
    } catch (error) {
      setExportStatus(`Error exporting memories: ${error instanceof Error ? error.message : String(error)}`);
    }
  };
  const handleImportMemories = async (event) => {
    var _a;
    try {
      const file = (_a = event.target.files) == null ? void 0 : _a[0];
      if (!file) return;
      setImportStatus("Importing...");
      const reader = new FileReader();
      reader.onload = async (e) => {
        var _a2;
        try {
          const content = (_a2 = e.target) == null ? void 0 : _a2.result;
          const memories = JSON.parse(content);
          if (!Array.isArray(memories)) {
            throw new Error("Invalid format: Expected an array of memories");
          }
          const memoryService = MemoryService.getInstance();
          await memoryService.init();
          let importedCount = 0;
          for (const memory of memories) {
            if (!memory.domain || !memory.taskDescription || !memory.toolSequence) {
              console.warn("Skipping invalid memory:", memory);
              continue;
            }
            if (!memory.createdAt) {
              memory.createdAt = Date.now();
            }
            await memoryService.storeMemory(memory);
            importedCount++;
          }
          await loadMemoryCount();
          setImportStatus(`Successfully imported ${importedCount} memories!`);
          setTimeout(() => setImportStatus(""), 3e3);
          if (fileInputRef.current) {
            fileInputRef.current.value = "";
          }
        } catch (error) {
          setImportStatus(`Error parsing import file: ${error instanceof Error ? error.message : String(error)}`);
        }
      };
      reader.readAsText(file);
    } catch (error) {
      setImportStatus(`Error importing memories: ${error instanceof Error ? error.message : String(error)}`);
    }
  };
  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  reactExports.useEffect(() => {
    loadMemoryCount();
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white/80 backdrop-blur-sm rounded-3xl shadow-lg border border-white/50 overflow-hidden hover:shadow-xl transition-all duration-300", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-gradient-to-r from-sky-50 to-blue-50 border-b border-sky-100 px-6 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-2xl font-bold text-gray-800 flex items-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mr-3 text-3xl", children: "🧠" }),
      "Memory Management"
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-gradient-to-r from-violet-50/50 to-purple-50/50 rounded-2xl p-4 border border-violet-100/50", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start space-x-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-shrink-0 mt-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 bg-gradient-to-r from-violet-500 to-purple-600 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" }) }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-gray-700 leading-relaxed", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-violet-700", children: "BrowserOnly" }),
            " intelligently stores memories of successful interactions with websites to enhance future automation. Export your memories for backup or transfer them to another device seamlessly."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex items-center space-x-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 bg-green-400 rounded-full" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm text-gray-600", children: "Auto Learning" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 bg-blue-400 rounded-full" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm text-gray-600", children: "Portable" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-2 h-2 bg-purple-400 rounded-full" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm text-gray-600", children: "Smart Recall" })
            ] })
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-gradient-to-r from-emerald-50/50 to-teal-50/50 rounded-2xl p-4 border border-emerald-100/50", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-5 h-5 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" }) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold text-emerald-700", children: "Memory Collection" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-emerald-600", children: "Stored interaction patterns and optimizations" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-white/70 backdrop-blur-sm rounded-xl px-4 py-2 border border-white/50 shadow-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium text-gray-600", children: "Current memories:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline-flex items-center px-3 py-1 bg-gradient-to-r from-emerald-500 to-teal-600 text-white text-sm font-medium rounded-full shadow-sm", children: memoryCount })
        ] }) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gradient-to-r from-sky-50/50 to-cyan-50/50 rounded-2xl p-4 border border-sky-100/50", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-lg font-semibold text-sky-700 mb-4 flex items-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-5 h-5 mr-2", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3-3m0 0l-3 3m3-3v12" }) }),
          "Memory Operations"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              onClick: handleExportMemories,
              className: "flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white font-medium rounded-xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none disabled:hover:shadow-lg",
              disabled: memoryCount === 0,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Export Memories" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              onClick: triggerFileInput,
              className: "flex items-center space-x-2 px-6 py-3 bg-white/70 backdrop-blur-sm border border-gray-200 text-gray-700 font-medium rounded-xl shadow-md hover:bg-white/90 hover:border-gray-300 hover:shadow-lg transform hover:scale-105 transition-all duration-200",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Import Memories" })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "file",
              ref: fileInputRef,
              onChange: handleImportMemories,
              accept: ".json",
              className: "hidden"
            }
          )
        ] })
      ] }),
      (exportStatus || importStatus) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
        exportStatus && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `rounded-2xl p-4 border ${exportStatus.includes("Error") ? "bg-gradient-to-r from-red-50/50 to-pink-50/50 border-red-100/50" : "bg-gradient-to-r from-green-50/50 to-emerald-50/50 border-green-100/50"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-8 h-8 rounded-full flex items-center justify-center ${exportStatus.includes("Error") ? "bg-gradient-to-r from-red-500 to-pink-600" : "bg-gradient-to-r from-green-500 to-emerald-600"}`, children: exportStatus.includes("Error") ? /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M6 18L18 6M6 6l12 12" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-sm font-medium ${exportStatus.includes("Error") ? "text-red-700" : "text-green-700"}`, children: exportStatus })
        ] }) }),
        importStatus && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `rounded-2xl p-4 border ${importStatus.includes("Error") ? "bg-gradient-to-r from-red-50/50 to-pink-50/50 border-red-100/50" : "bg-gradient-to-r from-green-50/50 to-emerald-50/50 border-green-100/50"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center space-x-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-8 h-8 rounded-full flex items-center justify-center ${importStatus.includes("Error") ? "bg-gradient-to-r from-red-500 to-pink-600" : "bg-gradient-to-r from-green-500 to-emerald-600"}`, children: importStatus.includes("Error") ? /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M6 18L18 6M6 6l12 12" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M5 13l4 4L19 7" }) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-sm font-medium ${importStatus.includes("Error") ? "text-red-700" : "text-green-700"}`, children: importStatus })
        ] }) })
      ] })
    ] })
  ] });
}
function MemoryTab() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MemoryManagement, {}) });
}
function NotionSettings({
  notionEnabled,
  setNotionEnabled,
  notionBearerToken,
  setNotionBearerToken,
  notionDatabaseId,
  setNotionDatabaseId
}) {
  const [testStatus, setTestStatus] = reactExports.useState("");
  const [saveStatus, setSaveStatus] = reactExports.useState("");
  const [isTesting, setIsTesting] = reactExports.useState(false);
  const [isSaving, setIsSaving] = reactExports.useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = reactExports.useState(false);
  const [availableDatabases, setAvailableDatabases] = reactExports.useState([]);
  const [isLoadingDatabases, setIsLoadingDatabases] = reactExports.useState(false);
  reactExports.useEffect(() => {
    const loadNotionSettings = async () => {
      const configManager = ConfigManager.getInstance();
      const notionConfig = await configManager.getNotionConfig();
      setNotionEnabled(notionConfig.enabled);
      setNotionBearerToken(notionConfig.bearerToken);
      try {
        const result = await chrome.storage.sync.get(["notionDatabaseId"]);
        if (result.notionDatabaseId) {
          setNotionDatabaseId(result.notionDatabaseId);
        }
      } catch (error) {
        console.error("Error loading database ID:", error);
      }
    };
    loadNotionSettings();
  }, []);
  reactExports.useEffect(() => {
    const checkForChanges = async () => {
      const configManager = ConfigManager.getInstance();
      const currentConfig = await configManager.getNotionConfig();
      let currentDatabaseId = "";
      try {
        const result = await chrome.storage.sync.get(["notionDatabaseId"]);
        currentDatabaseId = result.notionDatabaseId || "";
      } catch (error) {
        console.error("Error checking database ID:", error);
      }
      const hasChanges = currentConfig.enabled !== notionEnabled || currentConfig.bearerToken !== notionBearerToken || currentDatabaseId !== notionDatabaseId;
      setHasUnsavedChanges(hasChanges);
      if (hasChanges && saveStatus) {
        setSaveStatus("");
      }
    };
    checkForChanges();
  }, [notionEnabled, notionBearerToken, notionDatabaseId, saveStatus]);
  const loadAvailableDatabases = async () => {
    if (!notionBearerToken) return;
    setIsLoadingDatabases(true);
    try {
      const { NotionSDKClient } = await __vitePreload(async () => {
        const { NotionSDKClient: NotionSDKClient2 } = await import("./assets/notionClient-B6Inoxhc.js");
        return { NotionSDKClient: NotionSDKClient2 };
      }, true ? [] : void 0);
      const client = new NotionSDKClient({
        auth: notionBearerToken
      });
      const response = await client.search({
        filter: {
          property: "object",
          value: "database"
        },
        page_size: 50
      });
      const databases = response.results.filter((item) => item.object === "database").map((db) => {
        var _a, _b;
        return {
          id: db.id,
          title: ((_b = (_a = db.title) == null ? void 0 : _a[0]) == null ? void 0 : _b.plain_text) || "Untitled Database"
        };
      });
      setAvailableDatabases(databases);
    } catch (error) {
      console.error("Error loading databases:", error);
      setTestStatus(`⚠️ Could not load databases: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setIsLoadingDatabases(false);
    }
  };
  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestStatus("Testing connection...");
    try {
      const { NotionSDKClient } = await __vitePreload(async () => {
        const { NotionSDKClient: NotionSDKClient2 } = await import("./assets/notionClient-B6Inoxhc.js");
        return { NotionSDKClient: NotionSDKClient2 };
      }, true ? [] : void 0);
      const client = new NotionSDKClient({
        auth: notionBearerToken
      });
      await client.testConnection();
      setTestStatus("✅ Connection successful! Notion tools are available.");
      await loadAvailableDatabases();
    } catch (error) {
      setTestStatus(`❌ Connection failed: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setIsTesting(false);
    }
  };
  const handleSaveConnection = async () => {
    setIsSaving(true);
    setSaveStatus("Saving configuration...");
    try {
      const configManager = ConfigManager.getInstance();
      await configManager.saveNotionConfig({
        enabled: notionEnabled,
        bearerToken: notionBearerToken
      });
      await chrome.storage.sync.set({
        "notionDatabaseId": notionDatabaseId
      });
      setSaveStatus("✅ Configuration saved successfully!");
      setHasUnsavedChanges(false);
      setTimeout(() => {
        setSaveStatus("");
      }, 3e3);
    } catch (error) {
      setSaveStatus(`❌ Save failed: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setIsSaving(false);
    }
  };
  const handleTestAndSave = async () => {
    await handleTestConnection();
    if (testStatus.includes("✅")) {
      await handleSaveConnection();
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "card bg-base-100 shadow-sm border border-base-300/50", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "card-body p-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "card-title text-lg", children: "📝 Notion Integration" }),
      hasUnsavedChanges && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "badge badge-warning badge-xs", children: "Unsaved Changes" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "form-control", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "label cursor-pointer py-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text text-sm", children: "Enable Notion Integration" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "checkbox",
          className: "toggle toggle-primary toggle-sm",
          checked: notionEnabled,
          onChange: (e) => setNotionEnabled(e.target.checked)
        }
      )
    ] }) }),
    notionEnabled && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 mt-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "label py-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text text-sm", children: "Bearer Token" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "password",
            placeholder: "Your Notion API token",
            className: "input input-bordered input-sm",
            value: notionBearerToken,
            onChange: (e) => setNotionBearerToken(e.target.value)
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "label py-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text-alt text-xs", children: "Authentication token for Notion API integration" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "label py-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text text-sm", children: "Default Database" }) }),
        availableDatabases.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            className: "select select-bordered select-sm w-full",
            value: notionDatabaseId,
            onChange: (e) => setNotionDatabaseId(e.target.value),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "Select a database..." }),
              availableDatabases.map((db) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: db.id, children: [
                "📄 ",
                db.title
              ] }, db.id))
            ]
          }
        ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              placeholder: "Database ID (test connection to load databases)",
              className: "input input-bordered input-sm flex-1",
              value: notionDatabaseId,
              onChange: (e) => setNotionDatabaseId(e.target.value)
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              className: "btn btn-outline btn-xs",
              onClick: loadAvailableDatabases,
              disabled: isLoadingDatabases || !notionBearerToken,
              children: isLoadingDatabases ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "loading loading-spinner loading-xs" }) : "🔄"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "label py-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text-alt text-xs", children: "Default database for LLM content sync (optional)" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: "btn btn-outline btn-primary btn-sm flex-1",
              onClick: handleTestConnection,
              disabled: isTesting || isSaving || !notionBearerToken,
              children: isTesting ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "loading loading-spinner loading-xs" }),
                "Testing..."
              ] }) : "Test Connection"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: "btn btn-primary btn-sm flex-1",
              onClick: handleSaveConnection,
              disabled: isSaving || isTesting || !hasUnsavedChanges,
              children: isSaving ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "loading loading-spinner loading-xs" }),
                "Saving..."
              ] }) : "Save Configuration"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: "btn btn-success btn-xs w-full",
            onClick: handleTestAndSave,
            disabled: isTesting || isSaving || !notionBearerToken,
            children: isTesting || isSaving ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "loading loading-spinner loading-xs" }),
              isTesting ? "Testing..." : "Saving..."
            ] }) : "🚀 Test & Save"
          }
        ),
        testStatus && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `alert ${testStatus.includes("✅") ? "alert-success" : "alert-error"} py-2`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs", children: testStatus }) }),
        saveStatus && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `alert ${saveStatus.includes("✅") ? "alert-success" : "alert-error"} py-2`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs", children: saveStatus }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "alert alert-info py-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", className: "stroke-current shrink-0 w-5 h-5", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-sm", children: "Notion Integration Setup" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "text-xs mt-1 space-y-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Provides tools for creating/updating pages, querying databases" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Default database enables easy LLM content sync" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Test connection to verify server accessibility and load databases" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Save configuration to persist your settings" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Tools will be available in the agent when enabled" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "collapse collapse-arrow bg-base-200", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "collapse-title text-xs font-medium py-2", children: "🔧 Quick Setup Guide" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "collapse-content", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("ol", { className: "list-decimal list-inside text-xs space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { children: [
            "Go to ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://www.notion.com/my-integrations", target: "_blank", rel: "noopener noreferrer", className: "link link-primary", children: "Notion Integrations" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: 'Click "Create new integration"' }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Give it a name and select your workspace" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: 'Copy the "Internal Integration Token" (starts with ntn_)' }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Paste it in the Bearer Token field above" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: 'Click "Test Connection" to verify and load available databases' }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Select a default database for LLM content sync (optional)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: 'Click "Save Configuration" to persist your settings' }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Share your databases/pages with the integration" })
        ] }) })
      ] })
    ] })
  ] }) });
}
function DuckDBSettings({
  duckdbEnabled,
  setDuckdbEnabled,
  duckdbConnectionString,
  setDuckdbConnectionString,
  duckdbDatabasePath,
  setDuckdbDatabasePath
}) {
  const [testStatus, setTestStatus] = reactExports.useState("");
  const [saveStatus, setSaveStatus] = reactExports.useState("");
  const [isTesting, setIsTesting] = reactExports.useState(false);
  const [isSaving, setIsSaving] = reactExports.useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = reactExports.useState(false);
  reactExports.useEffect(() => {
    const loadDuckDBSettings = async () => {
      try {
        const result = await chrome.storage.sync.get(["duckdbEnabled", "duckdbConnectionString", "duckdbDatabasePath"]);
        setDuckdbEnabled(result.duckdbEnabled || false);
        setDuckdbConnectionString(result.duckdbConnectionString || "");
        setDuckdbDatabasePath(result.duckdbDatabasePath || ":memory:");
      } catch (error) {
        console.error("Error loading DuckDB settings:", error);
      }
    };
    loadDuckDBSettings();
  }, []);
  reactExports.useEffect(() => {
    const checkForChanges = async () => {
      try {
        const result = await chrome.storage.sync.get(["duckdbEnabled", "duckdbConnectionString", "duckdbDatabasePath"]);
        const hasChanges = (result.duckdbEnabled || false) !== duckdbEnabled || (result.duckdbConnectionString || "") !== duckdbConnectionString || (result.duckdbDatabasePath || ":memory:") !== duckdbDatabasePath;
        setHasUnsavedChanges(hasChanges);
        if (hasChanges && saveStatus) {
          setSaveStatus("");
        }
      } catch (error) {
        console.error("Error checking for changes:", error);
      }
    };
    checkForChanges();
  }, [duckdbEnabled, duckdbConnectionString, duckdbDatabasePath, saveStatus]);
  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestStatus("Testing DuckDB connection...");
    try {
      await new Promise((resolve) => setTimeout(resolve, 1e3));
      setTestStatus("✅ DuckDB connection successful! Database tools are available.");
    } catch (error) {
      setTestStatus(`❌ Connection failed: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setIsTesting(false);
    }
  };
  const handleSaveConnection = async () => {
    setIsSaving(true);
    setSaveStatus("Saving DuckDB configuration...");
    try {
      await chrome.storage.sync.set({
        "duckdbEnabled": duckdbEnabled,
        "duckdbConnectionString": duckdbConnectionString,
        "duckdbDatabasePath": duckdbDatabasePath
      });
      setSaveStatus("✅ DuckDB configuration saved successfully!");
      setHasUnsavedChanges(false);
      setTimeout(() => {
        setSaveStatus("");
      }, 3e3);
    } catch (error) {
      setSaveStatus(`❌ Save failed: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setIsSaving(false);
    }
  };
  const handleTestAndSave = async () => {
    await handleTestConnection();
    if (testStatus.includes("✅")) {
      await handleSaveConnection();
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "card bg-base-100 shadow-sm border border-base-300/50", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "card-body p-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "card-title text-lg", children: "🦆 DuckDB Integration" }),
      hasUnsavedChanges && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "badge badge-warning badge-xs", children: "Unsaved Changes" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "form-control", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "label cursor-pointer py-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text text-sm", children: "Enable DuckDB Integration" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "checkbox",
          className: "toggle toggle-primary toggle-sm",
          checked: duckdbEnabled,
          onChange: (e) => setDuckdbEnabled(e.target.checked)
        }
      )
    ] }) }),
    duckdbEnabled && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 mt-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "label py-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text text-sm", children: "Database Path" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            placeholder: ":memory: or path/to/database.duckdb",
            className: "input input-bordered input-sm",
            value: duckdbDatabasePath,
            onChange: (e) => setDuckdbDatabasePath(e.target.value)
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "label py-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text-alt text-xs", children: "Path to DuckDB database file (use :memory: for in-memory database)" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "label py-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text text-sm", children: "Connection String (Optional)" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            placeholder: "Additional connection parameters",
            className: "input input-bordered input-sm",
            value: duckdbConnectionString,
            onChange: (e) => setDuckdbConnectionString(e.target.value)
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "label py-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "label-text-alt text-xs", children: "Optional connection string for advanced configuration" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "form-control space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: "btn btn-outline btn-primary btn-sm flex-1",
              onClick: handleTestConnection,
              disabled: isTesting || isSaving,
              children: isTesting ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "loading loading-spinner loading-xs" }),
                "Testing..."
              ] }) : "Test Connection"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: "btn btn-primary btn-sm flex-1",
              onClick: handleSaveConnection,
              disabled: isSaving || isTesting || !hasUnsavedChanges,
              children: isSaving ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "loading loading-spinner loading-xs" }),
                "Saving..."
              ] }) : "Save Configuration"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: "btn btn-success btn-xs w-full",
            onClick: handleTestAndSave,
            disabled: isTesting || isSaving,
            children: isTesting || isSaving ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "loading loading-spinner loading-xs" }),
              isTesting ? "Testing..." : "Saving..."
            ] }) : "🚀 Test & Save"
          }
        ),
        testStatus && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `alert ${testStatus.includes("✅") ? "alert-success" : "alert-error"} py-2`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs", children: testStatus }) }),
        saveStatus && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `alert ${saveStatus.includes("✅") ? "alert-success" : "alert-error"} py-2`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs", children: saveStatus }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "alert alert-info py-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", className: "stroke-current shrink-0 w-5 h-5", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-sm", children: "DuckDB Integration Setup" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "text-xs mt-1 space-y-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Provides SQL-based data analysis and querying capabilities" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Supports both in-memory and persistent database storage" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Perfect for data analytics, ETL operations, and complex queries" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Fast columnar storage and execution engine" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Tools will be available in the agent when enabled" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "collapse collapse-arrow bg-base-200", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "collapse-title text-xs font-medium py-2", children: "🔧 Quick Setup Guide" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "collapse-content", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("ol", { className: "list-decimal list-inside text-xs space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: 'Choose between in-memory (":memory:") or persistent database' }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: 'For persistent: specify a file path like "data/mydb.duckdb"' }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Leave connection string empty for default configuration" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: 'Click "Test Connection" to verify DuckDB functionality' }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: 'Click "Save Configuration" to persist your settings' }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "DuckDB tools will be available for data analysis tasks" })
        ] }) })
      ] })
    ] })
  ] }) });
}
function ConnectionTab({
  notionEnabled,
  setNotionEnabled,
  notionBearerToken,
  setNotionBearerToken,
  notionDatabaseId,
  setNotionDatabaseId,
  duckdbEnabled,
  setDuckdbEnabled,
  duckdbConnectionString,
  setDuckdbConnectionString,
  duckdbDatabasePath,
  setDuckdbDatabasePath
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto max-w-3xl p-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold text-base-content mb-1", children: "🔗 Connections" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-base-content/70", children: "Connect external services to enhance your browsing experience" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        NotionSettings,
        {
          notionEnabled,
          setNotionEnabled,
          notionBearerToken,
          setNotionBearerToken,
          notionDatabaseId,
          setNotionDatabaseId
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        DuckDBSettings,
        {
          duckdbEnabled,
          setDuckdbEnabled,
          duckdbConnectionString,
          setDuckdbConnectionString,
          duckdbDatabasePath,
          setDuckdbDatabasePath
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "card bg-base-200/50 border border-dashed border-base-300/60", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "card-body text-center py-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-4xl mb-3", children: "🚧" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold text-base-content/70 mb-1", children: "More Integrations Coming Soon" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-base-content/50 max-w-sm mx-auto", children: "We're working on adding more service integrations to expand your productivity toolkit." })
      ] }) })
    ] })
  ] });
}
const translationLanguages = [
  { value: "zh-CN", label: "Chinese (Simplified)" },
  { value: "zh-TW", label: "Chinese (Traditional)" },
  { value: "en", label: "English" },
  { value: "ja", label: "Japanese" },
  { value: "ko", label: "Korean" },
  { value: "fr", label: "French" },
  { value: "de", label: "German" },
  { value: "es", label: "Spanish" },
  { value: "it", label: "Italian" },
  { value: "pt", label: "Portuguese" },
  { value: "ru", label: "Russian" }
];
const providerNames = {
  anthropic: "Anthropic",
  openai: "OpenAI",
  gemini: "Google Gemini",
  ollama: "Ollama",
  "openai-compatible": "OpenAI Compatible",
  deepseek: "DeepSeek"
};
function CheckIcon() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { "aria-hidden": "true", viewBox: "0 0 20 20", fill: "currentColor", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { fillRule: "evenodd", d: "M16.7 5.3a1 1 0 010 1.4l-8 8a1 1 0 01-1.4 0l-4-4a1 1 0 011.4-1.4L8 12.6l7.3-7.3a1 1 0 011.4 0z", clipRule: "evenodd" }) });
}
function FeaturesTab({ pdfInterceptorEnabled, setPdfInterceptorEnabled, translationProvider, setTranslationProvider, targetLanguage, setTargetLanguage, primaryProvider, configuredProviders }) {
  const [isSaving, setIsSaving] = reactExports.useState(false);
  const [saveStatus, setSaveStatus] = reactExports.useState("idle");
  const availableProviderIds = reactExports.useMemo(() => new Set(configuredProviders.map((item) => item.id)), [configuredProviders]);
  const selectedProviderIsAvailable = translationProvider === "primary" || availableProviderIds.has(translationProvider);
  const handleSave = () => {
    if (!selectedProviderIsAvailable) return;
    setIsSaving(true);
    setSaveStatus("idle");
    chrome.storage.sync.set({ "pdf-interceptor-enabled": pdfInterceptorEnabled, translationProvider, targetLanguage }, () => {
      setIsSaving(false);
      if (chrome.runtime.lastError) {
        setSaveStatus("error");
        return;
      }
      setSaveStatus("saved");
      chrome.runtime.sendMessage({ action: "providerConfigChanged" }).catch(() => void 0);
      window.setTimeout(() => setSaveStatus("idle"), 3e3);
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "features-page", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "features-header", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-kicker", children: "Extension capabilities" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { children: "Features" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Choose how BrowserOnly handles documents and language tasks." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "feature-count", "aria-label": "Two configurable features", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "02" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("small", { children: "configurable" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "feature-list", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "feature-row", "aria-labelledby": "pdf-feature-title", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "feature-index", "aria-hidden": "true", children: "01" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "feature-copy", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "feature-title-row", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { id: "pdf-feature-title", children: "PDF viewer" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `feature-state ${pdfInterceptorEnabled ? "is-on" : ""}`, children: pdfInterceptorEnabled ? "Active" : "Off" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Open PDF files in the BrowserOnly viewer for text extraction, Markdown copy, and AI-assisted reading." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "feature-toggle", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Enable PDF viewer" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", className: "toggle toggle-primary", checked: pdfInterceptorEnabled, onChange: (event) => setPdfInterceptorEnabled(event.target.checked) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "feature-row feature-row-expanded", "aria-labelledby": "translator-feature-title", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "feature-index", "aria-hidden": "true", children: "02" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "feature-copy", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "feature-title-row", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { id: "translator-feature-title", children: "Translator" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "feature-state is-on", children: "Ready" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Select which of your configured LLM providers handles translation. Credentials and model settings are reused from LLM Configuration." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "translator-control", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "translation-target-language", children: "Target language" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { id: "translation-target-language", className: "select select-bordered", value: targetLanguage, onChange: (event) => setTargetLanguage(event.target.value), children: [
              !translationLanguages.some((language) => language.value === targetLanguage) && /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: targetLanguage, children: targetLanguage }),
              translationLanguages.map((language) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: language.value, children: language.label }, language.value))
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { htmlFor: "translation-provider", children: "LLM provider" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { id: "translation-provider", className: "select select-bordered", value: translationProvider, onChange: (event) => setTranslationProvider(event.target.value), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: "primary", children: [
                "Follow default provider (",
                providerNames[primaryProvider] || primaryProvider,
                ")"
              ] }),
              configuredProviders.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: item.id, children: item.name }, item.id))
            ] }),
            configuredProviders.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "field-note", children: "No dedicated providers are configured yet. Translation will follow the default provider." }),
            !selectedProviderIsAvailable && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "field-error", role: "alert", children: "This provider is no longer configured. Choose an available provider before saving." })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("footer", { className: "features-savebar", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Settings are synced with this Chrome profile." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "save-actions", "aria-live": "polite", children: [
        saveStatus === "saved" && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "save-message", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CheckIcon, {}),
          " Saved"
        ] }),
        saveStatus === "error" && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "save-message save-error", children: "Could not save settings" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", className: "btn btn-primary active:scale-95", onClick: handleSave, disabled: isSaving || !selectedProviderIsAvailable, children: isSaving ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "loading loading-spinner loading-sm" }),
          " Saving"
        ] }) : "Save feature settings" })
      ] })
    ] })
  ] });
}
function VerticalTabs(props) {
  const [activeTab, setActiveTab] = reactExports.useState("general");
  const tabs = [
    { id: "general", label: "General", icon: "01" },
    { id: "providers", label: "LLM Configuration", icon: "02" },
    { id: "features", label: "Features", icon: "03" },
    { id: "connection", label: "Connection", icon: "04" },
    { id: "memory", label: "Memory", icon: "05" }
  ];
  const renderTabContent = () => {
    switch (activeTab) {
      case "general":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(GeneralTab, { onOpenConfiguration: () => setActiveTab("providers") });
      case "providers":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(
          ProvidersTab,
          {
            provider: props.provider,
            setProvider: props.setProvider,
            anthropicApiKey: props.anthropicApiKey,
            setAnthropicApiKey: props.setAnthropicApiKey,
            anthropicBaseUrl: props.anthropicBaseUrl,
            setAnthropicBaseUrl: props.setAnthropicBaseUrl,
            thinkingBudgetTokens: props.thinkingBudgetTokens,
            setThinkingBudgetTokens: props.setThinkingBudgetTokens,
            openaiApiKey: props.openaiApiKey,
            setOpenaiApiKey: props.setOpenaiApiKey,
            openaiBaseUrl: props.openaiBaseUrl,
            setOpenaiBaseUrl: props.setOpenaiBaseUrl,
            deepseekApiKey: props.deepseekApiKey,
            setDeepseekApiKey: props.setDeepseekApiKey,
            deepseekBaseUrl: props.deepseekBaseUrl,
            setDeepseekBaseUrl: props.setDeepseekBaseUrl,
            geminiApiKey: props.geminiApiKey,
            setGeminiApiKey: props.setGeminiApiKey,
            geminiBaseUrl: props.geminiBaseUrl,
            setGeminiBaseUrl: props.setGeminiBaseUrl,
            ollamaApiKey: props.ollamaApiKey,
            setOllamaApiKey: props.setOllamaApiKey,
            ollamaBaseUrl: props.ollamaBaseUrl,
            setOllamaBaseUrl: props.setOllamaBaseUrl,
            ollamaModelId: props.ollamaModelId,
            setOllamaModelId: props.setOllamaModelId,
            ollamaCustomModels: props.ollamaCustomModels,
            setOllamaCustomModels: props.setOllamaCustomModels,
            newOllamaModel: props.newOllamaModel,
            setNewOllamaModel: props.setNewOllamaModel,
            handleAddOllamaModel: props.handleAddOllamaModel,
            handleRemoveOllamaModel: props.handleRemoveOllamaModel,
            handleEditOllamaModel: props.handleEditOllamaModel,
            openaiCompatibleApiKey: props.openaiCompatibleApiKey,
            setOpenaiCompatibleApiKey: props.setOpenaiCompatibleApiKey,
            openaiCompatibleBaseUrl: props.openaiCompatibleBaseUrl,
            setOpenaiCompatibleBaseUrl: props.setOpenaiCompatibleBaseUrl,
            openaiCompatibleModelId: props.openaiCompatibleModelId,
            setOpenaiCompatibleModelId: props.setOpenaiCompatibleModelId,
            openaiCompatibleModels: props.openaiCompatibleModels,
            setOpenaiCompatibleModels: props.setOpenaiCompatibleModels,
            newModel: props.newModel,
            setNewModel: props.setNewModel,
            isSaving: props.isSaving,
            saveStatus: props.saveStatus,
            handleSave: props.handleSave,
            handleAddModel: props.handleAddModel,
            handleRemoveModel: props.handleRemoveModel,
            handleEditModel: props.handleEditModel
          }
        );
      case "features":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(
          FeaturesTab,
          {
            pdfInterceptorEnabled: props.pdfInterceptorEnabled,
            setPdfInterceptorEnabled: props.setPdfInterceptorEnabled,
            translationProvider: props.translationProvider,
            setTranslationProvider: props.setTranslationProvider,
            targetLanguage: props.targetLanguage,
            setTargetLanguage: props.setTargetLanguage,
            primaryProvider: props.provider,
            configuredProviders: props.configuredProviders
          }
        );
      case "connection":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(
          ConnectionTab,
          {
            notionEnabled: props.notionEnabled,
            setNotionEnabled: props.setNotionEnabled,
            notionBearerToken: props.notionBearerToken,
            setNotionBearerToken: props.setNotionBearerToken,
            notionDatabaseId: props.notionDatabaseId,
            setNotionDatabaseId: props.setNotionDatabaseId,
            duckdbEnabled: props.duckdbEnabled,
            setDuckdbEnabled: props.setDuckdbEnabled,
            duckdbConnectionString: props.duckdbConnectionString,
            setDuckdbConnectionString: props.setDuckdbConnectionString,
            duckdbDatabasePath: props.duckdbDatabasePath,
            setDuckdbDatabasePath: props.setDuckdbDatabasePath
          }
        );
      case "memory":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(MemoryTab, {});
      default:
        return /* @__PURE__ */ jsxRuntimeExports.jsx(GeneralTab, {});
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "options-page flex min-h-screen bg-[#eef1f3] text-stone-900", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "options-sidebar w-64 shrink-0 border-r border-stone-200 bg-[#f4f6f7]", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-12 flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "brand-mark flex h-10 w-10 items-center justify-center rounded-lg bg-[#315a78] text-white", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "B" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-lg font-semibold tracking-tight text-stone-900", children: "BrowserOnly" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-stone-500", children: "Extension settings" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-1.5", children: tabs.map((tab) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          className: `settings-nav-item flex w-full items-center gap-3 rounded-md px-3 py-3 text-left text-sm font-medium transition-colors ${activeTab === tab.id ? "bg-[#315a78] text-white shadow-sm" : "text-stone-600 hover:bg-stone-100 hover:text-stone-900"}`,
          onClick: () => setActiveTab(tab.id),
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "nav-index", children: tab.icon }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: tab.label })
          ]
        },
        tab.id
      )) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "options-content min-w-0 flex-1 overflow-auto p-4 sm:p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-full overflow-auto rounded-xl border border-stone-200 bg-white", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto max-w-5xl p-6 sm:p-12", children: renderTabContent() }) }) })
  ] });
}
const defaultTargetLanguage = () => typeof navigator !== "undefined" && navigator.language ? navigator.language : "zh-CN";
function Options() {
  const [provider, setProvider] = reactExports.useState("deepseek");
  const [anthropicApiKey, setAnthropicApiKey] = reactExports.useState("");
  const [anthropicBaseUrl, setAnthropicBaseUrl] = reactExports.useState("");
  const [openaiApiKey, setOpenaiApiKey] = reactExports.useState("");
  const [openaiBaseUrl, setOpenaiBaseUrl] = reactExports.useState("");
  const [deepseekApiKey, setDeepseekApiKey] = reactExports.useState("");
  const [deepseekBaseUrl, setDeepseekBaseUrl] = reactExports.useState("");
  const [geminiApiKey, setGeminiApiKey] = reactExports.useState("");
  const [geminiBaseUrl, setGeminiBaseUrl] = reactExports.useState("");
  const [ollamaApiKey, setOllamaApiKey] = reactExports.useState("");
  const [ollamaBaseUrl, setOllamaBaseUrl] = reactExports.useState("");
  const [ollamaCustomModels, setOllamaCustomModels] = reactExports.useState([]);
  const [newOllamaModel, setNewOllamaModel] = reactExports.useState({ id: "", name: "", contextWindow: 32768 });
  const [anthropicModelId, setAnthropicModelId] = reactExports.useState(anthropicDefaultModelId);
  const [openaiModelId, setOpenaiModelId] = reactExports.useState(openaiDefaultModelId);
  const [geminiModelId, setGeminiModelId] = reactExports.useState(geminiDefaultModelId);
  const [ollamaModelId, setOllamaModelId] = reactExports.useState(ollamaDefaultModelId);
  const [deepseekModelId, setDeepseekModelId] = reactExports.useState(deepseekDefaultModelId);
  const [thinkingBudgetTokens, setThinkingBudgetTokens] = reactExports.useState(0);
  const [isSaving, setIsSaving] = reactExports.useState(false);
  const [saveStatus, setSaveStatus] = reactExports.useState("");
  const [openaiCompatibleApiKey, setOpenaiCompatibleApiKey] = reactExports.useState("");
  const [openaiCompatibleBaseUrl, setOpenaiCompatibleBaseUrl] = reactExports.useState("");
  const [openaiCompatibleModelId, setOpenaiCompatibleModelId] = reactExports.useState("");
  const [openaiCompatibleModels, setOpenaiCompatibleModels] = reactExports.useState([]);
  const [newModel, setNewModel] = reactExports.useState({ id: "", name: "", isReasoningModel: false });
  const [notionEnabled, setNotionEnabled] = reactExports.useState(false);
  const [notionMcpServerUrl, setNotionMcpServerUrl] = reactExports.useState("");
  const [notionBearerToken, setNotionBearerToken] = reactExports.useState("");
  const [notionDatabaseId, setNotionDatabaseId] = reactExports.useState("");
  const [duckdbEnabled, setDuckdbEnabled] = reactExports.useState(false);
  const [duckdbConnectionString, setDuckdbConnectionString] = reactExports.useState("");
  const [duckdbDatabasePath, setDuckdbDatabasePath] = reactExports.useState(":memory:");
  const [pdfInterceptorEnabled, setPdfInterceptorEnabled] = reactExports.useState(true);
  const [translationProvider, setTranslationProvider] = reactExports.useState("primary");
  const [targetLanguage, setTargetLanguage] = reactExports.useState(defaultTargetLanguage);
  reactExports.useEffect(() => {
    chrome.storage.sync.get({
      provider: "deepseek",
      anthropicApiKey: "",
      anthropicModelId: anthropicDefaultModelId,
      anthropicBaseUrl: "",
      openaiApiKey: "",
      openaiModelId: openaiDefaultModelId,
      openaiBaseUrl: "",
      deepseekApiKey: "",
      deepseekModelId: deepseekDefaultModelId,
      deepseekBaseUrl: "",
      geminiApiKey: "",
      geminiModelId: geminiDefaultModelId,
      geminiBaseUrl: "",
      ollamaApiKey: "",
      ollamaModelId: ollamaDefaultModelId,
      ollamaBaseUrl: DEFAULT_OLLAMA_BASE_URL,
      ollamaCustomModels: [],
      thinkingBudgetTokens: 0,
      openaiCompatibleApiKey: "",
      openaiCompatibleBaseUrl: "",
      openaiCompatibleModelId: "",
      openaiCompatibleModels: [],
      notionEnabled: false,
      notionMcpServerUrl: "",
      notionBearerToken: "",
      notionDatabaseId: "",
      duckdbEnabled: false,
      duckdbConnectionString: "",
      duckdbDatabasePath: ":memory:",
      "pdf-interceptor-enabled": false,
      translationProvider: "primary",
      targetLanguage: ""
    }, (result) => {
      setProvider(result.provider);
      setAnthropicApiKey(result.anthropicApiKey);
      setAnthropicModelId(result.anthropicModelId);
      setAnthropicBaseUrl(result.anthropicBaseUrl);
      setOpenaiApiKey(result.openaiApiKey);
      setOpenaiModelId(result.openaiModelId);
      setOpenaiBaseUrl(result.openaiBaseUrl);
      setDeepseekApiKey(result.deepseekApiKey);
      setDeepseekModelId(result.deepseekModelId);
      setDeepseekBaseUrl(result.deepseekBaseUrl);
      setGeminiApiKey(result.geminiApiKey);
      setGeminiModelId(result.geminiModelId);
      setGeminiBaseUrl(result.geminiBaseUrl);
      setOllamaApiKey(result.ollamaApiKey);
      setOllamaModelId(result.ollamaModelId);
      setOllamaBaseUrl(result.ollamaBaseUrl || DEFAULT_OLLAMA_BASE_URL);
      setOllamaCustomModels(result.ollamaCustomModels || []);
      setThinkingBudgetTokens(result.thinkingBudgetTokens);
      setOpenaiCompatibleApiKey(result.openaiCompatibleApiKey || "");
      setOpenaiCompatibleBaseUrl(result.openaiCompatibleBaseUrl || "");
      setOpenaiCompatibleModelId(result.openaiCompatibleModelId || "");
      setOpenaiCompatibleModels(result.openaiCompatibleModels || []);
      setNotionEnabled(result.notionEnabled || false);
      setNotionMcpServerUrl(result.notionMcpServerUrl || "");
      setNotionBearerToken(result.notionBearerToken || "");
      setNotionDatabaseId(result.notionDatabaseId || "");
      setDuckdbEnabled(result.duckdbEnabled || false);
      setDuckdbConnectionString(result.duckdbConnectionString || "");
      setDuckdbDatabasePath(result.duckdbDatabasePath || ":memory:");
      setPdfInterceptorEnabled(result["pdf-interceptor-enabled"] !== false);
      setTranslationProvider(result.translationProvider || "primary");
      setTargetLanguage(result.targetLanguage || defaultTargetLanguage());
    });
  }, []);
  const handleSave = () => {
    setIsSaving(true);
    setSaveStatus("");
    chrome.storage.sync.set({
      provider,
      anthropicApiKey,
      anthropicModelId,
      anthropicBaseUrl,
      openaiApiKey,
      openaiModelId,
      openaiBaseUrl,
      deepseekApiKey,
      deepseekModelId,
      deepseekBaseUrl,
      geminiApiKey,
      geminiModelId,
      geminiBaseUrl,
      ollamaApiKey,
      ollamaModelId,
      ollamaBaseUrl,
      ollamaCustomModels,
      thinkingBudgetTokens,
      openaiCompatibleApiKey,
      openaiCompatibleBaseUrl,
      openaiCompatibleModelId,
      openaiCompatibleModels,
      notionEnabled,
      notionMcpServerUrl,
      notionBearerToken,
      notionDatabaseId,
      duckdbEnabled,
      duckdbConnectionString,
      duckdbDatabasePath,
      "pdf-interceptor-enabled": pdfInterceptorEnabled,
      translationProvider,
      targetLanguage
    }, () => {
      setIsSaving(false);
      setSaveStatus("Settings saved successfully!");
      chrome.runtime.sendMessage({
        action: "providerConfigChanged"
      }).catch((err) => console.error("Error sending message:", err));
      setTimeout(() => {
        setSaveStatus("");
      }, 3e3);
    });
  };
  const handleAddOllamaModel = () => {
    if (!newOllamaModel.id.trim() || !newOllamaModel.name.trim()) return;
    const updatedModels = [...ollamaCustomModels, { ...newOllamaModel }];
    setOllamaCustomModels(updatedModels);
    setNewOllamaModel({ id: "", name: "", contextWindow: 32768 });
    chrome.storage.sync.set({ ollamaCustomModels: updatedModels });
  };
  const handleRemoveOllamaModel = (id) => {
    const updatedModels = ollamaCustomModels.filter((m) => m.id !== id);
    setOllamaCustomModels(updatedModels);
    if (ollamaModelId === id) setOllamaModelId("");
    chrome.storage.sync.set({ ollamaCustomModels: updatedModels });
  };
  const handleEditOllamaModel = (idx, field, value) => {
    let updatedModels = [];
    setOllamaCustomModels((models) => {
      updatedModels = models.map((m, i) => i === idx ? { ...m, [field]: value } : m);
      return updatedModels;
    });
    setTimeout(() => {
      chrome.storage.sync.set({ ollamaCustomModels: updatedModels });
    }, 0);
  };
  const handleAddModel = () => {
    if (!newModel.id.trim() || !newModel.name.trim()) return;
    setOpenaiCompatibleModels([...openaiCompatibleModels, { ...newModel }]);
    setNewModel({ id: "", name: "", isReasoningModel: false });
  };
  const handleRemoveModel = (id) => {
    setOpenaiCompatibleModels(openaiCompatibleModels.filter((m) => m.id !== id));
    if (openaiCompatibleModelId === id) setOpenaiCompatibleModelId("");
  };
  const handleEditModel = (idx, field, value) => {
    setOpenaiCompatibleModels((models) => models.map((m, i) => i === idx ? { ...m, [field]: value } : m));
  };
  const configuredProviders = [
    anthropicApiKey.trim() && { id: "anthropic", name: "Anthropic" },
    openaiApiKey.trim() && { id: "openai", name: "OpenAI" },
    deepseekApiKey.trim() && { id: "deepseek", name: "DeepSeek" },
    geminiApiKey.trim() && { id: "gemini", name: "Google Gemini" },
    ollamaBaseUrl.trim() && ollamaCustomModels.length > 0 && { id: "ollama", name: "Ollama" },
    openaiCompatibleApiKey.trim() && openaiCompatibleModels.length > 0 && {
      id: "openai-compatible",
      name: "OpenAI Compatible"
    }
  ].filter((item) => Boolean(item));
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    VerticalTabs,
    {
      provider,
      setProvider,
      anthropicApiKey,
      setAnthropicApiKey,
      anthropicBaseUrl,
      setAnthropicBaseUrl,
      thinkingBudgetTokens,
      setThinkingBudgetTokens,
      openaiApiKey,
      setOpenaiApiKey,
      openaiBaseUrl,
      setOpenaiBaseUrl,
      deepseekApiKey,
      setDeepseekApiKey,
      deepseekBaseUrl,
      setDeepseekBaseUrl,
      geminiApiKey,
      setGeminiApiKey,
      geminiBaseUrl,
      setGeminiBaseUrl,
      ollamaApiKey,
      setOllamaApiKey,
      ollamaBaseUrl,
      setOllamaBaseUrl,
      ollamaModelId,
      setOllamaModelId,
      ollamaCustomModels,
      setOllamaCustomModels,
      newOllamaModel,
      setNewOllamaModel,
      handleAddOllamaModel,
      handleRemoveOllamaModel,
      handleEditOllamaModel,
      openaiCompatibleApiKey,
      setOpenaiCompatibleApiKey,
      openaiCompatibleBaseUrl,
      setOpenaiCompatibleBaseUrl,
      openaiCompatibleModelId,
      setOpenaiCompatibleModelId,
      openaiCompatibleModels,
      setOpenaiCompatibleModels,
      newModel,
      setNewModel,
      isSaving,
      saveStatus,
      handleSave,
      handleAddModel,
      handleRemoveModel,
      handleEditModel,
      notionEnabled,
      setNotionEnabled,
      notionMcpServerUrl,
      setNotionMcpServerUrl,
      notionBearerToken,
      setNotionBearerToken,
      notionDatabaseId,
      setNotionDatabaseId,
      duckdbEnabled,
      setDuckdbEnabled,
      duckdbConnectionString,
      setDuckdbConnectionString,
      duckdbDatabasePath,
      setDuckdbDatabasePath,
      pdfInterceptorEnabled,
      setPdfInterceptorEnabled,
      translationProvider,
      setTranslationProvider,
      targetLanguage,
      setTargetLanguage,
      configuredProviders
    }
  );
}
const container = document.getElementById("root");
const root = clientExports.createRoot(container);
root.render(/* @__PURE__ */ jsxRuntimeExports.jsx(Options, {}));
//# sourceMappingURL=options.js.map
